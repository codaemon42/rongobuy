(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_category_phone-cover_phone-cover_module_ts"],{

/***/ 68184:
/*!********************************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover-routing.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneCoverPageRoutingModule": () => (/* binding */ PhoneCoverPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _phone_cover_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./phone-cover.page */ 76826);




const routes = [
    {
        path: '',
        component: _phone_cover_page__WEBPACK_IMPORTED_MODULE_0__.PhoneCoverPage
    },
    {
        path: 'phone-cover-detail/:slug',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_category_phone-cover_phone-cover-detail_phone-cover-detail_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./phone-cover-detail/phone-cover-detail.module */ 89335)).then(m => m.PhoneCoverDetailPageModule)
    }
];
let PhoneCoverPageRoutingModule = class PhoneCoverPageRoutingModule {
};
PhoneCoverPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PhoneCoverPageRoutingModule);



/***/ }),

/***/ 18184:
/*!************************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneCoverPageModule": () => (/* binding */ PhoneCoverPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _phone_cover_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./phone-cover-routing.module */ 68184);
/* harmony import */ var _phone_cover_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-cover.page */ 76826);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/components.module */ 45642);








let PhoneCoverPageModule = class PhoneCoverPageModule {
};
PhoneCoverPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _phone_cover_routing_module__WEBPACK_IMPORTED_MODULE_0__.PhoneCoverPageRoutingModule
        ],
        declarations: [_phone_cover_page__WEBPACK_IMPORTED_MODULE_1__.PhoneCoverPage]
    })
], PhoneCoverPageModule);



/***/ }),

/***/ 76826:
/*!**********************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover.page.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneCoverPage": () => (/* binding */ PhoneCoverPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_phone_cover_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./phone-cover.page.html */ 29100);
/* harmony import */ var _phone_cover_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-cover.page.scss */ 61595);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var src_app_services_category_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/category.service */ 54655);






let PhoneCoverPage = class PhoneCoverPage {
    constructor(nav, loadingCtrl, categoryService) {
        this.nav = nav;
        this.loadingCtrl = loadingCtrl;
        this.categoryService = categoryService;
        this.hideOverlay = false;
        this.phoneCoverCat = null;
    }
    ngOnInit() {
        this.categoryService.fetchCategories().subscribe();
        this.categoryService.categories.subscribe(categories => {
            this.phoneCoverCat = categories.find(cat => cat.slug === 'phone-cover');
            console.log('this.phoneCoverCat : ', this.phoneCoverCat);
        });
    }
    onRoute(slug) {
        this.nav.navigateForward(`category/phone-cover/phone-cover-detail/${slug}`);
    }
    onSelectModel(event) {
        console.log('model event : ', event);
        if (event !== null) {
            let counter = 1;
            this.loadingCtrl.create({
                message: `Loading ${event.name} models`,
                mode: 'ios',
                duration: 2000
            }).then(loadingEl => {
                loadingEl.present();
                const timer = setInterval(() => {
                    if (this.hideOverlay) {
                        console.log(counter++);
                        this.hideOverlay = false;
                        this.nav.navigateForward('category/phone-cover/phone-cover-detail');
                        clearInterval(timer);
                    }
                }, 100);
            });
        }
    }
    onHiddenOverlay(event) {
        this.hideOverlay = event;
        console.log('event', this.hideOverlay);
    }
};
PhoneCoverPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.LoadingController },
    { type: src_app_services_category_service__WEBPACK_IMPORTED_MODULE_2__.CategoryService }
];
PhoneCoverPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-phone-cover',
        template: _raw_loader_phone_cover_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_phone_cover_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PhoneCoverPage);



/***/ }),

/***/ 61595:
/*!************************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover.page.scss ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (":host ::ng-deep .p-dropdown {\n  width: 100%;\n  box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.24);\n  border-top: 0.5px solid #dddddd;\n}\n\nion-card:hover {\n  box-shadow: 0 5px 8px #00000045;\n}\n\nion-card .subtitle {\n  color: #888;\n  font-weight: bold;\n  padding: 3px;\n  font-size: 14px;\n}\n\n.spinner {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBob25lLWNvdmVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLFdBQUE7RUFDQSwyQ0FBQTtFQUNBLCtCQUFBO0FBQUo7O0FBSUU7RUFDRSwrQkFBQTtBQURKOztBQUdFO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFESjs7QUFLQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFGRiIsImZpbGUiOiJwaG9uZS1jb3Zlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuOmhvc3QgOjpuZy1kZWVwIC5wLWRyb3Bkb3duIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm94LXNoYWRvdzogMCA4cHggOHB4IDAgcmdiYSgwLCAwLCAwLCAwLjI0KTtcclxuICAgIGJvcmRlci10b3A6IDAuNXB4IHNvbGlkIHJnYigyMjEsIDIyMSwgMjIxKTtcclxufVxyXG5cclxuaW9uLWNhcmR7XHJcbiAgJjpob3ZlcntcclxuICAgIGJveC1zaGFkb3c6IDAgNXB4IDhweCAjMDAwMDAwNDU7XHJcbiAgfVxyXG4gIC5zdWJ0aXRsZSB7XHJcbiAgICBjb2xvcjogIzg4ODtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgcGFkZGluZzogM3B4O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gIH1cclxufVxyXG5cclxuLnNwaW5uZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 29100:
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/category/phone-cover/phone-cover.page.html ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"warning\">\n    <ion-title class=\"ion-text-center\">Phone Brands</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col *ngIf=\"!phoneCoverCat\">\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"phoneCoverCat\">\n      <!-- <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <app-phone-selector (hideOverlay)=\"onHiddenOverlay($event)\" (modelSelected)=\"onSelectModel($event)\"></app-phone-selector>\n      </ion-col> -->\n    </ion-row>\n    <ion-row *ngIf=\"phoneCoverCat\">\n      <ion-col (click)=\"onRoute(brand.slug)\" size=\"3\" sizeSm=\"3\" sizeMd=\"3\" *ngFor=\"let brand of phoneCoverCat.child\" >\n        <ion-card>\n          <ion-img [src]=\"brand.image\"></ion-img>\n          <ion-card-subtitle class=\"subtitle ion-text-center\">{{brand.categoryName}}</ion-card-subtitle>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_category_phone-cover_phone-cover_module_ts.js.map