(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_review_review_module_ts"],{

/***/ 40138:
/*!*************************************************!*\
  !*** ./src/app/review/review-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewPageRoutingModule": () => (/* binding */ ReviewPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _review_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review.page */ 59125);




const routes = [
    {
        path: '',
        component: _review_page__WEBPACK_IMPORTED_MODULE_0__.ReviewPage
    }
];
let ReviewPageRoutingModule = class ReviewPageRoutingModule {
};
ReviewPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReviewPageRoutingModule);



/***/ }),

/***/ 83682:
/*!*****************************************!*\
  !*** ./src/app/review/review.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewPageModule": () => (/* binding */ ReviewPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var primeng_rating__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/rating */ 48015);
/* harmony import */ var _review_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review-routing.module */ 40138);
/* harmony import */ var _review_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./review.page */ 59125);








let ReviewPageModule = class ReviewPageModule {
};
ReviewPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            primeng_rating__WEBPACK_IMPORTED_MODULE_7__.RatingModule,
            _review_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReviewPageRoutingModule
        ],
        declarations: [_review_page__WEBPACK_IMPORTED_MODULE_1__.ReviewPage]
    })
], ReviewPageModule);



/***/ }),

/***/ 59125:
/*!***************************************!*\
  !*** ./src/app/review/review.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewPage": () => (/* binding */ ReviewPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_review_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./review.page.html */ 44165);
/* harmony import */ var _review_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./review.page.scss */ 88591);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 80476);







let ReviewPage = class ReviewPage {
    constructor(router, nav, loadingCtrl, toastCtrl) {
        this.router = router;
        this.nav = nav;
        this.loadingCtrl = loadingCtrl;
        this.toastCtrl = toastCtrl;
        this.rating = 5;
        this.invalid = false;
        this.reviewForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroup({
            review: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl(null, {
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
                updateOn: 'change'
            })
        });
        this.logo = 'https://scontent.fdac22-1.fna.fbcdn.net/v/t1.6435-9/52384618_403447716890410_7519901944706498560_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=09cbfe&_nc_ohc=4vf2J_gHjV4AX9Iw4WH&_nc_ht=scontent.fdac22-1.fna&oh=cc8086e722ec06839a2993d3ac1852a3&oe=6180485F';
        this.loginSection = true;
        this.otpSection = false;
        this.successSection = false;
    }
    ngOnInit() {
        this.router.params.subscribe(route => {
            this.productId = route.productId;
            console.log('product_id : ', this.productId);
        });
    }
    onReview() {
        console.log(this.reviewForm);
        this.loadingCtrl.create({
            mode: 'ios',
            message: 'Submitting Review'
        }).then(loadingEl => {
            loadingEl.present();
            if (this.reviewForm.valid) {
                this.loadingCtrl.dismiss();
                console.log({
                    success: true,
                    review: this.reviewForm.value.review,
                    rating: this.rating
                });
                this.nav.navigateForward('/tabs/home');
            }
            else {
                this.loadingCtrl.dismiss();
                this.toastCtrl.create({
                    mode: 'ios',
                    color: 'danger',
                    position: 'top',
                    message: 'something went wrong...',
                    duration: 2000
                }).then(toastEl => {
                    toastEl.present();
                });
            }
        });
    }
    inputChanged() {
        if (!this.reviewForm.valid) {
            this.invalid = true;
            this.message = 'Invalid phone number. Ex.013xxxxxxxx';
        }
        else {
            this.invalid = false;
            this.message = '';
        }
    }
};
ReviewPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController }
];
ReviewPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-review',
        template: _raw_loader_review_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_review_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ReviewPage);



/***/ }),

/***/ 88591:
/*!*****************************************!*\
  !*** ./src/app/review/review.page.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo-container {\n  display: block;\n  width: 100%;\n  text-align: center;\n  padding-top: 50px;\n  padding-bottom: 25px;\n}\n.logo-container .site-icon {\n  width: 110px;\n  height: 110px;\n  border-radius: 50%;\n  text-align: center;\n  margin: auto;\n}\n.login-content {\n  border-radius: 10px 10px 0 0;\n  padding: 20px;\n  margin-top: 70px;\n}\n.login-content .rating {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  margin-bottom: 22px;\n}\n.login-content ion-textarea {\n  border: 1px solid #d7d7d7;\n  box-shadow: 0 8px 8px #ebebeb;\n  margin-bottom: 25px;\n  border-radius: 10px;\n}\n.login-content ion-input {\n  border-radius: 15px;\n  background: #fff;\n  box-shadow: 0 8px 8px 0 #ececec;\n}\n.login-content ion-button {\n  --border-radius: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJldmlldy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtBQUFGO0FBRUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBQUo7QUFJQTtFQUNFLDRCQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0FBREY7QUFHRTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQURKO0FBSUU7RUFDRSx5QkFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQUZKO0FBTUU7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsK0JBQUE7QUFKSjtBQU1FO0VBQ0UscUJBQUE7QUFKSiIsImZpbGUiOiJyZXZpZXcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5sb2dvLWNvbnRhaW5lcntcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB3aWR0aDogMTAwJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZy10b3A6IDUwcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDI1cHg7XHJcblxyXG4gIC5zaXRlLWljb257XHJcbiAgICB3aWR0aDogMTEwcHg7XHJcbiAgICBoZWlnaHQ6IDExMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czo1MCU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgfVxyXG59XHJcblxyXG4ubG9naW4tY29udGVudHtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMCAwO1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgbWFyZ2luLXRvcDogNzBweDtcclxuXHJcbiAgLnJhdGluZyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIG1hcmdpbi1ib3R0b206IDIycHg7XHJcbiAgfVxyXG5cclxuICBpb24tdGV4dGFyZWF7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZDdkN2Q3O1xyXG4gICAgYm94LXNoYWRvdzogMCA4cHggOHB4ICNlYmViZWI7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyNXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICB9XHJcblxyXG5cclxuICBpb24taW5wdXR7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIGJveC1zaGFkb3c6IDAgOHB4IDhweCAwIHJnYigyMzYsIDIzNiwgMjM2KTtcclxuICB9XHJcbiAgaW9uLWJ1dHRvbntcclxuICAgIC0tYm9yZGVyLXJhZGl1czogMTVweDtcclxuICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 44165:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/review/review.page.html ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"12\" sizeLg=\"12\">\n        <div class=\"logo-container\">\n          <img class=\"site-icon\" [src]=\"logo\" alt=\"Rongobuy\">\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"12\" sizeLg=\"12\">\n        <div class=\"login-content\">\n          <div class=\"login-section\">\n            <div class=\"rating\">\n              <p-rating [(ngModel)]=\"rating\" [cancel]=\"false\"></p-rating>\n            </div>\n            <form [formGroup]=\"reviewForm\" (ngSubmit)=\"onReview()\">\n              <ion-textarea formControlName=\"review\" placeholder=\"write review\" ></ion-textarea>\n              <ion-button type=\"submit\" color=\"warning\" expand=\"block\">Submit Review</ion-button>\n            </form>\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_review_review_module_ts.js.map