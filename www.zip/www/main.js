(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 81131:
/*!******************************************!*\
  !*** ./src/app/account/account.guard.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountGuard": () => (/* binding */ AccountGuard)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _account_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account.service */ 10740);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/auth.service */ 37556);





let AccountGuard = class AccountGuard {
    constructor(accountService, router, authService) {
        this.accountService = accountService;
        this.router = router;
        this.authService = authService;
    }
    canActivate(route, state) {
        if (!this.accountService.userIsAuthenticated) {
            console.log('segments from acc guard : ', state);
            this.authService.addReferrer(state.url);
            this.router.navigateByUrl('/tabs/account');
        }
        return this.accountService.userIsAuthenticated;
    }
};
AccountGuard.ctorParameters = () => [
    { type: _account_service__WEBPACK_IMPORTED_MODULE_0__.AccountService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService }
];
AccountGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], AccountGuard);



/***/ }),

/***/ 10740:
/*!********************************************!*\
  !*** ./src/app/account/account.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountService": () => (/* binding */ AccountService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/storage.service */ 71188);

/* eslint-disable no-underscore-dangle */


let AccountService = class AccountService {
    constructor(storageService) {
        this.storageService = storageService;
        this._userIsAuthenticated = false;
        this._userId = null;
        this._userToken = null;
        this.setConstants();
    }
    setConstants() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            this._userIsAuthenticated = yield this.storageService.get('_userIsAuthenticated');
            this._userId = yield this.storageService.get('_userId');
            this._userToken = yield this.storageService.get('_userToken');
        });
    }
    get userId() {
        return this._userId;
    }
    get userIsAuthenticated() {
        return this._userIsAuthenticated;
    }
    get userToken() {
        return this._userToken;
    }
    isLoggedIn() {
        if (this._userIsAuthenticated) {
            return true;
        }
        else {
            return false;
        }
    }
    logIn(token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            this._userIsAuthenticated = true;
            this._userToken = token;
            //await this.storeToken(token);
            yield this.storageService.set('_userIsAuthenticated', true);
            yield this.storageService.set('_userToken', token);
        });
    }
    logOut() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            this._userIsAuthenticated = false;
            yield this.storageService.set('_userIsAuthenticated', false);
        });
    }
    storeToken(token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storageService.set('_userToken', token);
            yield this.storageService.set('_userToken', token);
        });
    }
    deleteToken() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storageService.set('_userToken', false);
        });
    }
};
AccountService.ctorParameters = () => [
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_0__.StorageService }
];
AccountService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], AccountService);



/***/ }),

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _account_account_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account/account.guard */ 81131);




const routes = [
    {
        path: '',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_rxjs__esm2015_internal_operators_shareReplay_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_tabs_tabs_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./tabs/tabs.module */ 15564)).then(m => m.TabsPageModule)
    },
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"), __webpack_require__.e("default-node_modules_rxjs__esm2015_internal_operators_shareReplay_js"), __webpack_require__.e("default-src_app_components_components_module_ts"), __webpack_require__.e("default-src_app_home_home_module_ts"), __webpack_require__.e("common")]).then(__webpack_require__.bind(__webpack_require__, /*! ./home/home.module */ 3467)).then(m => m.HomePageModule)
    },
    {
        path: 'category',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"), __webpack_require__.e("default-node_modules_rxjs__esm2015_internal_operators_shareReplay_js"), __webpack_require__.e("default-src_app_components_components_module_ts"), __webpack_require__.e("default-src_app_category_category_module_ts"), __webpack_require__.e("common")]).then(__webpack_require__.bind(__webpack_require__, /*! ./category/category.module */ 26914)).then(m => m.CategoryPageModule)
    },
    {
        path: 'all/orders',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_orders_orders_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./orders/orders.module */ 84819)).then(m => m.OrdersPageModule),
        canActivate: [_account_account_guard__WEBPACK_IMPORTED_MODULE_0__.AccountGuard]
    },
    {
        path: 'products',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_products_products_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./products/products.module */ 88980)).then(m => m.ProductsPageModule)
    },
    {
        path: 'carts',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_rxjs__esm2015_internal_operators_shareReplay_js"), __webpack_require__.e("default-src_app_carts_carts_module_ts"), __webpack_require__.e("common")]).then(__webpack_require__.bind(__webpack_require__, /*! ./carts/carts.module */ 92120)).then(m => m.CartsPageModule),
        canActivate: [_account_account_guard__WEBPACK_IMPORTED_MODULE_0__.AccountGuard]
    },
    {
        path: 'checkout',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-node_modules_rxjs__esm2015_internal_operators_shareReplay_js"), __webpack_require__.e("src_app_checkout_checkout_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./checkout/checkout.module */ 28400)).then(m => m.CheckoutPageModule),
        canActivate: [_account_account_guard__WEBPACK_IMPORTED_MODULE_0__.AccountGuard]
    },
    {
        path: 'pages',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_pages_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/pages.module */ 18950)).then(m => m.PagesPageModule)
    },
    {
        path: 'phone-customizer',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"), __webpack_require__.e("default-node_modules_rxjs__esm2015_internal_operators_shareReplay_js"), __webpack_require__.e("src_app_phone-customizer_phone-customizer_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./phone-customizer/phone-customizer.module */ 47216)).then(m => m.PhoneCustomizerPageModule)
    },
    {
        path: 'search',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_search_search_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./search/search.module */ 24682)).then(m => m.SearchPageModule)
    },
    {
        path: 'review/:productId',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_review_review_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./review/review.module */ 83682)).then(m => m.ReviewPageModule)
    },
    {
        path: 'wishlist',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_wishlist_wishlist_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./wishlist/wishlist.module */ 90582)).then(m => m.WishlistPageModule),
        canActivate: [_account_account_guard__WEBPACK_IMPORTED_MODULE_0__.AccountGuard]
    },
    {
        path: 'account',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"), __webpack_require__.e("default-node_modules_rxjs__esm2015_internal_operators_shareReplay_js"), __webpack_require__.e("default-src_app_components_components_module_ts"), __webpack_require__.e("default-src_app_account_account_module_ts"), __webpack_require__.e("common")]).then(__webpack_require__.bind(__webpack_require__, /*! ./account/account.module */ 63879)).then(m => m.AccountPageModule)
    },
    {
        path: 'custom-checkout',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_custom-checkout_custom-checkout_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./custom-checkout/custom-checkout.module */ 4872)).then(m => m.CustomCheckoutPageModule)
    }
    // {
    //   path: 'home',
    //   loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
    // },
    // {
    //   path: 'category',
    //   loadChildren: () => import('./category/category.module').then( m => m.CategoryPageModule)
    // },
    // {
    //   path: 'account',
    //   loadChildren: () => import('./account/account.module').then( m => m.AccountPageModule)
    // },
    // {
    //   path: 'shop',
    //   loadChildren: () => import('./shop/shop.module').then( m => m.ShopPageModule)
    // },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 91106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 43069);
/* harmony import */ var _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/device/ngx */ 77668);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ 73494);
/* harmony import */ var _services_menu_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/menu.service */ 98914);
/* harmony import */ var _account_account_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./account/account.service */ 10740);
/* harmony import */ var _services_controllers_loading_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/controllers/loading.service */ 24521);




/* eslint-disable max-len */






let AppComponent = class AppComponent {
    constructor(menuCtrl, menuService, platform, statusBar, nav, device, accountService, loadingService) {
        this.menuCtrl = menuCtrl;
        this.menuService = menuService;
        this.platform = platform;
        this.statusBar = statusBar;
        this.nav = nav;
        this.device = device;
        this.accountService = accountService;
        this.loadingService = loadingService;
        this.logo = 'https://scontent.fdac22-1.fna.fbcdn.net/v/t1.6435-9/52384618_403447716890410_7519901944706498560_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=09cbfe&_nc_ohc=4vf2J_gHjV4AX9Iw4WH&_nc_ht=scontent.fdac22-1.fna&oh=cc8086e722ec06839a2993d3ac1852a3&oe=6180485F';
        this.osVersion = "";
        this.uuid = "";
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            // let status bar overlay webview
            this.statusBar.overlaysWebView(true);
            // set status bar to white
            this.statusBar.backgroundColorByHexString('#000');
            this.osVersion = this.device.version;
            this.uuid = this.device.uuid;
            this.name = this.device.isVirtual;
            console.log(this.osVersion, this.uuid, this.name);
        });
        this.getMenus();
        // setTimeout(()=>{
        //   this.menus[1].show = true;
        // }, 7000);
    }
    getMenus() {
        this.menus = this.menuService.fetchMenus();
    }
    openMenu() {
        this.menuCtrl.enable(true, 'custom');
        this.menuCtrl.open('custom');
        console.log('menu clicked');
    }
    closeMenu() {
        this.menuCtrl.close('custom');
    }
    onClickMenu(index) {
        console.log('index : ', index);
        if (this.menus[index].children.length > 0) {
            console.log('entered');
            this.menus[index].show = !this.menus[index].show;
        }
        else {
            this.closeMenu();
            this.nav.navigateForward(this.menus[index].route);
        }
    }
    onClickMenuSub(i, si) {
        this.nav.navigateForward(this.menus[i].children[si].route);
    }
    menuIcon(index) {
        if (this.menus[index].children.length > 0 && !this.menus[index].show) { // down
            return 'caret-down';
        }
        if (this.menus[index].children.length > 0 && this.menus[index].show) { // up
            return 'caret-up';
        }
        if (this.menus[index].children.length === 0 && !this.menus[index].show) { // forward
            return 'caret-forward';
        }
    }
    logOut() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingService.loader('Logging out ...', 2000);
            if (loading) {
                this.accountService.logOut();
                this.closeMenu();
                this.nav.navigateForward('tabs/home');
            }
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.MenuController },
    { type: _services_menu_service__WEBPACK_IMPORTED_MODULE_4__.MenuService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.Platform },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__.StatusBar },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_2__.Device },
    { type: _account_account_service__WEBPACK_IMPORTED_MODULE_5__.AccountService },
    { type: _services_controllers_loading_service__WEBPACK_IMPORTED_MODULE_6__.LoadingService }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ 39075);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ 73494);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/storage-angular */ 54925);
/* harmony import */ var _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/device/ngx */ 77668);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser/animations */ 75835);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 91841);












let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__.AppComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.BrowserModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_2__.AppRoutingModule,
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__.BrowserAnimationsModule,
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.HammerModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule,
            _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_10__.IonicStorageModule.forRoot()
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_0__.StatusBar,
            Storage,
            _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_1__.Device,
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicRouteStrategy },
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 37556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var _cart_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart.service */ 90910);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);





let AuthService = class AuthService {
    constructor(http, cartService) {
        this.http = http;
        this.cartService = cartService;
        this._referrer = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
    }
    get referrer() {
        return this._referrer.asObservable();
    }
    addReferrer(referrer = '/tabs/home') {
        this._referrer.next(referrer);
    }
    loginWithOtp(phone = '01767000000') {
        return new Promise(resolve => {
            const url = 'http://auth.rongobuy.com/api/auth/v1/send-otp';
            const body = {
                mobile: phone
            };
            this.http.post(url, body).subscribe(resData => {
                console.log('sms api call login : ', resData);
                resolve(resData);
            });
        });
    }
    checkOTP(phone = '01767000000', code = '111111') {
        return new Promise(resolve => {
            const url = 'http://auth.rongobuy.com/api/auth/v1/check-otp';
            const body = {
                mobile: phone,
                otp: code
            };
            this.http.post(url, body).subscribe(resData => {
                console.log('otp verified : ', resData);
                resolve(resData);
            });
        });
    }
    getToken() {
        return 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9hdXRoLnJvbmdvYnV5LmNvbVwvYXBpXC9hdXRoXC92MVwvY2hlY2stb3RwIiwiaWF0IjoxNjM2Mjc5ODQ4LCJleHAiOjE2MzYyODM0NDgsIm5iZiI6MTYzNjI3OTg0OCwianRpIjoiY0FBMEEwZW1lSndZRGg1NiIsInN1YiI6MSwicHJ2IjoiMjNiZDVjODk0OWY2MDBhZGIzOWU3MDFjNDAwODcyZGI3YTU5NzZmNyJ9.UuFEB4ZZMSKHdpCqJkbzmpcS7Qm7mOuqJJz62YAKfkM';
    }
    mockAddCart(token) {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
        });
        const url = 'http://public.rongobuy.com/api/v1/cart/add';
        const body = {
            productId: '12',
            skuId: '12-green',
            quantity: '2'
        };
        this.http.post(url, body, { headers }).subscribe(resData => {
            console.log('auth cart added : ', resData);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient },
    { type: _cart_service__WEBPACK_IMPORTED_MODULE_0__.CartService }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 90910:
/*!******************************************!*\
  !*** ./src/app/services/cart.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartService": () => (/* binding */ CartService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 68307);
/* harmony import */ var _account_account_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../account/account.service */ 10740);



/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable no-underscore-dangle */




let CartService = class CartService {
    constructor(http, accountService) {
        this.http = http;
        this.accountService = accountService;
        // _cartObj = new BehaviorSubject<CartProduct[]>([]);
        this._cartDetails = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(null);
        this._cartTotalItems = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(0);
    }
    // get cartObj() {
    //   return this._cartObj.asObservable();
    // }
    get cartDetails() {
        return this._cartDetails.asObservable();
    }
    get cartTotalItems() {
        return this._cartTotalItems.asObservable();
    }
    fetchCartObj() {
        const token = this.accountService.userToken;
        const httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            })
        };
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/cart/all`, httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)(cartRes => {
            console.log('cartRes', cartRes);
            const data = cartRes.data;
            if (!cartRes.success && data === 401) {
                this.accountService.logOut();
            }
            // this._cartObj.next(cartRes.data.product);
            this._cartDetails.next(cartRes);
            this._cartTotalItems.next(cartRes.data.totalItem ? cartRes.data.totalItem : 0);
        }));
    }
    deleteCartItem(id) {
        console.log('deleted cart id : ', id);
        const token = this.accountService.userToken;
        const httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            })
        };
        let details;
        this.cartDetails.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1)).subscribe(detail => {
            details = detail;
            console.log('cart prev detail : ', detail);
            details.data.product.map(res => {
                console.log('cart id products details : ', res);
                if (res.id === id) {
                    // detail.data.subtotal
                    console.log('res id : ', res.id);
                    details.data.subtotal = details.data.subtotal ? details.data.subtotal - res.discountedPrice : 0;
                    details.data.grandTotal = details.data.grandTotal ? details.data.grandTotal - res.discountedPrice : 0;
                    console.log('grand total change : ', details);
                    const nextTotalItems = details.data.totalItem ? details.data.totalItem - res.quantity : 0;
                    details.data.totalItem = nextTotalItems;
                    this._cartTotalItems.next(nextTotalItems);
                }
            });
            const nextDetails = details.data.product.filter(res => res.id !== id);
            details.data.product = nextDetails;
            console.log('deleted cart : ', details);
            console.log('filtered cart product : ', nextDetails);
            console.log('next deleted details : ', details);
            this._cartDetails.next(details);
        });
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/cart/delete/${id}`, null, httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)(newCartItemRes => {
            //this.fetchCartObj().subscribe();
        }));
    }
    addTOCart(productId, skuId, quantity = 1, backgroundImage = null) {
        const token = this.accountService.userToken;
        const httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            })
        };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/cart/add`, { productId, skuId, quantity, backgroundImage }, httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)(newCartItemRes => {
            let details;
            this.cartDetails.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1)).subscribe(detail => {
                details = detail;
                console.log('cart added : ', detail);
                details.data.product.concat(newCartItemRes.data);
                const nextTotalItems = details.data.totalItem ? details.data.totalItem + quantity : 0;
                details.data.totalItem = nextTotalItems;
                this._cartDetails.next(details);
                this._cartTotalItems.next(nextTotalItems);
            });
        }));
    }
};
CartService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient },
    { type: _account_account_service__WEBPACK_IMPORTED_MODULE_1__.AccountService }
];
CartService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
        providedIn: 'root'
    })
], CartService);



/***/ }),

/***/ 24521:
/*!*********************************************************!*\
  !*** ./src/app/services/controllers/loading.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadingService": () => (/* binding */ LoadingService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 80476);



let LoadingService = class LoadingService {
    constructor(loadingCtrl) {
        this.loadingCtrl = loadingCtrl;
    }
    loader(message = 'loading ...', duration = null, mode = 'ios') {
        return new Promise(resolve => {
            const options = {
                message,
                duration,
                mode
            };
            this.loadingCtrl.create(options).then(el => {
                el.present();
                resolve(true);
            });
        });
    }
    closeLoader() {
        this.loadingCtrl.dismiss();
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.LoadingController }
];
LoadingService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], LoadingService);



/***/ }),

/***/ 98914:
/*!******************************************!*\
  !*** ./src/app/services/menu.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuService": () => (/* binding */ MenuService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);

/* eslint-disable @typescript-eslint/naming-convention */

let MenuService = class MenuService {
    constructor() { }
    fetchMenus() {
        return [
            {
                id: '1',
                icon: 'home',
                title: 'About Us',
                route: 'pages/about-us',
                show: false,
                children: []
            },
            {
                id: '2',
                icon: 'apps',
                title: 'Orders',
                route: 'all/orders',
                show: false,
                children: [
                    {
                        id: '2',
                        icon: 'apps',
                        title: 'Orders',
                        route: 'all/orders',
                        children: [
                            {
                                id: '3',
                                icon: 'home',
                                title: 'Order Tracking',
                                route: 'pages/order-tracking',
                                children: []
                            }
                        ]
                    },
                    {
                        id: '1',
                        icon: 'home',
                        title: 'About Us',
                        route: 'pages/about-us',
                        children: []
                    }
                ]
            },
            {
                id: '3',
                icon: 'home',
                title: 'Order Tracking',
                route: 'pages/order-tracking',
                show: false,
                children: []
            },
            {
                id: '4',
                icon: 'home',
                title: 'Customize Phone Cover',
                route: 'phone-customizer',
                show: false,
                children: []
            }
        ];
    }
};
MenuService.ctorParameters = () => [];
MenuService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], MenuService);



/***/ }),

/***/ 71188:
/*!*********************************************!*\
  !*** ./src/app/services/storage.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StorageService": () => (/* binding */ StorageService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/storage-angular */ 61628);

/* eslint-disable no-underscore-dangle */


let StorageService = class StorageService {
    constructor(storage) {
        this.storage = storage;
        this._storage = null;
        this.init();
    }
    init() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            // If using, define drivers here: await this.storage.defineDriver(/*...*/);
            const storage = yield this.storage.create();
            this._storage = storage;
        });
    }
    // Create and expose methods that users of this service can
    // call, for example:
    set(key, value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.storage.set(key, value);
        });
    }
    get(key) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.storage.get(key);
        });
    }
};
StorageService.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__.Storage }
];
StorageService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], StorageService);



/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    url: {
        base: 'http://public.rongobuy.com/api/v1'
    }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 24608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		47321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		36108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		31489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		10305,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		15830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		37757,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		30392,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		66911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		30937,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		78695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		16034,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		68837,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		34195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		41709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		33087,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		84513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		58056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		10862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		76272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		71855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		38708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		23527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		24694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		19222,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		25277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		39921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		83122,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		51602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45174,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		76164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		20592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		27162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		81374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		97896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		25043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		77802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		29072,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		32191,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		40801,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		67110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		10431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 43069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".rb-footer-void {\n  width: 100%;\n  height: 50px;\n}\n\nion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, rgb(255, 250, 250)));\n}\n\nion-toolbar {\n  padding: 0;\n  margin: 0;\n}\n\nion-toolbar img {\n  width: 100%;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14) ;\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-warning);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #ffffff;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #fff;\n}\n\nion-item.selected {\n  --color: var(--ion-color-warning);\n}\n\n.sub-menu {\n  margin-left: 20px;\n  transition: 2s;\n}\n\n.main-menu-item ion-item:hover {\n  --background: rgba(15, 15, 15, 0.027);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBQUY7O0FBRUE7RUFDRSx5RkFBQTtBQUNGOztBQUVBO0VBQ0UsVUFBQTtFQUNBLFNBQUE7QUFDRjs7QUFBRTtFQUNFLFdBQUE7QUFFSjs7QUFHQTtFQUNFLHVEQUFBO0FBQUY7O0FBR0E7RUFDRSwrQkFBQTtBQUFGOztBQUdBO0VBQ0UsY0FBQTtBQUFGOztBQUdBO0VBQ0UsK0JBQUE7QUFBRjs7QUFHQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FBQUY7O0FBR0E7RUFDRSxpQ0FBQTtBQUFGOztBQUdBO0VBQ0UsaUJBQUE7RUFDQSxjQUFBO0FBQUY7O0FBRUE7RUFDRSxxQ0FBQTtBQUNGIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGZvb3RlciBzZWN0aW9uXHJcbi5yYi1mb290ZXItdm9pZCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG59XHJcbmlvbi1tZW51IGlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pdGVtLWJhY2tncm91bmQsIHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yLCByZ2IoMjU1LCAyNTAsIDI1MCkpKTtcclxufVxyXG5cclxuaW9uLXRvb2xiYXIge1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIGltZyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9XHJcbn1cclxuXHJcblxyXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpXHJcbn1cclxuXHJcbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xyXG59XHJcblxyXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbn1cclxuXHJcbmlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxufVxyXG5cclxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgY29sb3I6ICNmZmY7XHJcbn1cclxuXHJcbmlvbi1pdGVtLnNlbGVjdGVkIHtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XHJcbn1cclxuXHJcbi5zdWItbWVudXtcclxuICBtYXJnaW4tbGVmdDogMjBweDtcclxuICB0cmFuc2l0aW9uOiAycztcclxufVxyXG4ubWFpbi1tZW51LWl0ZW0gaW9uLWl0ZW06aG92ZXJ7XHJcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE1LCAxNSwgMTUsIDAuMDI3KTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 91106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n\n  <ion-menu side=\"start\" menuId=\"custom\" contentId=\"main\" class=\"my-custom-menu\">\n    <ion-header>\n      <ion-toolbar color=\"warning\">\n        <ion-title>Menu</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-list>\n        <!-- <ion-item *ngFor=\"let menu of menus\" detail (click)=\"closeMenu()\"  [routerLink]=\"menu.route\"> {{ menu.title }} </ion-item> -->\n      <!-- <ion-menu-toggle auto-hide=\"false\">\n        <ion-list lines=\"none\">\n          <ion-item [routerLink]=\"'/'\">\n            <ion-icon name=\"home\" slot=\"start\"></ion-icon>\n            Home\n          </ion-item>\n          <ion-item routerLink=\"todos\">\n            <ion-icon name=\"list\" slot=\"start\"></ion-icon>\n            <ion-label>\n              Todos\n            </ion-label>\n          </ion-item>\n          <ion-item routerLink=\"finance\">\n            <ion-icon color=\"warning\" name=\"cash\" slot=\"start\"></ion-icon>\n            <ion-label>\n              Finance\n            </ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-menu-toggle> -->\n      <div class=\"main-menu-item\" *ngFor=\"let menu of menus; let i = index\">\n        <ion-item lines=\"none\" (click)=\"onClickMenu(i)\">\n          <ion-icon color=\"dark\" [name]=\"menu.icon\" slot=\"start\"></ion-icon>\n          {{ menu.title }}\n          <ion-icon color=\"warning\" slot=\"end\" [name]=\"menuIcon(i)\"></ion-icon>\n        </ion-item>\n\n        <!-- <ion-item lines=\"none\" (click)=\"onClickMenu(i)\">\n          <ion-icon color=\"warning\" [name]=\"menu.icon\" slot=\"start\"></ion-icon>\n          {{ menu.title }}\n          <ion-icon color=\"warning\" slot=\"end\" [name]=\"menuIcon(i)\"></ion-icon>\n        </ion-item> -->\n\n\n        <ion-menu-toggle *ngIf=\"menu.show\"  auto-hide=\"false\">\n          <ion-list lines=\"none\">\n            <ion-item\n              *ngFor=\"let subMenu of menu.children; let si = index\"\n              (click)=\"onClickMenuSub(i, si)\"\n              menuclose\n              [hidden]=\"!menu.show\"\n              [routerLink]=\"subMenu.route\"\n              menuClose\n              class=\"sub-menu\">\n              <ion-icon color=\"warning\" [name]=\"subMenu.icon\" slot=\"start\"></ion-icon>\n              {{subMenu.title}}\n            </ion-item>\n          </ion-list>\n        </ion-menu-toggle>\n      </div>\n      <div *ngIf=\"accountService.isLoggedIn()\" class=\"main-menu-item\">\n        <ion-item lines=\"none\" (click)=\"logOut()\">\n          <ion-icon color=\"dark\" name=\"log-out\" slot=\"start\"></ion-icon>\n          Log Out\n        </ion-item>\n      </div>\n      </ion-list>\n    </ion-content>\n  </ion-menu>\n\n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n\n  <!-- footer void -->\n\n  <div class=\"rb-footer-void\"></div>\n</ion-app>\n");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map