(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_checkout_checkout_module_ts"],{

/***/ 2290:
/*!*****************************************************!*\
  !*** ./src/app/checkout/checkout-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckoutPageRoutingModule": () => (/* binding */ CheckoutPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _checkout_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./checkout.page */ 45247);




const routes = [
    {
        path: '',
        component: _checkout_page__WEBPACK_IMPORTED_MODULE_0__.CheckoutPage
    },
    {
        path: 'thankyou',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_checkout_thankyou_thankyou_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./thankyou/thankyou.module */ 28454)).then(m => m.ThankyouPageModule)
    }
];
let CheckoutPageRoutingModule = class CheckoutPageRoutingModule {
};
CheckoutPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CheckoutPageRoutingModule);



/***/ }),

/***/ 28400:
/*!*********************************************!*\
  !*** ./src/app/checkout/checkout.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckoutPageModule": () => (/* binding */ CheckoutPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/dropdown */ 50103);
/* harmony import */ var _checkout_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./checkout-routing.module */ 2290);
/* harmony import */ var _checkout_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./checkout.page */ 45247);








let CheckoutPageModule = class CheckoutPageModule {
};
CheckoutPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_7__.DropdownModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _checkout_routing_module__WEBPACK_IMPORTED_MODULE_0__.CheckoutPageRoutingModule
        ],
        declarations: [_checkout_page__WEBPACK_IMPORTED_MODULE_1__.CheckoutPage]
    })
], CheckoutPageModule);



/***/ }),

/***/ 45247:
/*!*******************************************!*\
  !*** ./src/app/checkout/checkout.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckoutPage": () => (/* binding */ CheckoutPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_checkout_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./checkout.page.html */ 66646);
/* harmony import */ var _checkout_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./checkout.page.scss */ 5554);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _services_cart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/cart.service */ 90910);
/* harmony import */ var _services_orders_order_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/orders/order.service */ 53675);
/* harmony import */ var _services_address_address_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/address/address.service */ 47172);
/* harmony import */ var _services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/controllers/toast.service */ 41048);
/* harmony import */ var _account_account_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../account/account.service */ 10740);



/* eslint-disable @typescript-eslint/naming-convention */








let CheckoutPage = class CheckoutPage {
    constructor(nav, loadingCtrl, toastService, cartService, addressService, accountService, orderService) {
        this.nav = nav;
        this.loadingCtrl = loadingCtrl;
        this.toastService = toastService;
        this.cartService = cartService;
        this.addressService = addressService;
        this.accountService = accountService;
        this.orderService = orderService;
        this.sendGift = false;
        this.cartLoading = true;
        this.selectedAddress = null;
        this.addressLoading = true;
    }
    ngOnInit() {
        this.giftFormInit();
        this.AddressInit();
        this.cartServiceInit();
    }
    giftFormInit() {
        this.giftForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup({
            message: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
            }),
            sender: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
            })
        });
    }
    AddressInit() {
        this.addressLoading = true;
        this.addressService.fetchAddress().subscribe(res => {
            this.addressLoading = false;
            this.selectedAddress = res.data.data.filter(address => address.default === '1')[0];
        });
        this.addressSub = this.addressService.address.subscribe(addresses => {
            this.addresses = addresses;
        });
        console.log('selected Address : ', this.selectedAddress);
    }
    cartServiceInit() {
        this.cartLoading = true;
        this.cartService.fetchCartObj().subscribe(res => {
            this.cartLoading = false;
        });
        this.cartSub = this.cartService.cartDetails.subscribe(res => {
            this.cartDetails = res;
        });
    }
    ionViewWillEnter() {
        this.cartLoading = true;
        this.cartService.fetchCartObj().subscribe(res => {
            this.cartLoading = false;
        });
        console.log('cart ion view');
        this.addressLoading = true;
        this.addressService.fetchAddress().subscribe(res => {
            this.addressLoading = false;
        });
    }
    onSelectAddress(addressId) {
        this.selectedAddress = this.addresses.filter(address => address.id === addressId)[0];
        console.log('selected Address : ', this.selectedAddress);
    }
    addNewAddress() {
        this.nav.navigateForward('account/address/add-address');
    }
    onPlacingOrder() {
        this.loadingCtrl.create({
            message: 'Placing order',
            mode: 'ios'
        }).then(el => {
            el.present();
            this.orderService.addOrder(1).subscribe(res => {
                this.loadingCtrl.dismiss();
                this.toastService.toast('Order placed successfully', 'success', 3000);
                this.nav.navigateForward('/all/orders');
            });
        });
    }
    // helper
    sendAsGift(event) {
        console.log('check box event : ', event);
        this.sendGift = !this.sendGift;
    }
    ngOnDestroy() {
        this.cartSub.unsubscribe();
        this.addressSub.unsubscribe();
    }
};
CheckoutPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: _services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _services_cart_service__WEBPACK_IMPORTED_MODULE_2__.CartService },
    { type: _services_address_address_service__WEBPACK_IMPORTED_MODULE_4__.AddressService },
    { type: _account_account_service__WEBPACK_IMPORTED_MODULE_6__.AccountService },
    { type: _services_orders_order_service__WEBPACK_IMPORTED_MODULE_3__.OrderService }
];
CheckoutPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-checkout',
        template: _raw_loader_checkout_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_checkout_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CheckoutPage);



/***/ }),

/***/ 5554:
/*!*********************************************!*\
  !*** ./src/app/checkout/checkout.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (":host ::ng-deep .p-dropdown {\n  width: 100%;\n  border-radius: 4px;\n  box-shadow: 0 8px 8px 0 #0000001c;\n  padding-left: 20px;\n  border: none;\n  border-top: 0.5px solid #0808080a;\n  border-bottom: 0;\n  border-left: 0;\n  border-right: 0;\n}\n\nion-content {\n  --background: #F5F4F9;\n}\n\n.country-item-value img.flag {\n  width: 17px;\n}\n\n.gift-box-wrapper {\n  box-shadow: inset 0px 0px 12px 6px #00000012;\n  margin: 10px 0;\n  padding: 10px 5px;\n  border-radius: 5px;\n}\n\n.gift-box-wrapper .gift-box {\n  border: 1px solid #00000024;\n  padding: 0;\n  border-radius: 2px;\n}\n\n.gift-box-wrapper .gift-box .rb-gift-textarea {\n  margin: 0;\n}\n\n.gift-box-wrapper .gift-box ion-input {\n  line-height: 2;\n}\n\n.gift-box-wrapper .gift-box .gift-box-text {\n  text-align: center;\n  font-weight: bold;\n  color: #888;\n}\n\n.payment-section {\n  border: 1px solid #5effb4;\n  padding: 10px;\n  border-radius: 10px;\n}\n\n.payment-section .order-review-section {\n  display: flex;\n  flex-direction: column;\n  color: #666;\n}\n\n.payment-section .order-review-section .shipping-cost-section {\n  display: flex;\n  flex-direction: row;\n}\n\n.payment-section .order-review-section .shipping-cost-section .shipping-label {\n  width: 40%;\n}\n\n.payment-section .order-review-section .shipping-cost-section .shipping-total {\n  width: 60%;\n  text-align: right;\n  padding-right: 10px;\n}\n\n.payment-section .order-review-section .order-amount-section {\n  display: flex;\n  flex-direction: row;\n}\n\n.payment-section .order-review-section .order-amount-section .total-ordered-amount-text {\n  width: 40%;\n}\n\n.payment-section .order-review-section .order-amount-section .total-ordered-amount {\n  width: 60%;\n  text-align: right;\n  padding-right: 10px;\n}\n\n.payment-section .order-review-section .grand-total-section {\n  display: flex;\n  flex-direction: row;\n  font-weight: bold;\n  color: #333;\n}\n\n.payment-section .order-review-section .grand-total-section .grand-total-label {\n  width: 40%;\n}\n\n.payment-section .order-review-section .grand-total-section .grand-total-amount {\n  width: 60%;\n  text-align: right;\n  padding-right: 10px;\n}\n\n.payment-section .payment-method-section {\n  margin-top: 15px;\n  border-radius: 10px;\n}\n\n.payment-section .payment-method-section ion-label {\n  padding-left: 10px;\n}\n\n.checkout ion-button {\n  margin-top: 20px;\n  --border-radius: 10px;\n}\n\n.rb-input-shadow {\n  --padding-start: 20px;\n  --padding-end: 10px;\n  margin: 10px 10px 10px auto;\n  border-radius: 4px;\n  box-shadow: 0 8px 8px 0 #0000001c;\n  border-top: 0.5px solid #0808080a;\n  color: #4c4a4a;\n  background: #fff;\n  margin-bottom: 15px;\n}\n\nion-note {\n  text-align: left;\n  margin: auto;\n  display: block;\n  padding-left: 20px;\n}\n\n.address {\n  margin-left: 10px;\n}\n\n.spinner {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoZWNrb3V0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBSEo7O0FBTUE7RUFDRSxxQkFBQTtBQUhGOztBQU9JO0VBQ0ksV0FBQTtBQUpSOztBQVFBO0VBQ0UsNENBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUxGOztBQU9FO0VBQ0UsMkJBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7QUFMSjs7QUFPSTtFQUVFLFNBQUE7QUFOTjs7QUFRSTtFQUNFLGNBQUE7QUFOTjs7QUFRSTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0FBTk47O0FBbUJFO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFoQko7O0FBa0JJO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtBQWhCTjs7QUFrQk07RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUFoQlI7O0FBa0JRO0VBQ0UsVUFBQTtBQWhCVjs7QUFrQlE7RUFDRSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQWhCVjs7QUFtQk07RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUFqQlI7O0FBbUJRO0VBQ0UsVUFBQTtBQWpCVjs7QUFtQlE7RUFDRSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQWpCVjs7QUFxQk07RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7QUFuQlI7O0FBcUJRO0VBQ0UsVUFBQTtBQW5CVjs7QUFxQlE7RUFDRSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQW5CVjs7QUF3Qkk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0FBdEJOOztBQXdCTTtFQUNFLGtCQUFBO0FBdEJSOztBQWtDRTtFQUNFLGdCQUFBO0VBQ0EscUJBQUE7QUEvQko7O0FBbUNBO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsY0E5SWM7RUErSWQsZ0JBQUE7RUFDQSxtQkFBQTtBQWhDRjs7QUFtQ0E7RUFDRSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFoQ0Y7O0FBa0NBO0VBQ0UsaUJBQUE7QUEvQkY7O0FBa0NBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQS9CRiIsImZpbGUiOiJjaGVja291dC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIkYm94U2hhZG93OiAjMDAwMDAwMWM7XHJcbiRib3JkZXJUb3A6ICMwODA4MDgwYTtcclxuJGlvbklucHV0Q29sb3I6ICM0YzRhNGE7XHJcblxyXG46aG9zdCA6Om5nLWRlZXAgLnAtZHJvcGRvd24ge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDhweCA4cHggMCAkYm94U2hhZG93O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyMHB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYm9yZGVyLXRvcDogMC41cHggc29saWQgJGJvcmRlclRvcDtcclxuICAgIGJvcmRlci1ib3R0b206IDA7XHJcbiAgICBib3JkZXItbGVmdDogMDtcclxuICAgIGJvcmRlci1yaWdodDogMDtcclxufVxyXG5cclxuaW9uLWNvbnRlbnR7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjRjVGNEY5O1xyXG5cclxufVxyXG4uY291bnRyeS1pdGVtLXZhbHVlIHtcclxuICAgIGltZy5mbGFnIHtcclxuICAgICAgICB3aWR0aDogMTdweDtcclxuICAgIH1cclxufVxyXG5cclxuLmdpZnQtYm94LXdyYXBwZXJ7XHJcbiAgYm94LXNoYWRvdzogaW5zZXQgMHB4IDBweCAxMnB4IDZweCAjMDAwMDAwMTI7XHJcbiAgbWFyZ2luOiAxMHB4IDA7XHJcbiAgcGFkZGluZzogMTBweCA1cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG5cclxuICAuZ2lmdC1ib3gge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDAwMDI0O1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcclxuXHJcbiAgICAucmItZ2lmdC10ZXh0YXJlYXtcclxuICAgICAgLy9ib3JkZXI6IDFweCBzb2xpZCAjODg4O1xyXG4gICAgICBtYXJnaW46IDA7XHJcbiAgICB9XHJcbiAgICBpb24taW5wdXR7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAyO1xyXG4gICAgfVxyXG4gICAgLmdpZnQtYm94LXRleHR7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgIGNvbG9yOiAjODg4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuXHJcblxyXG4vLyAucmItZ2lmdC1pbnB1dHtcclxuLy8gICBib3JkZXI6IDFweCBzb2xpZCAjODg4O1xyXG4vLyAgIGJvcmRlci1yYWRpdXM6IG5vbmU7XHJcbi8vIH1cclxuXHJcbi8vI0Y1RjRGOVxyXG4gIC5wYXltZW50LXNlY3Rpb257XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjNWVmZmI0O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblxyXG4gICAgLm9yZGVyLXJldmlldy1zZWN0aW9ue1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICBjb2xvcjogIzY2NjtcclxuXHJcbiAgICAgIC5zaGlwcGluZy1jb3N0LXNlY3Rpb257XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG5cclxuICAgICAgICAuc2hpcHBpbmctbGFiZWx7XHJcbiAgICAgICAgICB3aWR0aDogNDAlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuc2hpcHBpbmctdG90YWx7XHJcbiAgICAgICAgICB3aWR0aDogNjAlO1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAub3JkZXItYW1vdW50LXNlY3Rpb257XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG5cclxuICAgICAgICAudG90YWwtb3JkZXJlZC1hbW91bnQtdGV4dHtcclxuICAgICAgICAgIHdpZHRoOiA0MCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC50b3RhbC1vcmRlcmVkLWFtb3VudHtcclxuICAgICAgICAgIHdpZHRoOiA2MCU7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICAuZ3JhbmQtdG90YWwtc2VjdGlvbntcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgY29sb3I6ICMzMzM7XHJcblxyXG4gICAgICAgIC5ncmFuZC10b3RhbC1sYWJlbHtcclxuICAgICAgICAgIHdpZHRoOiA0MCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5ncmFuZC10b3RhbC1hbW91bnR7XHJcbiAgICAgICAgICB3aWR0aDogNjAlO1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5wYXltZW50LW1ldGhvZC1zZWN0aW9ue1xyXG4gICAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5cclxuICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbi5jaGVja291dCB7XHJcbiAgLy9tYXJnaW46IDIwcHg7XHJcblxyXG5cclxuXHJcblxyXG5cclxuICBpb24tYnV0dG9ue1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogMTBweDtcclxuICB9XHJcbn1cclxuXHJcbi5yYi1pbnB1dC1zaGFkb3d7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAyMHB4O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XHJcbiAgbWFyZ2luOiAxMHB4IDEwcHggMTBweCBhdXRvO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBib3gtc2hhZG93OiAwIDhweCA4cHggMCAkYm94U2hhZG93O1xyXG4gIGJvcmRlci10b3A6IDAuNXB4IHNvbGlkICRib3JkZXJUb3A7XHJcbiAgY29sb3I6ICRpb25JbnB1dENvbG9yO1xyXG4gIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufVxyXG5cclxuaW9uLW5vdGV7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgcGFkZGluZy1sZWZ0OiAyMHB4O1xyXG59XHJcbi5hZGRyZXNzIHtcclxuICBtYXJnaW4tbGVmdDogMTBweDtcclxufVxyXG5cclxuLnNwaW5uZXJ7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 66646:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/checkout/checkout.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"warning\" class=\"ion-text-center\">\n    <ion-title>Checkout</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <!-- address section -->\n    <ion-row *ngIf=\"addressLoading\">\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!addressLoading && selectedAddress\">\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <ion-list>\n          <ion-radio-group #address color=\"warning\" [value]=\"selectedAddress.id\" (ionChange)=\"onSelectAddress(address.value)\">\n            <ion-list-header>\n              <ion-label>\n                Select Address\n              </ion-label>\n            </ion-list-header>\n\n            <ion-item *ngFor=\"let address of addresses\">\n              <ion-radio color=\"warning\" [value]=\"address.id\"></ion-radio>\n              <ion-label class=\"address\">\n                <p> {{address.name}} : {{address.phone}}</p>\n                <p> {{address.address}}, {{address.city}}, {{address.area}}, {{address.division}}</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item (click)=\"addNewAddress()\">\n              <ion-buttons>\n                <ion-button>\n                  <ion-icon slot=\"icon-only\" color=\"tertiary\" name=\"add\"></ion-icon>\n                </ion-button>\n              </ion-buttons>\n              <ion-label color=\"tertiary\" class=\"address\"> Add different address</ion-label>\n            </ion-item>\n\n          </ion-radio-group>\n\n        </ion-list>\n        <!-- <ion-card [ngClass]=\"{'active': address.default==='1'}\">\n          <ion-card-header class='card-header'>\n            <ion-checkbox [checked]=\"address.default==='1'\" [value]=\"address.id\"></ion-checkbox>\n            {{address.type}}\n            <span *ngIf=\"address.default==='1'\"> (Default Address) </span>\n          </ion-card-header>\n          <ion-card-content>\n            <ion-label>\n              <p>{{address.name}} : {{address.phone}}</p>\n              <p>{{address.address}}, {{address.city}}, {{address.area}}, {{address.division}}</p>\n            </ion-label>\n          </ion-card-content>\n        </ion-card> -->\n      </ion-col>\n    </ion-row>\n    <!-- address section ends -->\n    <ion-row>\n      <!-- <ion-col size=\"12\" sizeSm=\"6\" sizeMd=\"6\">\n        <div class=\"checkout\">\n          <form [formGroup]=\"checkoutForm\">\n            <div class=\"name-section\">\n              <ion-input class=\"rb-input-shadow\" formControlName=\"name\" placeholder=\"Full Name\"></ion-input>\n               <ion-note *ngIf=\"checkoutForm.controls.phone.invalid && (checkoutForm.controls.phone.dirty || checkoutForm.controls.phone.touched)\" color=\"danger\" slot=\"end\">valid phone number required !</ion-note>\n              <ion-input class=\"rb-input-shadow\" maxLength=\"11\" formControlName=\"phone\" placeholder=\"Phone number\"></ion-input>\n              <ion-note *ngIf=\"checkoutForm.controls.email.invalid && (checkoutForm.controls.email.dirty || checkoutForm.controls.email.touched)\" color=\"danger\" slot=\"end\">valid email address required !</ion-note>\n              <ion-input class=\"rb-input-shadow\" formControlName=\"email\" type=\"email\" placeholder=\"email\"></ion-input>\n            </div>\n            <div class=\"address-section\">\n              <ion-input class=\"rb-input-shadow\" formControlName=\"address\" placeholder=\"house, street, local Address\"></ion-input>\n            </div>\n          </form>\n          <p-dropdown (onChange)=\"onChangeArea()\" [options]=\"area\" [(ngModel)]=\"selectedArea\" optionLabel=\"name\" [filter]=\"true\" filterBy=\"name\" [showClear]=\"true\" placeholder=\"Select Area\">\n                <ng-template pTemplate=\"selectedItem\">\n                    <div class=\"country-item country-item-value\"  *ngIf=\"selectedArea\">\n\n                        <div>{{selectedArea.name}}</div>\n                    </div>\n                </ng-template>\n          </p-dropdown>\n        </div>\n      </ion-col> -->\n      <ion-col size=\"12\" sizeSm=\"6\" sizeMd=\"6\">\n        <form [formGroup]=\"giftForm\">\n          <ion-list>\n            <ion-item>\n              <ion-checkbox (ionChange)=\"sendAsGift($event)\" [checked]=\"sendGift\" mode=\"ios\" color=\"warning\" ></ion-checkbox>\n              <ion-label color=\"dark\"> Send as gift </ion-label>\n            </ion-item>\n          </ion-list>\n          <ion-grid *ngIf=\"sendGift\" class=\"ion-no-padding\">\n            <ion-row class=\"gift-box-wrapper\">\n              <ion-label color=\"tertiary\">Gift message</ion-label>\n              <ion-col size=\"12\" class=\"gift-box\">\n                <ion-textarea formControlName=\"message\" class=\"rb-gift-textarea\" placeholder=\"write something...\" autofocus=\"true\"></ion-textarea>\n              </ion-col>\n              <ion-col size=\"2\" class=\"gift-box\">\n                <p class=\"gift-box-text\" >From</p>\n              </ion-col>\n              <ion-col size=\"10\" class=\"gift-box\">\n                  <ion-input formControlName=\"sender\"></ion-input>\n              </ion-col>\n              <ion-col>\n                <ion-list>\n                  <ion-item>\n                    <ion-checkbox (ionChange)=\"sendAsGift($event)\" [checked]=\"sendGift\" mode=\"ios\" color=\"warning\" ></ion-checkbox>\n                    <ion-label color=\"dark\"> add special packaging </ion-label>\n                  </ion-item>\n                </ion-list>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n\n          <!-- ddd -->\n\n          <!-- ddd -->\n        </form>\n        <div >\n          <div class=\"payment-section\">\n            <div *ngIf=\"cartLoading\" class=\"order-amount-section\">\n              <div class=\"spinner\">\n                <ion-spinner color=\"warning\"></ion-spinner>\n              </div>\n            </div>\n            <div *ngIf=\"!cartLoading\" class=\"order-review-section\">\n              <div class=\"order-amount-section\">\n                <div class=\"total-ordered-amount-text\">\n                  Sub-total\n                </div>\n                <div class=\"total-ordered-amount\">\n                  BDT {{cartDetails.data.subtotal}}\n                </div>\n              </div>\n\n              <div class=\"shipping-cost-section\">\n                <div class=\"shipping-label\">\n                  Shipping cost\n                </div>\n                <div class=\"shipping-total\">\n                  BDT {{cartDetails.data.shippingTotal}}\n                </div>\n              </div>\n\n              <div class=\"grand-total-section\">\n                <div class=\"grand-total-label\">\n                  Grand Total\n                </div>\n                <div class=\"grand-total-amount\">\n                  BDT {{cartDetails.data.grandTotal}}\n                </div>\n              </div>\n            </div>\n            <div class=\"payment-method-section\">\n              <ion-list>\n                <ion-radio-group #payment color=\"warning\" value=\"cod\" (ionChange)=\"onChangePayment(payment.value)\">\n                  <ion-list-header>\n                    <ion-label>\n                      Select Payment Method\n                    </ion-label>\n                  </ion-list-header>\n\n                  <ion-item>\n                    <ion-radio color=\"warning\" value=\"cod\"></ion-radio>\n                    <ion-label>Cash on delivery</ion-label>\n                  </ion-item>\n\n                  <!-- <ion-item>\n                    <ion-radio color=\"warning\" value=\"sslcommerz\"></ion-radio>\n                    <ion-label>SSLCOMMERZ (pay online)</ion-label>\n                  </ion-item> -->\n                </ion-radio-group>\n              </ion-list>\n            </div>\n          </div>\n          <ion-button [disabled]=\"cartLoading && addressLoading\" color=\"warning\" expand=\"full\" (click)=\"onPlacingOrder()\">Place Order</ion-button>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_checkout_checkout_module_ts.js.map