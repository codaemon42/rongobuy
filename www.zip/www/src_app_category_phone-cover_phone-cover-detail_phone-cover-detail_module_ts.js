(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_category_phone-cover_phone-cover-detail_phone-cover-detail_module_ts"],{

/***/ 81776:
/*!**********************************************************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover-detail/phone-cover-detail-routing.module.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneCoverDetailPageRoutingModule": () => (/* binding */ PhoneCoverDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _phone_cover_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./phone-cover-detail.page */ 67226);




const routes = [
    {
        path: '',
        component: _phone_cover_detail_page__WEBPACK_IMPORTED_MODULE_0__.PhoneCoverDetailPage
    },
    {
        path: 'specific',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_category_phone-cover_phone-cover-detail_specific_specific_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./specific/specific.module */ 36223)).then(m => m.SpecificPageModule)
    }
];
let PhoneCoverDetailPageRoutingModule = class PhoneCoverDetailPageRoutingModule {
};
PhoneCoverDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PhoneCoverDetailPageRoutingModule);



/***/ }),

/***/ 89335:
/*!**************************************************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover-detail/phone-cover-detail.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneCoverDetailPageModule": () => (/* binding */ PhoneCoverDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _phone_cover_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./phone-cover-detail-routing.module */ 81776);
/* harmony import */ var _phone_cover_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-cover-detail.page */ 67226);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);








let PhoneCoverDetailPageModule = class PhoneCoverDetailPageModule {
};
PhoneCoverDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _phone_cover_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.PhoneCoverDetailPageRoutingModule
        ],
        declarations: [_phone_cover_detail_page__WEBPACK_IMPORTED_MODULE_1__.PhoneCoverDetailPage]
    })
], PhoneCoverDetailPageModule);



/***/ }),

/***/ 67226:
/*!************************************************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover-detail/phone-cover-detail.page.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneCoverDetailPage": () => (/* binding */ PhoneCoverDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_phone_cover_detail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./phone-cover-detail.page.html */ 13194);
/* harmony import */ var _phone_cover_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-cover-detail.page.scss */ 97302);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var src_app_services_phone_cover_phone_cover_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/phone-cover/phone-cover.service */ 70672);
/* harmony import */ var src_app_services_category_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/category.service */ 54655);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var src_app_services_products_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/products.service */ 29531);









let PhoneCoverDetailPage = class PhoneCoverDetailPage {
    constructor(loadingCtrl, categoryService, phoneCoverService, router, productsService, nav) {
        this.loadingCtrl = loadingCtrl;
        this.categoryService = categoryService;
        this.phoneCoverService = phoneCoverService;
        this.router = router;
        this.productsService = productsService;
        this.nav = nav;
        this.isDisplay = false;
        this.backgroundImage = null;
    }
    ngOnInit() {
        //this.closeLoader();
        this.categoryService.fetchCategories().subscribe();
        this.router.params.subscribe(res => {
            console.log(res.slug);
            this.catSub = this.categoryService.categories.subscribe(categories => {
                this.getCategory(categories, res.slug).then(phoneCat => {
                    this.phoneCoverCatChild = phoneCat;
                    console.log('this.phoneCoverCatChild : ', this.phoneCoverCatChild);
                });
            });
        });
        this.fetchPhoneCovers();
    }
    getCategory(categories, slug) {
        return new Promise(resolve => {
            categories.map(cat => {
                if (cat.slug === 'phone-cover') {
                    cat.child.map(phoneCat => {
                        if (phoneCat.slug === slug) {
                            resolve(phoneCat.child);
                        }
                    });
                }
            });
        });
    }
    closeLoader() {
        this.loadingCtrl.dismiss();
    }
    onSelectImage(slug) {
        this.isDisplay = true;
        this.productsService.fetchProductsByCat(slug).subscribe(products => {
            this.product = products.data.data[0];
            this.backgroundImage = products.data.data[0].mainImage;
        });
    }
    fetchPhoneCovers() {
        this.phoneCoverSub = this.phoneCoverService.phoneCovers.subscribe(data => {
            this.phoneCovers = data;
            console.log('this fn cover : ', this.phoneCovers);
        });
        this.phoneCoverService.fetchPhoneCoversByFilter().subscribe(data => {
            console.log('fetch fn covers : ', data);
        });
    }
    onSelectProductModel(event) {
        console.log('selected backGround : ', this.phoneCovers[event]);
        this.productsService.addSelectedProductBackground(this.phoneCovers[event].image);
        this.nav.navigateForward(`products/${this.product.slug}`);
    }
    ngOnDestroy() {
        this.catSub.unsubscribe();
        this.phoneCoverSub.unsubscribe();
    }
};
PhoneCoverDetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: src_app_services_category_service__WEBPACK_IMPORTED_MODULE_3__.CategoryService },
    { type: src_app_services_phone_cover_phone_cover_service__WEBPACK_IMPORTED_MODULE_2__.PhoneCoverService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: src_app_services_products_service__WEBPACK_IMPORTED_MODULE_4__.ProductsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController }
];
PhoneCoverDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-phone-cover-detail',
        template: _raw_loader_phone_cover_detail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_phone_cover_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PhoneCoverDetailPage);



/***/ }),

/***/ 70672:
/*!*************************************************************!*\
  !*** ./src/app/services/phone-cover/phone-cover.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneCoverService": () => (/* binding */ PhoneCoverService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 68307);






let PhoneCoverService = class PhoneCoverService {
    constructor(http) {
        this.http = http;
        this._phoneCovers = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
    }
    get phoneCovers() {
        return this._phoneCovers.asObservable();
    }
    fetchPhoneCovers(data = []) {
        const body = {
            type: 'phone-cover',
            gender: null,
            phoneModel: null
        };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/setting/get-phone-cover`, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)(res => {
            this._phoneCovers.next(data.concat(res.data.data));
        }));
    }
    fetchPhoneCoversByFilter(gender = null, phoneModel = null, data = []) {
        const body = {
            type: 'phone-cover',
            gender,
            phoneModel
        };
        console.log(body);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/setting/get-phone-cover`, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)(res => {
            this._phoneCovers.next(data.concat(res.data.data));
        }));
    }
};
PhoneCoverService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient }
];
PhoneCoverService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], PhoneCoverService);



/***/ }),

/***/ 97302:
/*!**************************************************************************************!*\
  !*** ./src/app/category/phone-cover/phone-cover-detail/phone-cover-detail.page.scss ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwaG9uZS1jb3Zlci1kZXRhaWwucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 13194:
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/category/phone-cover/phone-cover-detail/phone-cover-detail.page.html ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"warning\">\n    <ion-title class=\"ion-text-center\">Models</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-grid *ngIf=\"!isDisplay\" class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col size=\"6\" sizeSm=\"6\" sizeMd=\"3\" (click)=\"onSelectImage(cat.slug)\" *ngFor=\"let cat of phoneCoverCatChild\">\n        <ion-card>\n          <ion-img [src]=\"cat.image\"></ion-img>\n          <ion-card-subtitle class=\"subtitle ion-text-center\">{{cat.categoryName}}</ion-card-subtitle>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid *ngIf=\"isDisplay\">\n    <ion-row>\n      <ion-col>\n        <app-phone-display [categoryImages]=\"phoneCovers\" [backgroundImage]=\"backgroundImage\" (selectedBackground)=\"onSelectProductModel($event)\"></app-phone-display>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_category_phone-cover_phone-cover-detail_phone-cover-detail_module_ts.js.map