(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_account_address_address_module_ts"],{

/***/ 78812:
/*!***********************************************************!*\
  !*** ./src/app/account/address/address-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddressPageRoutingModule": () => (/* binding */ AddressPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _address_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./address.page */ 665);




const routes = [
    {
        path: '',
        component: _address_page__WEBPACK_IMPORTED_MODULE_0__.AddressPage
    },
    {
        path: 'add-address',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_account_address_add-address_add-address_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./add-address/add-address.module */ 36510)).then(m => m.AddAddressPageModule)
    },
    {
        path: 'edit-address',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_account_address_edit-address_edit-address_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./edit-address/edit-address.module */ 28737)).then(m => m.EditAddressPageModule)
    }
];
let AddressPageRoutingModule = class AddressPageRoutingModule {
};
AddressPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddressPageRoutingModule);



/***/ }),

/***/ 65107:
/*!***************************************************!*\
  !*** ./src/app/account/address/address.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddressPageModule": () => (/* binding */ AddressPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _address_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./address-routing.module */ 78812);
/* harmony import */ var _address_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./address.page */ 665);







let AddressPageModule = class AddressPageModule {
};
AddressPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _address_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddressPageRoutingModule
        ],
        declarations: [_address_page__WEBPACK_IMPORTED_MODULE_1__.AddressPage]
    })
], AddressPageModule);



/***/ }),

/***/ 665:
/*!*************************************************!*\
  !*** ./src/app/account/address/address.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddressPage": () => (/* binding */ AddressPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_address_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./address.page.html */ 295);
/* harmony import */ var _address_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./address.page.scss */ 10213);
/* harmony import */ var _edit_address_edit_address_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-address/edit-address.page */ 71486);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_services_address_address_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/address/address.service */ 47172);







let AddressPage = class AddressPage {
    constructor(addressService, modalCtrl) {
        this.addressService = addressService;
        this.modalCtrl = modalCtrl;
        this.addresses = [];
        this.addressLoading = true;
    }
    ngOnInit() {
        this.getAddress();
        this.addressSub = this.addressService.address.subscribe(addresses => {
            this.addresses = addresses;
        });
    }
    getAddress() {
        this.addressLoading = true;
        this.addressService.fetchAddress().subscribe(res => {
            this.addressLoading = false;
        });
    }
    onEdit(address) {
        this.modalCtrl.create({
            component: _edit_address_edit_address_page__WEBPACK_IMPORTED_MODULE_2__.EditAddressPage,
            componentProps: {
                defaultValues: address
            }
        }).then(el => el.present());
    }
    // ionViewWillEnter(){
    //   this.getAddress();
    // }
    ngOnDestroy() {
        this.addressSub.unsubscribe();
    }
};
AddressPage.ctorParameters = () => [
    { type: src_app_services_address_address_service__WEBPACK_IMPORTED_MODULE_3__.AddressService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController }
];
AddressPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-address',
        template: _raw_loader_address_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_address_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddressPage);



/***/ }),

/***/ 71486:
/*!*******************************************************************!*\
  !*** ./src/app/account/address/edit-address/edit-address.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditAddressPage": () => (/* binding */ EditAddressPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_edit_address_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./edit-address.page.html */ 62331);
/* harmony import */ var _edit_address_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-address.page.scss */ 39100);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _services_address_address_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/address/address.service */ 47172);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var src_app_services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/controllers/toast.service */ 41048);








let EditAddressPage = class EditAddressPage {
    constructor(addressService, modalCtrl, loadingCtrl, toastService) {
        this.addressService = addressService;
        this.modalCtrl = modalCtrl;
        this.loadingCtrl = loadingCtrl;
        this.toastService = toastService;
        this.defaultGender = 'female';
    }
    ngOnInit() {
        this.editAddressForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroup({
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.name, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.email, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.email, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.phone, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.address, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            city: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.city, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            area: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.area, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            division: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.division, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            additional: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.additional, {
                updateOn: 'change'
            }),
            type: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.type, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            }),
            default: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.defaultValues.default, {
                updateOn: 'change'
            })
        });
    }
    closeModal() {
        this.modalCtrl.dismiss();
    }
    updateProfile() {
        console.log(this.editAddressForm);
        this.loadingCtrl.create({
            message: 'Adding Address...',
            mode: 'ios'
        }).then(el => el.present());
        this.addressService.updateAddress(this.defaultValues.id, this.editAddressForm.value).subscribe(res => {
            console.log('updated address : ', res);
            this.loadingCtrl.dismiss();
            if (res.success) {
                this.toastService.toast('address Updated successfully', 'success', 2000);
                this.closeModal();
            }
            else {
                this.toastService.toast('something went wrong. try again', 'danger', 2000);
            }
        });
    }
};
EditAddressPage.ctorParameters = () => [
    { type: _services_address_address_service__WEBPACK_IMPORTED_MODULE_2__.AddressService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: src_app_services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_3__.ToastService }
];
EditAddressPage.propDecorators = {
    defaultValues: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }]
};
EditAddressPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-edit-address',
        template: _raw_loader_edit_address_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_edit_address_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EditAddressPage);



/***/ }),

/***/ 10213:
/*!***************************************************!*\
  !*** ./src/app/account/address/address.page.scss ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-input {\n  border-radius: 5px;\n  box-shadow: 0 5px 5px #0000002b;\n  margin: 10px 0;\n  padding: 5px 10px;\n}\n\n.birthday {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  padding: 5px 10px;\n  border-radius: 5px;\n  box-shadow: 0 8px 8px #0000002b;\n}\n\n.gender {\n  margin-top: 20px;\n  margin-bottom: 20px;\n  box-shadow: 0 8px 8px #0000002b;\n}\n\n.active {\n  border: 1px solid var(--ion-color-danger);\n}\n\n.card-header {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.spinner {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZHJlc3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0Usa0JBQUE7RUFDQSwrQkFBQTtFQUNBLGNBQUE7RUFFQSxpQkFBQTtBQURKOztBQUlFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQkFBQTtBQURKOztBQUlFO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLCtCQUFBO0FBREo7O0FBSUU7RUFDRSx5Q0FBQTtBQURKOztBQUlBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQURGOztBQUdBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFGIiwiZmlsZSI6ImFkZHJlc3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW9uLWlucHV0e1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA1cHggNXB4ICMwMDAwMDAyYjtcclxuICAgIG1hcmdpbjogMTBweCAwO1xyXG5cclxuICAgIHBhZGRpbmc6IDVweCAxMHB4O1xyXG4gIH1cclxuXHJcbiAgLmJpcnRoZGF5IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDVweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA4cHggOHB4ICMwMDAwMDAyYjtcclxuICB9XHJcblxyXG4gIC5nZW5kZXJ7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgIGJveC1zaGFkb3c6IDAgOHB4IDhweCAjMDAwMDAwMmI7XHJcbiAgfVxyXG5cclxuICAuYWN0aXZlIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xyXG4gIH1cclxuXHJcbi5jYXJkLWhlYWRlcntcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLnNwaW5uZXJ7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 39100:
/*!*********************************************************************!*\
  !*** ./src/app/account/address/edit-address/edit-address.page.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-input {\n  border-radius: 5px;\n  box-shadow: 0 5px 5px #0000002b;\n  margin: 10px 0;\n  padding: 5px 10px;\n}\n\n.birthday {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  padding: 5px 10px;\n  border-radius: 5px;\n  box-shadow: 0 8px 8px #0000002b;\n}\n\n.gender {\n  margin-top: 20px;\n  margin-bottom: 20px;\n  box-shadow: 0 8px 8px #0000002b;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVkaXQtYWRkcmVzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxrQkFBQTtFQUNBLCtCQUFBO0VBQ0EsY0FBQTtFQUVBLGlCQUFBO0FBREo7O0FBSUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLCtCQUFBO0FBREo7O0FBSUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsK0JBQUE7QUFESiIsImZpbGUiOiJlZGl0LWFkZHJlc3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW9uLWlucHV0e1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA1cHggNXB4ICMwMDAwMDAyYjtcclxuICAgIG1hcmdpbjogMTBweCAwO1xyXG5cclxuICAgIHBhZGRpbmc6IDVweCAxMHB4O1xyXG4gIH1cclxuXHJcbiAgLmJpcnRoZGF5IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDVweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA4cHggOHB4ICMwMDAwMDAyYjtcclxuICB9XHJcblxyXG4gIC5nZW5kZXJ7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgIGJveC1zaGFkb3c6IDAgOHB4IDhweCAjMDAwMDAwMmI7XHJcbiAgfVxyXG5cclxuIl19 */");

/***/ }),

/***/ 295:
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/account/address/address.page.html ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/home\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title class=\"ion-text-center\">Address</ion-title>\n\n    <ion-buttons slot=\"end\">\n      <ion-button [routerLink]=\"['/', 'tabs', 'account', 'address', 'add-address']\">\n        <ion-icon slot=\"icon-only\" color=\"success\" name=\"add\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n\n  <ion-grid>\n    <ion-row *ngIf=\"addressLoading\">\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!addressLoading\">\n      <ion-col *ngFor=\"let address of addresses\" size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <ion-card [ngClass]=\"{'active': address.default==='1'}\">\n          <ion-card-header class='card-header'>\n            {{address.type}}\n            <span *ngIf=\"address.default==='1'\"> (Default Address) </span>\n            <ion-buttons>\n              <ion-button (click)=\"onEdit(address)\" color=\"danger\">\n                <ion-icon name=\"create\"></ion-icon>\n              </ion-button>\n            </ion-buttons>\n          </ion-card-header>\n          <ion-card-content>\n            <ion-label>\n              <p>{{address.name}} : {{address.phone}}</p>\n              <p>{{address.address}}, {{address.city}}, {{address.area}}, {{address.division}}</p>\n            </ion-label>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ 62331:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/account/address/edit-address/edit-address.page.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"danger\" slot=\"icon-only\" (click)=\"closeModal()\">\n        <ion-icon name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <form [formGroup]=\"editAddressForm\" (ngSubmit)=\"updateProfile()\">\n          <ion-input formControlName=\"name\" type=\"text\" placeholder=\"Full Name *\"></ion-input>\n          <ion-input formControlName=\"email\" type=\"email\" placeholder=\"Email *\"></ion-input>\n          <ion-input formControlName=\"phone\" type=\"text\" placeholder=\"Phone *\"></ion-input>\n          <ion-input formControlName=\"address\" type=\"text\" placeholder=\"Address *\"></ion-input>\n          <ion-input formControlName=\"city\" type=\"text\" placeholder=\"city *\"></ion-input>\n          <ion-input formControlName=\"area\" type=\"text\" placeholder=\"area *\"></ion-input>\n          <ion-input formControlName=\"division\" type=\"text\" placeholder=\"division *\"></ion-input>\n          <ion-input formControlName=\"additional\" type=\"text\" placeholder=\"additional\"></ion-input>\n          <ion-input formControlName=\"type\" type=\"text\" placeholder=\"type (home/ofice/...etc) *\"></ion-input>\n          <ion-list>\n            <ion-item lines=\"none\">\n              <ion-label>Make this as default Address</ion-label>\n              <ion-checkbox formControlName=\"default\" slot=\"start\"></ion-checkbox>\n            </ion-item>\n          </ion-list>\n          <ion-button [disabled]=\"!editAddressForm.valid\" type=\"submit\" class=\"update-btn\" expand=\"full\" color=\"success\">Update</ion-button>\n        </form>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_account_address_address_module_ts.js.map