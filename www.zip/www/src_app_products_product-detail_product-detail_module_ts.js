(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_products_product-detail_product-detail_module_ts"],{

/***/ 53768:
/*!**************************************************************************!*\
  !*** ./src/app/products/product-detail/product-detail-routing.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDetailPageRoutingModule": () => (/* binding */ ProductDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _product_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-detail.page */ 31603);




const routes = [
    {
        path: '',
        component: _product_detail_page__WEBPACK_IMPORTED_MODULE_0__.ProductDetailPage
    }
];
let ProductDetailPageRoutingModule = class ProductDetailPageRoutingModule {
};
ProductDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProductDetailPageRoutingModule);



/***/ }),

/***/ 89881:
/*!******************************************************************!*\
  !*** ./src/app/products/product-detail/product-detail.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDetailPageModule": () => (/* binding */ ProductDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var primeng_rating__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/rating */ 48015);
/* harmony import */ var _product_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-detail-routing.module */ 53768);
/* harmony import */ var _product_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-detail.page */ 31603);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 91841);










let ProductDetailPageModule = class ProductDetailPageModule {
};
ProductDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            primeng_rating__WEBPACK_IMPORTED_MODULE_8__.RatingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule,
            _product_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProductDetailPageRoutingModule
        ],
        declarations: [_product_detail_page__WEBPACK_IMPORTED_MODULE_1__.ProductDetailPage]
    })
], ProductDetailPageModule);



/***/ }),

/***/ 31603:
/*!****************************************************************!*\
  !*** ./src/app/products/product-detail/product-detail.page.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDetailPage": () => (/* binding */ ProductDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_product_detail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./product-detail.page.html */ 1185);
/* harmony import */ var _product_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-detail.page.scss */ 99441);
/* harmony import */ var _services_wishlist_wishlist_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/wishlist/wishlist.service */ 93462);
/* harmony import */ var _account_account_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../account/account.service */ 10740);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var src_app_services_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/product.service */ 66082);
/* harmony import */ var _services_cart_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/cart.service */ 90910);
/* harmony import */ var src_app_services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/controllers/toast.service */ 41048);
/* harmony import */ var src_app_services_products_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/products.service */ 29531);












let ProductDetailPage = class ProductDetailPage {
    constructor(animationCtrl, nav, cartService, wishlistService, activatedRoute, productService, productsService, accountService, toastService) {
        this.animationCtrl = animationCtrl;
        this.nav = nav;
        this.cartService = cartService;
        this.wishlistService = wishlistService;
        this.activatedRoute = activatedRoute;
        this.productService = productService;
        this.productsService = productsService;
        this.accountService = accountService;
        this.toastService = toastService;
        this.animatorDuration = 800;
        this.rating = 4;
        this.segment = 'description';
        this.slug = 'red-light-green-light-premium-covers-available-for-all-the-phone-models-7593';
        this.slideOpts = {
            initialSlide: 0,
            slidesPerView: 1,
            speed: 400
        };
        this.selectedAttr = [];
        this.disableCartButtons = false;
        this.backGroundImage = null;
        this.wishlistColor = false;
    }
    ngOnInit() {
        this.totalCartQty = 0;
        this.cartQuantityController();
        this.activatedRoute.params.subscribe(data => {
            console.log('activated route : ', data.slug);
            this.getSingleProduct(data.slug);
        });
        this.productsService.selectedProductBackground.subscribe(res => {
            this.backGroundImage = res;
            console.log('this.backGroundImage : ', this.backGroundImage);
        });
        console.log(' on init');
        this.reviews = [
            {
                id: '1',
                user_name: 'Ovi',
                product_slug: 'product-one',
                rating: 5,
                review: 'this is the description of the review given'
            },
            {
                id: '2',
                user_name: 'Supriya',
                product_slug: 'product-one',
                rating: 5,
                review: 'this is the description of the review given'
            },
            {
                id: '3',
                user_name: 'naim',
                product_slug: 'product-one',
                rating: 5,
                review: 'this is the description of the review given'
            },
            {
                id: '4',
                user_name: 'oishe',
                product_slug: 'product-one',
                rating: 5,
                review: 'this is the description of the review given'
            },
            {
                id: '5',
                user_name: 'rasel',
                product_slug: 'product-one',
                rating: 5,
                review: 'this is the description of the review given'
            },
        ];
    }
    // ionViewWillEnter(){
    //   this.cartQuantityController();
    // }
    ngAfterViewInit() {
        // scroll to top
        this.scrollToTop(900);
        console.log('after view init');
    }
    getSingleProduct(product_slug) {
        this.productService.fetchSingleProduct(product_slug).subscribe(product => {
            console.log('product detail : ', product);
            this.singleProduct = product;
            this.selectedSKUProduct = this.singleProduct.skuModule.skuPriceList[0];
            const propValues = this.singleProduct.skuModule.skuPriceList[0].skuPropValIds;
            this.singleProduct.skuModule.productSKUPropertyList.map(res => {
                res.skuPropertyValues.map(pVal => {
                    pVal['active'] = false;
                    if (this.inCommaArray(pVal.propertyValueId, propValues)) {
                        pVal['active'] = true;
                    }
                });
            });
        });
    }
    /**
     * observe segment change event and scroll to a point
     *
     * @param event
     * @return void
     */
    segmentChanged(event) {
        console.log(event.target.value);
        if (event.target.value) {
            this.segment = event.target.value;
            this.content.scrollToPoint(200, 300, 1500);
        }
    }
    /**
     * controls all activity on cart product clicking add to cart button
     * start animation
     * play animation
     * increase cart quantity on completing the animation
     *
     * @since 1.0.0
     *
     * return void
     */
    addToCart() {
        this.animation();
        this.animator.play();
        if (this.accountService.isLoggedIn()) {
            this.cartAdder();
        }
        else {
            this.nav.navigateForward('tabs/carts');
        }
        console.log('carted');
    }
    buyNow() {
        this.addToCart();
        this.nav.navigateForward('carts');
    }
    addToWishlist() {
        this.wishlistColor = !this.wishlistColor;
        this.wishlistService.addToWishlist(this.singleProduct.id, this.selectedSKUProduct.SkuId, this.backGroundImage).subscribe(res => {
            if (res.success) {
                this.toastService.toast('added to wishlist', 'success', 2000);
            }
            else {
                this.wishlistColor = !this.wishlistColor;
                this.toastService.toast(res.message, 'danger', 2000);
            }
        });
    }
    genarateSKU(skuModule) {
        const productSKUPropertyList = skuModule.productSKUPropertyList; // Attributes
        const skuPriceList = skuModule.skuPriceList; // products
        const newAttributeProductArray = [];
    }
    getAttr(attrIndex, attrValIndex, propertyValueId) {
        this.selectedAttr = [];
        this.checkAvailability(attrIndex, attrValIndex, propertyValueId).then(resp => {
            const promised = resp;
            if (promised.success) {
                this.disableCartButtons = false;
                this.singleProduct.skuModule.productSKUPropertyList.map((property, index) => {
                    if (attrIndex === index) {
                        property.skuPropertyValues.map((value, valIndex) => {
                            value['active'] = false;
                            if (valIndex === attrValIndex && value.propertyValueId === propertyValueId) {
                                value['active'] = true;
                            }
                        });
                    }
                });
                console.log('selectedPropertyValIds : ', promised.selectedPropertyValIds);
                this.getSelectedProduct(promised.selectedPropertyValIds);
                console.log('selected attr  :', this.singleProduct.skuModule.productSKUPropertyList);
            }
            else {
                // toast
                this.disableCartButtons = true;
                this.toastService.toast('sorry this variation not available...', 'danger', 2000);
            }
        });
    }
    checkAvailability(attrIndex, attrValIndex, propertyValueId) {
        return new Promise(resolve => {
            const selectedPropertyValIds = [];
            this.singleProduct.skuModule.productSKUPropertyList.map((property, index) => {
                if (attrIndex === index) {
                    property.skuPropertyValues.map((value, valIndex) => {
                        value['active'] = false;
                        if (valIndex === attrValIndex && value.propertyValueId === propertyValueId) {
                            value['active'] = true;
                            selectedPropertyValIds.push(value.propertyValueId);
                        }
                    });
                }
                else {
                    property.skuPropertyValues.map((value, valIndex) => {
                        if (value['active']) {
                            selectedPropertyValIds.push(value.propertyValueId);
                        }
                    });
                }
            });
            const propValIds = selectedPropertyValIds.toString();
            const data = this.singleProduct.skuModule.skuPriceList.filter(skuProduct => skuProduct.skuPropValIds === propValIds);
            if (data.length > 0) {
                resolve({
                    success: true,
                    selectedPropertyValIds: propValIds
                });
            }
            else {
                resolve({
                    success: false,
                    selectedPropertyValIds: propValIds
                });
            }
        });
    }
    getSelectedProduct(propValIds) {
        this.singleProduct.skuModule.skuPriceList.map((item, index) => {
            if (item.skuPropValIds === propValIds) {
                this.selectedSKUProduct = item;
            }
        });
    }
    ngOnDestroy() {
        this.cartQtySub.unsubscribe();
    }
    // helper
    inCommaArray(value, stringComma) {
        if (stringComma.split(',').indexOf(value) === -1) {
            return false;
        }
        else {
            return true;
        }
    }
    /**
     * scroll to a point
     *
     * @param position | number
     *
     * @return void
     */
    scrollToTop(position) {
        setTimeout(() => {
            this.content.scrollToTop(position);
            console.log('timeout');
        }, 500);
    }
    /**
     * increase cart item by 1 on click add to cart button
     * calls cartsService f(addCartItem)
     * update cartService carted amount
     */
    cartAdder() {
        this.totalCartQty += 1;
        console.log('product-detail cartAdder');
        const skuId = `${this.singleProduct.id}-green`;
        this.cartService.addTOCart(this.singleProduct.id, this.selectedSKUProduct.SkuId, 1, this.backGroundImage).subscribe();
        console.log(this.singleProduct.id, this.selectedSKUProduct.SkuId, this.backGroundImage);
    }
    /**
     * controls the cart quantity of single product
     */
    cartQuantityController() {
        this.cartQtySub = this.cartService.cartTotalItems.subscribe(res => {
            this.totalCartQty = res;
        });
    }
    /**
     * define animation controls on click add to cart button
     */
    animation() {
        this.animator = this.animationCtrl.create()
            .addElement(document.querySelector('.square'))
            .duration(this.animatorDuration)
            .iterations(1)
            .fromTo('top', '80%', '2%')
            .fromTo('right', '10%', '12px')
            .fromTo('opacity', '0.2', '1');
    }
};
ProductDetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AnimationController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _services_cart_service__WEBPACK_IMPORTED_MODULE_5__.CartService },
    { type: _services_wishlist_wishlist_service__WEBPACK_IMPORTED_MODULE_2__.WishlistService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute },
    { type: src_app_services_product_service__WEBPACK_IMPORTED_MODULE_4__.ProductService },
    { type: src_app_services_products_service__WEBPACK_IMPORTED_MODULE_7__.ProductsService },
    { type: _account_account_service__WEBPACK_IMPORTED_MODULE_3__.AccountService },
    { type: src_app_services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService }
];
ProductDetailPage.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonContent, { static: false },] }]
};
ProductDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-product-detail',
        template: _raw_loader_product_detail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_product_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ProductDetailPage);



/***/ }),

/***/ 66082:
/*!*********************************************!*\
  !*** ./src/app/services/product.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductService": () => (/* binding */ ProductService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 88002);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 68307);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);





let ProductService = class ProductService {
    constructor(http) {
        this.http = http;
        this._product = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(null);
    }
    get product() {
        return this._product.asObservable();
    }
    fetchSingleProduct(slug) {
        return this.http.get(`http://public.rongobuy.com/api/v1/details/${slug}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(data => {
            console.log(data);
            return data.data;
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)(product => {
            console.log('product details: ', product);
            this._product.next(product);
        }));
    }
};
ProductService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient }
];
ProductService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], ProductService);



/***/ }),

/***/ 99441:
/*!******************************************************************!*\
  !*** ./src/app/products/product-detail/product-detail.page.scss ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: #ffd700;\n}\nion-content .cart-badge {\n  position: absolute;\n  top: 7px;\n  right: 10px;\n}\nion-content ion-toolbar {\n  --background: #ffd700;\n}\nion-content .fullscreen {\n  height: 100%;\n}\nion-content .fullscreen .title-wrapper {\n  z-index: 15;\n  margin-top: -20px;\n}\nion-content .fullscreen .title-wrapper .title {\n  text-align: center !important;\n  color: #000;\n  font-weight: bold;\n  text-shadow: 2px 2px 3px #0000007d;\n  font-size: 18px;\n}\nion-content .fullscreen .upper-part {\n  height: 30%;\n  display: inline;\n}\nion-content .fullscreen .upper-part ion-slides {\n  height: 350px;\n}\nion-content .fullscreen .upper-part ion-slides ion-img {\n  height: 100%;\n}\nion-content .fullscreen .bottom-part {\n  background: #fff;\n  height: 70%;\n  border-radius: 20px 20px 0 0;\n  margin-top: -200px;\n  padding-top: 200px;\n  box-shadow: 0 -2px 10px 5px #22222217;\n}\nion-content .fullscreen .bottom-part .regular-price {\n  display: flex;\n  flex-direction: column;\n  font-weight: bold;\n  font-size: 15px;\n  justify-content: center;\n}\nion-content .fullscreen .bottom-part .rating {\n  margin-right: 15px;\n}\nion-content .fullscreen .bottom-part .description {\n  background: #fff;\n  padding: 35px 15px 50px 15px;\n  letter-spacing: 1.1px;\n  line-height: 1.7;\n  font-size: 14px;\n  text-align: justify;\n}\nion-content .fullscreen .bottom-part .description ion-segment {\n  margin-bottom: 30px;\n  --background: #f8f8f8;\n}\nion-content .fullscreen .bottom-part .reviews {\n  padding: 10px;\n  border-radius: 10px;\n  box-shadow: 0 8px 8px 0 #0000001c;\n  margin-bottom: 20px;\n}\nion-content .fullscreen .bottom-part .reviews .header {\n  display: flex;\n  width: 100%;\n  flex-direction: row;\n  justify-content: left;\n  align-items: center;\n}\nion-content .fullscreen .bottom-part .reviews .header .name {\n  width: 50%;\n  color: #333;\n  font-weight: bold;\n}\nion-content .fullscreen .bottom-part .reviews .header .name ion-icon {\n  margin-right: 5px;\n}\nion-content .fullscreen .bottom-part .reviews .body {\n  color: #888;\n  font-weight: bold;\n  font-size: 12px;\n  margin-top: 10px;\n}\nion-content .actions {\n  position: fixed;\n  bottom: 0;\n  width: 100%;\n  left: 0;\n  background: #fff;\n}\nion-content .actions .square {\n  display: block;\n  width: 50px;\n  height: 50px;\n  border-radius: 50%;\n  position: fixed;\n  background-color: var(--ion-color-warning);\n  border: 5px solid #000;\n  right: 12px;\n  top: 100%;\n  z-index: 10000000000000000;\n}\n.attr-container {\n  display: flex;\n  flex-direction: row;\n  justify-content: left;\n  align-items: flex-start;\n}\n.attr-container .attr-name {\n  margin: 0 10px;\n  font-weight: bold;\n}\n.attr-container .activeBody {\n  background: var(--ion-color-warning);\n  color: var(--ion-color-warning-contrast) !important;\n  box-shadow: 0 4px 4px #000000eb;\n}\n.attr-container .attr-content {\n  margin: 5px;\n  font-size: 10px;\n  padding: 5px;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  border: 1px solid var(--ion-color-warning);\n  border-radius: 5px;\n  cursor: pointer;\n}\n.attr-container .attr-content .attrValName {\n  color: var(--ion-color-dark);\n  font-weight: bold;\n}\n.attr-container .attr-content .active {\n  box-shadow: inset 0 55px 8px #fa9c096b;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3QtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFXQTtFQUNFLHFCQUFBO0FBVkY7QUFjRTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7QUFaSjtBQWNJO0VBQ0UscUJBQUE7QUFaTjtBQWVJO0VBQ0UsWUFBQTtBQWJOO0FBZVE7RUFDRSxXQUFBO0VBQ0EsaUJBQUE7QUFiVjtBQWVVO0VBQ0UsNkJBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGVBQUE7QUFiWjtBQWtCTTtFQU1FLFdBQUE7RUFDQSxlQUFBO0FBckJSO0FBdUJRO0VBQ0UsYUFBQTtBQXJCVjtBQXVCVTtFQUNFLFlBQUE7QUFyQlo7QUEwQk07RUFDRSxnQkFBQTtFQUNBLFdBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQ0FBQTtBQXhCUjtBQTJCUTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0FBekJWO0FBNEJRO0VBQ0Usa0JBQUE7QUExQlY7QUE2QlE7RUFDRSxnQkFBQTtFQUNBLDRCQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQTNCVjtBQTZCVTtFQUNFLG1CQUFBO0VBQ0EscUJBQUE7QUEzQlo7QUFnQ1E7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQ0FBQTtFQUNBLG1CQUFBO0FBOUJWO0FBZ0NVO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUE5Qlo7QUFnQ1k7RUFDRSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FBOUJkO0FBZ0NjO0VBQ0UsaUJBQUE7QUE5QmhCO0FBa0NVO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBaENaO0FBdUNJO0VBQ0UsZUFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsT0FBQTtFQUNBLGdCQUFBO0FBckNOO0FBdUNNO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsMENBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsMEJBQUE7QUFyQ1I7QUEyQ0E7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLHVCQUFBO0FBeENGO0FBMENFO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0FBeENKO0FBMkNFO0VBQ0Usb0NBQUE7RUFDQSxtREFBQTtFQUNBLCtCQUFBO0FBekNKO0FBNENFO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBMUNKO0FBNENJO0VBQ0UsNEJBQUE7RUFDQSxpQkFBQTtBQTFDTjtBQTZDSTtFQUNFLHNDQUFBO0FBM0NOIiwiZmlsZSI6InByb2R1Y3QtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vJGJhY2tncm91bmRMYXllcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSwxMjMsMCwxKSAwJSwgcmdiYSgyMzcsMjU1LDAsMC45NDE2OTAwNTQ5MjgyMjEzKSAxMDAlKTtcclxuJGJhY2tncm91bmRMYXllcjogI2ZmZDcwMDtcclxuXHJcbiAgLy8gaW9uLXNsaWRlc3tcclxuICAvLyAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcblxyXG4gIC8vICAgaW9uLXNsaWRlIHtcclxuICAvLyAgICAgcGFkZGluZy10b3A6IDI1cHg7XHJcbiAgLy8gICAgIHBhZGRpbmctYm90dG9tOiAyNXB4O1xyXG4gIC8vICAgfVxyXG4gIC8vIH1cclxuaW9uLWNvbnRlbnR7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZmZkNzAwO1xyXG5cclxuXHJcblxyXG4gIC5jYXJ0LWJhZGdle1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA3cHg7XHJcbiAgICByaWdodDogMTBweDtcclxuICB9XHJcbiAgICBpb24tdG9vbGJhcntcclxuICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZkNzAwO1xyXG4gICAgfVxyXG5cclxuICAgIC5mdWxsc2NyZWVue1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcblxyXG4gICAgICAgIC50aXRsZS13cmFwcGVye1xyXG4gICAgICAgICAgei1pbmRleDogMTU7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiAtMjBweDtcclxuXHJcbiAgICAgICAgICAudGl0bGV7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgIHRleHQtc2hhZG93OiAycHggMnB4IDNweCAjMDAwMDAwN2Q7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgLnVwcGVyLXBhcnR7XHJcblxyXG4gICAgICAgIC8vIGlvbi1pbWd7XHJcbiAgICAgICAgLy8gICB3aWR0aDogMTUwcHg7XHJcbiAgICAgICAgLy8gICBoZWlnaHQ6IDMwMHB4O1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICBoZWlnaHQ6IDMwJTtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmU7XHJcblxyXG4gICAgICAgIGlvbi1zbGlkZXN7XHJcbiAgICAgICAgICBoZWlnaHQ6IDM1MHB4O1xyXG5cclxuICAgICAgICAgIGlvbi1pbWd7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5ib3R0b20tcGFydHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgIGhlaWdodDogNzAlO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHggMjBweCAwIDA7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogLTIwMHB4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAyMDBweDtcclxuICAgICAgICBib3gtc2hhZG93OiAwIC0ycHggMTBweCA1cHggIzIyMjIyMjE3O1xyXG5cclxuXHJcbiAgICAgICAgLnJlZ3VsYXItcHJpY2V7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAucmF0aW5ne1xyXG4gICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmRlc2NyaXB0aW9ue1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgIHBhZGRpbmc6IDM1cHggMTVweCA1MHB4IDE1cHg7XHJcbiAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMS4xcHg7XHJcbiAgICAgICAgICBsaW5lLWhlaWdodDogMS43O1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxuXHJcbiAgICAgICAgICBpb24tc2VnbWVudHtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZjhmOGY4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIC5yZXZpZXdze1xyXG4gICAgICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgICBib3gtc2hhZG93OiAwIDhweCA4cHggMCAjMDAwMDAwMWM7XHJcbiAgICAgICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG5cclxuICAgICAgICAgIC5oZWFkZXJ7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGxlZnQ7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICAgICAgICAubmFtZXtcclxuICAgICAgICAgICAgICB3aWR0aDogNTAlO1xyXG4gICAgICAgICAgICAgIGNvbG9yOiAjMzMzO1xyXG4gICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG5cclxuICAgICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLmJvZHl7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjODg4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICAuYWN0aW9uc3tcclxuICAgICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgICBib3R0b206IDA7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBsZWZ0OiAwO1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG5cclxuICAgICAgLnNxdWFyZXtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICB3aWR0aDogNTBweDtcclxuICAgICAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XHJcbiAgICAgICAgYm9yZGVyOiA1cHggc29saWQgIzAwMDtcclxuICAgICAgICByaWdodDogMTJweDtcclxuICAgICAgICB0b3A6IDEwMCU7XHJcbiAgICAgICAgei1pbmRleDogOTk5OTk5OTk5OTk5OTk5OTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG5cclxuLmF0dHItY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAganVzdGlmeS1jb250ZW50OiBsZWZ0O1xyXG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG5cclxuICAuYXR0ci1uYW1lIHtcclxuICAgIG1hcmdpbjogMCAxMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgfVxyXG5cclxuICAuYWN0aXZlQm9keSB7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmctY29udHJhc3QpICFpbXBvcnRhbnQ7XHJcbiAgICBib3gtc2hhZG93OiAwIDRweCA0cHggIzAwMDAwMGViO1xyXG4gIH1cclxuXHJcbiAgLmF0dHItY29udGVudCB7XHJcbiAgICBtYXJnaW46IDVweDtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG5cclxuICAgIC5hdHRyVmFsTmFtZSB7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgfVxyXG5cclxuICAgIC5hY3RpdmUge1xyXG4gICAgICBib3gtc2hhZG93OiBpbnNldCAwIDU1cHggOHB4ICNmYTljMDk2YjtcclxuICAgIH1cclxuICB9XHJcblxyXG59XHJcblxyXG4iXX0= */");

/***/ }),

/***/ 1185:
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/products/product-detail/product-detail.page.html ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content [scrollEvents]=\"true\">\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button  color=\"danger\" [routerLink]=\"['/carts']\">\n      <ion-icon name=\"cart\"></ion-icon>\n      <ion-badge class=\"cart-badge\" color=\"warning\">{{ totalCartQty }}</ion-badge>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-fab style=\"bottom: 60px\" vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"light\" (click)=\"addToWishlist()\">\n      <ion-icon [color]=\"wishlistColor ? 'danger' : 'medium'\" name=\"heart\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <ion-grid class=\"fullscreen ion-no-padding\">\n    <ion-toolbar>\n      <ion-buttons slot=\"start\">\n        <ion-back-button color=\"light\" defaultHref=\"tabs/home\"></ion-back-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n  <ion-grid *ngIf=\"singleProduct\">\n    <ion-row>\n      <ion-col class=\"title-wrapper ion-text-center\" size=\"12\" style=\"z-index: 15; margin-top: -20px\">\n        <ion-text color=\"light\" class=\"title ion-text-center\">{{ singleProduct.title }}</ion-text>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"upper-part\">\n      <ion-col size=\"2\"></ion-col>\n      <ion-col size=\"10\">\n        <ion-slides pager=\"true\" [options]=\"slideOpts\">\n          <!-- <ion-slide *ngFor=\"let image of singleProduct.images\"> -->\n          <ion-slide>\n            <img\n              [ngStyle]=\"{\n                'margin-top.px': 10,\n                'border-radius.px': 10,\n                'box-shadow': '0px 8px 8px rgba(4, 4, 4, 0.11)',\n                'max-height.%': 90,\n                'background-image': 'url('+backGroundImage+')',\n                'background-size.%': 100,\n                'background-repeat': 'no-repeat',\n                'background-position-x.px': 0,\n                'background-position-y.px': 0\n              }\"\n             [src]=\"singleProduct.mainImage\">\n          </ion-slide>\n          <!-- <ion-slide>\n\n          </ion-slide> -->\n\n        </ion-slides>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"bottom-part\">\n      <ion-col size=\"6\" style=\"height:min-content\">\n        <ion-chip *ngIf=\"selectedSKUProduct.discount\" class=\"regular-price\" color=\"primary\" ><del>BDT {{selectedSKUProduct.price}}</del></ion-chip>\n        <ion-chip class=\"regular-price\" color=\"success\" >BDT {{selectedSKUProduct.discountPrice}}</ion-chip>\n        <ion-chip class=\"regular-price\" color=\"success\" >BDT {{selectedSKUProduct.SkuId}}</ion-chip>\n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-right ion-padding-right\" style=\"height:min-content\">\n        <ion-chip color=\"success\" class=\"stock\">In stock</ion-chip>\n        <div class=\"rating\">\n          <p-rating [(ngModel)]=\"singleProduct.review.avarage\" readonly=\"true\" [cancel]=\"false\"></p-rating>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div class=\"attr-container\" *ngFor=\"let attr of singleProduct.skuModule.productSKUPropertyList; let attrIndex = index\">\n          <div class=\"attr-name\">\n            {{attr.skuPropertyName}}\n          </div>\n          <div\n            (click)=\"getAttr(attrIndex, attrValIndex, attrValues.propertyValueId)\"\n            [ngClass]=\"{'activeBody': attrValues['active']}\"\n            class=\"attr-content\"\n            *ngFor=\"let attrValues of attr.skuPropertyValues; let attrValIndex = index\">\n            <!-- <div> propertyValueId: {{attrValues.propertyValueId}} </div>\n            <div> propertyValueName: {{attrValues.propertyValueName}} </div> -->\n              <ion-img\n\n                style=\"width: 50px; height:50px; border: 1px solid rgba(51, 51, 51, 0.363); border-radius: 5px;\"\n                [src]=\"attrValues.skuPropertyImagePathSmall\"></ion-img>\n                <div class=\"attrValName\">{{attrValues.propertyValueName}}</div>\n          </div>\n        </div>\n        <!-- <ion-button (click)=\"genarateSKU(singleProduct.skuModule)\">Gen sku</ion-button> -->\n      </ion-col>\n      <ion-col class=\"description\">\n        <ion-segment color=\"medium\" value=\"description\" (ionChange)=\"segmentChanged($event)\">\n          <ion-segment-button value=\"description\">\n            <ion-label>Description</ion-label>\n          </ion-segment-button>\n          <ion-segment-button value=\"reviews\">\n            <ion-label>Reviews</ion-label>\n          </ion-segment-button>\n        </ion-segment>\n        <!-- review section -->\n        <ion-grid *ngIf=\"segment === 'reviews'\" >\n          <ion-row>\n            <ion-col size=\"12\" *ngFor=\"let review of reviews\">\n              <div class=\"reviews\">\n                <div class=\"header\">\n                  <div class=\"name\">\n                    <ion-icon name=\"person\"></ion-icon>{{ review.user_name }}\n                  </div>\n                  <div class=\"ratinng\">\n                    <p-rating [(ngModel)]=\"review.rating\" readonly=\"true\" [cancel]=\"false\"></p-rating>\n                  </div>\n                </div>\n\n                <div class=\"body\">\n                  <ion-text>\n                    {{ review.review }}\n                  </ion-text>\n                </div>\n              </div>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n        <ion-text *ngIf=\"segment === 'description'\" color=\"medium\">\n          {{ singleProduct.description }}\n        </ion-text>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\">\n        <iframe width=\"100%\" height=\"315\" src=\"https://www.youtube.com/embed/_aCeAMrh-wo\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n\n  </ion-grid>\n\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row class=\"actions\">\n      <ion-col size=\"6\">\n          <ion-button [disabled]=\"disableCartButtons\" color=\"warning\" expand=\"full\" class=\"buy-now\" (click)=\"buyNow()\">Buy Now</ion-button>\n      </ion-col>\n      <ion-col size=\"6\">\n          <div class=\"square\"></div>\n          <ion-button [disabled]=\"disableCartButtons\" color=\"danger\" expand=\"full\" class=\"add-to-cart\" (click)=\"addToCart()\">Add to cart</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_products_product-detail_product-detail_module_ts.js.map