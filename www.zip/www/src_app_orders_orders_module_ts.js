(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_orders_orders_module_ts"],{

/***/ 35674:
/*!*************************************************!*\
  !*** ./src/app/orders/orders-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdersPageRoutingModule": () => (/* binding */ OrdersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _orders_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orders.page */ 30206);




const routes = [
    {
        path: '',
        component: _orders_page__WEBPACK_IMPORTED_MODULE_0__.OrdersPage
    },
    {
        path: ':id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("src_app_orders_order-details_order-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./order-details/order-details.module */ 14782)).then(m => m.OrderDetailsPageModule)
    }
];
let OrdersPageRoutingModule = class OrdersPageRoutingModule {
};
OrdersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrdersPageRoutingModule);



/***/ }),

/***/ 84819:
/*!*****************************************!*\
  !*** ./src/app/orders/orders.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdersPageModule": () => (/* binding */ OrdersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _orders_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orders-routing.module */ 35674);
/* harmony import */ var _orders_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./orders.page */ 30206);







let OrdersPageModule = class OrdersPageModule {
};
OrdersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _orders_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrdersPageRoutingModule
        ],
        declarations: [_orders_page__WEBPACK_IMPORTED_MODULE_1__.OrdersPage]
    })
], OrdersPageModule);



/***/ }),

/***/ 30206:
/*!***************************************!*\
  !*** ./src/app/orders/orders.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdersPage": () => (/* binding */ OrdersPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_orders_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./orders.page.html */ 84698);
/* harmony import */ var _orders_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./orders.page.scss */ 78832);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _services_orders_order_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/orders/order.service */ 53675);





let OrdersPage = class OrdersPage {
    constructor(orderService) {
        this.orderService = orderService;
    }
    ngOnInit() {
        this.orderService.fetchOrders().subscribe();
        this.orderSub = this.orderService.orders.subscribe(orders => {
            this.orders = orders;
        });
    }
    ngOnDestroy() {
        this.orderSub.unsubscribe();
    }
};
OrdersPage.ctorParameters = () => [
    { type: _services_orders_order_service__WEBPACK_IMPORTED_MODULE_2__.OrderService }
];
OrdersPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-orders',
        template: _raw_loader_orders_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_orders_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], OrdersPage);



/***/ }),

/***/ 53675:
/*!**************************************************!*\
  !*** ./src/app/services/orders/order.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderService": () => (/* binding */ OrderService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../environments/environment */ 92340);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 25917);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_account_account_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/account/account.service */ 10740);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 68307);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 5304);







let OrderService = class OrderService {
    constructor(http, accountService) {
        this.http = http;
        this.accountService = accountService;
        this._orders = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject([]);
    }
    get orders() {
        return this._orders.asObservable();
    }
    fetchOrders() {
        const headerOps = this.headerOptions();
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/order/all?status=pending`, headerOps).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(orderRes => {
            const data = orderRes.data;
            if (!orderRes.success && data === 401) {
                this.accountService.logOut();
            }
            const orders = orderRes.data.data;
            this._orders.next(orders);
        }));
    }
    fetchSingleOrder(id) {
        const headerOps = this.headerOptions();
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/order/single?orderId=${id}`, {}, headerOps).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(singleOrderRes => {
            return singleOrderRes;
        }));
    }
    addOrder(shippingAddressId, gift = 0, message = '', from = '') {
        const headerOps = this.headerOptions();
        const body = {
            shippingAddressId,
            gift,
            message,
            from
        };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/order/place`, body, headerOps).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(newOrder => {
            console.log('newOrder : ', newOrder);
            this.fetchOrders().subscribe(res => {
                return res;
            });
        }));
    }
    addCustomOrder(shippingAddressId, text = '', gift = 0, message = '', from = '') {
        const headerOps = this.headerOptions();
        const body = {
            shippingAddressId,
            text,
            gift,
            message,
            from
        };
        console.log('custom order body : ', body, text.length);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/order/custom`, body, headerOps).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(order => {
            console.log('custom order : ', order);
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(err => (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)('error', err)));
    }
    headerOptions() {
        const token = this.accountService.userToken;
        return {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            })
        };
    }
};
OrderService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient },
    { type: src_app_account_account_service__WEBPACK_IMPORTED_MODULE_1__.AccountService }
];
OrderService = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Injectable)({
        providedIn: 'root'
    })
], OrderService);



/***/ }),

/***/ 78832:
/*!*****************************************!*\
  !*** ./src/app/orders/orders.page.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: rgb(255, 252, 244);\n}\nion-content ion-toolbar {\n  --background: rgb(255, 252, 244);\n}\nion-content .card {\n  background: #fff;\n  border-radius: 20px;\n  box-shadow: 0px 8px 8px 0px #00000017;\n  padding: 10px;\n  margin-bottom: 25px;\n}\nion-content .card .header {\n  width: 100%;\n  display: flex;\n}\nion-content .card .header ion-chip {\n  width: 50%;\n}\nion-content .card .header .date {\n  width: 50%;\n  text-align: right;\n  margin-top: 10px;\n  margin-right: 8px;\n  color: #888;\n  font-weight: bold;\n}\nion-content .card .content {\n  width: 100%;\n  display: flex;\n  padding: 10px;\n  font-size: 14px;\n}\nion-content .card .content .status {\n  width: 50%;\n}\nion-content .card .content .total {\n  width: 50%;\n  text-align: right;\n}\nion-content .card .actions {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  padding: 2px;\n  margin: 5px;\n}\nion-content .card .actions ion-button {\n  width: 100%;\n}\nion-content .proceed {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  width: 100%;\n}\nion-content .proceed .total-section {\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  padding: 20px;\n}\nion-content .proceed .total-section .total-text {\n  width: 50%;\n  text-align: left;\n}\nion-content .proceed .total-section .total {\n  width: 50%;\n  font-weight: bold;\n  text-align: right;\n}\nion-content .proceed ion-button {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSxnQ0FBQTtBQURGO0FBR0k7RUFDRSxnQ0FBQTtBQUROO0FBS0k7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EscUNBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFITjtBQUtNO0VBQ0UsV0FBQTtFQUNBLGFBQUE7QUFIUjtBQUtRO0VBQ0UsVUFBQTtBQUhWO0FBTVE7RUFDRSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FBSlY7QUFRTTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUFOUjtBQVFRO0VBQ0UsVUFBQTtBQU5WO0FBU1E7RUFDRSxVQUFBO0VBQ0EsaUJBQUE7QUFQVjtBQVdNO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBVFI7QUFXUTtFQUNFLFdBQUE7QUFUVjtBQWVJO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUFiTjtBQWdCTTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0FBZFI7QUFpQlE7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7QUFmVjtBQWtCUTtFQUNFLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FBaEJWO0FBb0JNO0VBQ0UsV0FBQTtBQWxCUiIsImZpbGUiOiJvcmRlcnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5pb24tY29udGVudHtcclxuICAtLWJhY2tncm91bmQ6IHJnYigyNTUsIDI1MiwgMjQ0KTtcclxuXHJcbiAgICBpb24tdG9vbGJhcntcclxuICAgICAgLS1iYWNrZ3JvdW5kOiByZ2IoMjU1LCAyNTIsIDI0NCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC5jYXJkIHtcclxuICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgYm94LXNoYWRvdzogMHB4IDhweCA4cHggMHB4ICMwMDAwMDAxNztcclxuICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMjVweDtcclxuXHJcbiAgICAgIC5oZWFkZXIge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcblxyXG4gICAgICAgIGlvbi1jaGlwe1xyXG4gICAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kYXRle1xyXG4gICAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICAgIG1hcmdpbi1yaWdodDogOHB4O1xyXG4gICAgICAgICAgY29sb3I6ICM4ODg7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5jb250ZW50e1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcblxyXG4gICAgICAgIC5zdGF0dXN7XHJcbiAgICAgICAgICB3aWR0aDogNTAlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnRvdGFse1xyXG4gICAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLmFjdGlvbnN7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgcGFkZGluZzogMnB4O1xyXG4gICAgICAgIG1hcmdpbjogNXB4O1xyXG5cclxuICAgICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC5wcm9jZWVke1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcblxyXG5cclxuICAgICAgLnRvdGFsLXNlY3Rpb257XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICAgIHBhZGRpbmc6IDIwcHg7XHJcblxyXG5cclxuICAgICAgICAudG90YWwtdGV4dHtcclxuICAgICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnRvdGFse1xyXG4gICAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB9XHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 84698:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/orders.page.html ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/home\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngFor=\"let order of orders\">\n        <div class=\"card\">\n            <div class=\"header\">\n              <ion-chip color=\"tertiary\">#{{order.orderId}}</ion-chip>\n              <div class=\"date\"> 12-10-2021 </div>\n            </div>\n            <div class=\"content\">\n              <div class=\"status\">\n                status: {{order.status}}\n              </div>\n              <div class=\"total\">\n                Total: BDT {{order.orderPrice}}\n              </div>\n            </div>\n            <div class=\"actions\">\n              <ion-button expand=\"block\" color=\"secondary\" [routerLink]=\"['/', 'all','orders', order.id]\"> View Details </ion-button>\n            </div>\n        </div>\n      </ion-col>\n      <!-- <ion-col>\n        <div class=\"card\">\n            <div class=\"header\">\n              <ion-chip color=\"tertiary\">#12341</ion-chip>\n              <div class=\"date\"> 12-10-2021 </div>\n            </div>\n            <div class=\"content\">\n              <div class=\"status\">\n                status: processing\n              </div>\n              <div class=\"total\">\n                Total: BDT 2000\n              </div>\n            </div>\n            <div class=\"actions\">\n              <ion-button expand=\"block\" color=\"secondary\" [routerLink]=\"['new']\"> View Details </ion-button>\n            </div>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div class=\"card\">\n            <div class=\"header\">\n              <ion-chip color=\"tertiary\">#12341</ion-chip>\n              <div class=\"date\"> 12-10-2021 </div>\n            </div>\n            <div class=\"content\">\n              <div class=\"status\">\n                status: processing\n              </div>\n              <div class=\"total\">\n                Total: BDT 2000\n              </div>\n            </div>\n            <div class=\"actions\">\n              <ion-button expand=\"block\" color=\"secondary\" [routerLink]=\"['new']\"> View Details </ion-button>\n            </div>\n        </div>\n      </ion-col> -->\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_orders_orders_module_ts.js.map