(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["default-src_app_carts_carts_module_ts"],{

/***/ 10669:
/*!**********************************************************!*\
  !*** ./node_modules/primeng/fesm2015/primeng-divider.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Divider": () => (/* binding */ Divider),
/* harmony export */   "DividerModule": () => (/* binding */ DividerModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 38583);




const _c0 = ["*"];

class Divider {
  constructor() {
    this.layout = "horizontal";
    this.type = "solid";
  }

  containerClass() {
    return {
      'p-divider p-component': true,
      'p-divider-horizontal': this.layout === "horizontal",
      'p-divider-vertical': this.layout === "vertical",
      'p-divider-solid': this.type === "solid",
      'p-divider-dashed': this.type === "dashed",
      'p-divider-dotted': this.type === "dotted",
      'p-divider-left': this.layout === 'horizontal' && (!this.align || this.align === 'left'),
      'p-divider-center': this.layout === 'horizontal' && this.align === 'center' || this.layout === 'vertical' && (!this.align || this.align === 'center'),
      'p-divider-right': this.layout === 'horizontal' && this.align === 'right',
      'p-divider-top': this.layout === 'vertical' && this.align === 'top',
      'p-divider-bottom': this.layout === 'vertical' && this.align === 'bottom'
    };
  }

}

Divider.ɵfac = function Divider_Factory(t) {
  return new (t || Divider)();
};

Divider.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: Divider,
  selectors: [["p-divider"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    styleClass: "styleClass",
    style: "style",
    layout: "layout",
    type: "type",
    align: "align"
  },
  ngContentSelectors: _c0,
  decls: 3,
  vars: 4,
  consts: [["role", "separator", 3, "ngClass", "ngStyle"], [1, "p-divider-content"]],
  template: function Divider_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.styleClass);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx.containerClass())("ngStyle", ctx.style);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgStyle],
  styles: [".p-divider-horizontal{display:flex;width:100%;position:relative;align-items:center}.p-divider-horizontal:before{position:absolute;display:block;top:50%;left:0;width:100%;content:\"\"}.p-divider-horizontal.p-divider-left{justify-content:flex-start}.p-divider-horizontal.p-divider-right{justify-content:flex-end}.p-divider-horizontal.p-divider-center{justify-content:center}.p-divider-content{z-index:1}.p-divider-vertical{min-height:100%;margin:0 1rem;display:flex;position:relative;justify-content:center}.p-divider-vertical:before{position:absolute;display:block;top:0;left:50%;height:100%;content:\"\"}.p-divider-vertical.p-divider-top{align-items:flex-start}.p-divider-vertical.p-divider-center{align-items:center}.p-divider-vertical.p-divider-bottom{align-items:flex-end}.p-divider-solid.p-divider-horizontal:before{border-top-style:solid}.p-divider-solid.p-divider-vertical:before{border-left-style:solid}.p-divider-dashed.p-divider-horizontal:before{border-top-style:dashed}.p-divider-dashed.p-divider-vertical:before{border-left-style:dashed}.p-divider-dotted.p-divider-horizontal:before{border-top-style:dotted;border-left-style:dotted}"],
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Divider, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-divider',
      template: `
        <div [ngClass]="containerClass()" [class]="styleClass" [ngStyle]="style" role="separator">
            <div class="p-divider-content">
                <ng-content></ng-content>
            </div>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      styleUrls: ['./divider.css'],
      host: {
        'class': 'p-element'
      }
    }]
  }], null, {
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    layout: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    type: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    align: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();

class DividerModule {}

DividerModule.ɵfac = function DividerModule_Factory(t) {
  return new (t || DividerModule)();
};

DividerModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: DividerModule,
  declarations: [Divider],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule],
  exports: [Divider]
});
DividerModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DividerModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule],
      exports: [Divider],
      declarations: [Divider]
    }]
  }], null, null);
})();
/**
 * Generated bundle index. Do not edit.
 */


 //# sourceMappingURL=primeng-divider.js.map

/***/ }),

/***/ 40349:
/*!***********************************************!*\
  !*** ./src/app/carts/carts-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartsPageRoutingModule": () => (/* binding */ CartsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _carts_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carts.page */ 24519);




const routes = [
    {
        path: '',
        component: _carts_page__WEBPACK_IMPORTED_MODULE_0__.CartsPage
    }
];
let CartsPageRoutingModule = class CartsPageRoutingModule {
};
CartsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CartsPageRoutingModule);



/***/ }),

/***/ 92120:
/*!***************************************!*\
  !*** ./src/app/carts/carts.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartsPageModule": () => (/* binding */ CartsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var primeng_divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/divider */ 10669);
/* harmony import */ var _carts_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carts-routing.module */ 40349);
/* harmony import */ var _carts_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./carts.page */ 24519);








let CartsPageModule = class CartsPageModule {
};
CartsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            primeng_divider__WEBPACK_IMPORTED_MODULE_7__.DividerModule,
            _carts_routing_module__WEBPACK_IMPORTED_MODULE_0__.CartsPageRoutingModule
        ],
        declarations: [_carts_page__WEBPACK_IMPORTED_MODULE_1__.CartsPage]
    })
], CartsPageModule);



/***/ }),

/***/ 24519:
/*!*************************************!*\
  !*** ./src/app/carts/carts.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartsPage": () => (/* binding */ CartsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_carts_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./carts.page.html */ 86330);
/* harmony import */ var _carts_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./carts.page.scss */ 27938);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _carts_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./carts.service */ 77328);
/* harmony import */ var _services_breakpoint_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../services/breakpoint.service */ 43489);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _services_cart_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/cart.service */ 90910);
/* harmony import */ var _services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/controllers/toast.service */ 41048);
/* harmony import */ var _services_coupon_coupon_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/coupon/coupon.service */ 23843);











let CartsPage = class CartsPage {
    constructor(breakpoint, nav, cartService, cartsService, couponService, toastService) {
        this.breakpoint = breakpoint;
        this.nav = nav;
        this.cartService = cartService;
        this.cartsService = cartsService;
        this.couponService = couponService;
        this.toastService = toastService;
        this.layout = 'horizontal';
        this.cartDetails = null;
        this.carts = this.cartsService.carts;
    }
    ngOnInit() {
        this.getLayout();
        this.couponInit();
    }
    couponInit() {
        this.couponForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup({
            coupon: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null, {
                updateOn: 'change'
            })
        });
    }
    applyCoupon() {
        if (!this.couponForm.valid) {
            this.toastService.toast('coupon is not valid');
        }
        else {
            this.couponService.applyCoupon(this.couponForm.value.coupon).subscribe(res => {
                console.log('got the coupon res : ', res);
                if (!res.success) {
                    this.toastService.toast(res.message);
                }
                else {
                    this.toastService.toast('coupon successfully applied', 'success');
                }
            });
        }
    }
    ionViewWillEnter() {
        console.log('cart view will enter');
        this.cartService.fetchCartObj().subscribe();
        this.cartSub = this.cartService.cartDetails.subscribe(res => {
            if (res) {
                this.cartDetails = res;
                this.carts = res.data.product;
            }
        });
    }
    getLayout() {
        this.breakpoint.size.subscribe((data) => {
            console.log(data);
            if (data === 'sm' || data === 'md' || data === 'lg' || data === 'xl') {
                this.layout = 'vertical';
            }
            else {
                this.layout = 'horizontal';
            }
        });
    }
    onProceedCheckout() {
        this.nav.navigateForward('checkout');
        console.log('next');
    }
    increaseCart(productId, quantity) {
        const skuId = productId + '-green';
        console.log(productId);
        this.increaseQuantity(productId);
        this.cartService.addTOCart(productId, skuId, quantity).subscribe();
    }
    decreaseCart(productId, quantity) {
        const skuId = productId + '-green';
        console.log(productId, quantity);
        this.decreaseQuantity(productId);
        this.cartService.addTOCart(productId, skuId, quantity).subscribe();
    }
    // helpers
    increaseQuantity(productId) {
        this.cartDetails.data.product.map(cartItem => {
            if (cartItem.productId === productId) {
                // this.cartDetails.data.subtotal += cartItem.discountedPrice;
                console.log('naims cart subtotal : ', this.cartDetails.data.subtotal);
                cartItem.quantity++;
                cartItem.discountedPrice = cartItem.orginalPrice * cartItem.quantity;
                this.cartDetails.data.subtotal += cartItem.orginalPrice;
                this.cartDetails.data.grandTotal += cartItem.orginalPrice;
                return;
            }
        });
    }
    decreaseQuantity(productId) {
        this.cartDetails.data.product.map(cartItem => {
            if (cartItem.productId === productId) {
                cartItem.quantity--;
                cartItem.discountedPrice = cartItem.orginalPrice * cartItem.quantity;
                this.cartDetails.data.subtotal -= cartItem.orginalPrice;
                this.cartDetails.data.grandTotal -= cartItem.orginalPrice;
                return;
            }
        });
    }
    onDeleteCartItem(cartId) {
        this.cartService.deleteCartItem(cartId).subscribe();
    }
    ngOnDestroy() {
        this.cartSub.unsubscribe();
    }
};
CartsPage.ctorParameters = () => [
    { type: _services_breakpoint_service__WEBPACK_IMPORTED_MODULE_3__.BreakpointObserverService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _services_cart_service__WEBPACK_IMPORTED_MODULE_4__.CartService },
    { type: _carts_service__WEBPACK_IMPORTED_MODULE_2__.CartsService },
    { type: _services_coupon_coupon_service__WEBPACK_IMPORTED_MODULE_6__.CouponService },
    { type: _services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService }
];
CartsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-carts',
        template: _raw_loader_carts_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_carts_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CartsPage);



/***/ }),

/***/ 77328:
/*!****************************************!*\
  !*** ./src/app/carts/carts.service.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartsService": () => (/* binding */ CartsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);

/* eslint-disable @typescript-eslint/naming-convention */

let CartsService = class CartsService {
    constructor() {
        this.carts = [
            {
                product_id: '12',
                product_title: 'product one',
                product_image: '../../assets/images/productone.png',
                unit_price: 300,
                qty: 1
            },
            {
                product_id: '13',
                product_title: 'product Two',
                product_image: '../../assets/images/productone.png',
                unit_price: 300,
                qty: 1
            },
            {
                product_id: '14',
                product_title: 'product Three',
                product_image: '../../assets/images/productone.png',
                unit_price: 300,
                qty: 1
            },
        ];
    }
    getTotalCartQty() {
        let totalCartQty = 0;
        this.carts.map(cartItem => {
            totalCartQty += cartItem.qty;
        });
        return totalCartQty;
    }
    /**
     * retrieves the products carted quantity from product id
     *
     * @param product_id
     * @returns number
     */
    getCartQuantityByProduct(product_id) {
        const cartItem = this.carts.filter(data => data.product_id === product_id);
        console.log(cartItem);
        if (cartItem.length === 0) {
            return 0;
        }
        else {
            return cartItem[0].qty;
        }
    }
    addCartItem(cart) {
        let push = true;
        this.carts.map((cartItem, index) => {
            if (cartItem.product_id === cart.product_id) {
                push = false;
                console.log('cart index', cartItem);
                console.log('cart index', index);
                this.carts[index].qty = cart.qty;
            }
            else {
            }
        });
        if (push) {
            this.carts.push(cart);
        }
    }
    changeCartQty(index, qty) {
        this.carts[index].qty = qty;
    }
    subTotal() {
        let total = 0;
        this.carts.map((cartItem) => {
            total += (cartItem.unit_price * cartItem.qty);
        });
        return total;
    }
};
CartsService.ctorParameters = () => [];
CartsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], CartsService);



/***/ }),

/***/ 41048:
/*!*******************************************************!*\
  !*** ./src/app/services/controllers/toast.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToastService": () => (/* binding */ ToastService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);



let ToastService = class ToastService {
    constructor(toastCtrl) {
        this.toastCtrl = toastCtrl;
    }
    toast(message = 'something went wrong', color = 'danger', duration = 2000, cssClass = 'controller.scss', mode = 'ios', position = 'top') {
        this.toastCtrl.create({
            message,
            color,
            mode,
            position,
            duration,
            cssClass
        }).then(toaslEl => {
            toaslEl.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.ToastController }
];
ToastService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ToastService);



/***/ }),

/***/ 23843:
/*!***************************************************!*\
  !*** ./src/app/services/coupon/coupon.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CouponService": () => (/* binding */ CouponService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _account_account_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../account/account.service */ 10740);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 68307);






let CouponService = class CouponService {
    constructor(http, accountService) {
        this.http = http;
        this.accountService = accountService;
    }
    applyCoupon(coupon) {
        const token = this.accountService.userToken;
        const httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            })
        };
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.url.base}/coupon/apply`, { coupon }, httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(res => {
            console.log('apply coupon res : ', res);
        }));
    }
};
CouponService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient },
    { type: _account_account_service__WEBPACK_IMPORTED_MODULE_0__.AccountService }
];
CouponService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], CouponService);



/***/ }),

/***/ 27938:
/*!***************************************!*\
  !*** ./src/app/carts/carts.page.scss ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: rgb(255, 252, 244);\n}\nion-content ion-toolbar {\n  --background: rgb(255, 252, 244);\n}\nion-content .card {\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n  background: floralwhite;\n  margin: 10px 0 20px 35px;\n  border-radius: 10px;\n  box-shadow: inset 0px 8px 8px 3px #c1c1c130;\n}\nion-content .card img {\n  width: 100px;\n  height: 120px;\n  margin-left: -31px;\n  margin-top: 15px !important;\n  margin-bottom: 15px !important;\n}\nion-content .card .detail {\n  min-width: 185px;\n  margin: 10px;\n}\nion-content .card .detail .title {\n  font-weight: bold;\n  font-size: 17px;\n  color: #000000c7;\n}\nion-content .card .detail .price {\n  font-weight: bold;\n  color: #888;\n}\nion-content .card .detail .price .delete {\n  background: #3333330f;\n  padding: 5px;\n  border-radius: 50%;\n  color: #f74b4b;\n  font-size: 16px;\n}\nion-content .card .detail .price .delete:hover {\n  background: rgba(0, 0, 0, 0.164);\n  font-size: 20px;\n}\nion-content .card .actions {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  border: 1px solid #e3e3e3;\n  border-radius: 30px;\n  box-shadow: 0px 5px 5px 0 #a1a1a180;\n  padding: 2px;\n  margin-right: 5px;\n}\nion-content .card .actions ion-icon {\n  background-color: var(--ion-color-warning);\n  color: #fff;\n  width: 25px;\n  height: 25px;\n  border-radius: 50%;\n  box-shadow: 0 5px 5px 0 #0606063d;\n}\nion-content .card .actions ion-button {\n  --border-radius: 50%;\n}\nion-content .proceed {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  width: 100%;\n}\nion-content .proceed .total-section {\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  padding: 20px;\n}\nion-content .proceed .total-section .total-text {\n  width: 50%;\n  text-align: left;\n}\nion-content .proceed .total-section .total {\n  width: 50%;\n  font-weight: bold;\n  text-align: right;\n}\nion-content .proceed ion-button {\n  width: 100%;\n}\nion-content .empty-box {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\nion-content .empty-box .empty-cart-icon {\n  font-size: 64px;\n}\n.coupon-form {\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n}\n.coupon-form ion-input {\n  box-shadow: inset 3px 5px 8px #00000042;\n  border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcnRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLGdDQUFBO0FBREY7QUFHSTtFQUNFLGdDQUFBO0FBRE47QUFLSTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtBQUhOO0FBS007RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSw4QkFBQTtBQUhSO0FBTU07RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFKUjtBQU1RO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFKVjtBQU9RO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0FBTFY7QUFPVTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUFMWjtBQU9ZO0VBQ0UsZ0NBQUE7RUFDQSxlQUFBO0FBTGQ7QUFZTTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUNBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFWUjtBQVlRO0VBQ0UsMENBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0FBVlY7QUFlUTtFQUNFLG9CQUFBO0FBYlY7QUFxQkk7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQW5CTjtBQXNCTTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0FBcEJSO0FBdUJRO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0FBckJWO0FBd0JRO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUF0QlY7QUEwQk07RUFDRSxXQUFBO0FBeEJSO0FBNkJFO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQTNCSjtBQTRCSTtFQUNFLGVBQUE7QUExQk47QUErQkE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBNUJGO0FBOEJFO0VBQ0UsdUNBQUE7RUFDQSxrQkFBQTtBQTVCSiIsImZpbGUiOiJjYXJ0cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcbmlvbi1jb250ZW50e1xyXG4gIC0tYmFja2dyb3VuZDogcmdiKDI1NSwgMjUyLCAyNDQpO1xyXG5cclxuICAgIGlvbi10b29sYmFye1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHJnYigyNTUsIDI1MiwgMjQ0KTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLmNhcmR7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICBiYWNrZ3JvdW5kOiBmbG9yYWx3aGl0ZTtcclxuICAgICAgbWFyZ2luOiAxMHB4IDAgMjBweCAzNXB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICBib3gtc2hhZG93OiBpbnNldCAwcHggOHB4IDhweCAzcHggI2MxYzFjMTMwO1xyXG5cclxuICAgICAgaW1ne1xyXG4gICAgICAgIHdpZHRoOiAxMDBweDtcclxuICAgICAgICBoZWlnaHQ6IDEyMHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAtMzFweDtcclxuICAgICAgICBtYXJnaW4tdG9wOiAxNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweCAhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuZGV0YWlse1xyXG4gICAgICAgIG1pbi13aWR0aDogMTg1cHg7XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG5cclxuICAgICAgICAudGl0bGV7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgICAgIGNvbG9yOiAjMDAwMDAwYzc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAucHJpY2V7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgIGNvbG9yOiAjODg4O1xyXG5cclxuICAgICAgICAgIC5kZWxldGV7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICMzMzMzMzMwZjtcclxuICAgICAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZjc0YjRiO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcblxyXG4gICAgICAgICAgICAmOmhvdmVye1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xNjQpO1xyXG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5hY3Rpb25ze1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNlM2UzZTM7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgICBib3gtc2hhZG93OiAwcHggNXB4IDVweCAwICNhMWExYTE4MDtcclxuICAgICAgICBwYWRkaW5nOiAycHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcblxyXG4gICAgICAgIGlvbi1pY29ue1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xyXG4gICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgICB3aWR0aDogMjVweDtcclxuICAgICAgICAgIGhlaWdodDogMjVweDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgNXB4IDVweCAwICMwNjA2MDYzZDtcclxuICAgICAgICB9XHJcblxyXG5cclxuXHJcbiAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgLy8gd2lkdGg6IDMwcHg7XHJcbiAgICAgICAgICAvLyBoZWlnaHQ6IDMwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC5wcm9jZWVke1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcblxyXG5cclxuICAgICAgLnRvdGFsLXNlY3Rpb257XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICAgIHBhZGRpbmc6IDIwcHg7XHJcblxyXG5cclxuICAgICAgICAudG90YWwtdGV4dHtcclxuICAgICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnRvdGFse1xyXG4gICAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAuZW1wdHktYm94IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgLmVtcHR5LWNhcnQtaWNvbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogNjRweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi5jb3Vwb24tZm9ybSB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gIGlvbi1pbnB1dHtcclxuICAgIGJveC1zaGFkb3c6IGluc2V0IDNweCA1cHggOHB4ICMwMDAwMDA0MjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 86330:
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/carts/carts.page.html ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/home\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" sizeSm=\"6\" sizeMd=\"6\" sizeLg=\"4\" *ngIf=\"cartDetails\">\n        <span *ngIf=\"cartDetails.success\">\n          <div class=\"card\" *ngFor=\"let cartItem of cartDetails.data.product; let i = index\">\n            <img [ngStyle]=\"{\n            'background-image': 'url('+cartItem.backgroundImage+')',\n            'background-size.%': 100,\n            'background-repeat': 'no-repeat',\n            'background-position-x.px': 0,\n            'background-position-y.px': 0\n            }\" [src]=\"cartItem.productImage\">\n            <ion-label class=\"detail\">\n              <h3 class=\"title\">{{ cartItem.productTitle }}</h3>\n              <p class=\"price\">{{ cartItem.discountedPrice }}</p>\n              <p class=\"price\">\n                <ion-icon (click)=\"onDeleteCartItem(cartItem.id)\" class=\"delete\"  name=\"trash\"></ion-icon>\n                <!-- <ion-buttons>\n                  <ion-button>\n                    <ion-icon name=\"trash\"></ion-icon>\n                  </ion-button>\n                </ion-buttons> -->\n              </p>\n            </ion-label>\n            <div class=\"actions\">\n                <ion-icon name=\"add\" (click)=\"increaseCart(cartItem.productId, 1)\"></ion-icon>\n              <ion-label>{{ cartItem.quantity }}</ion-label>\n                <ion-icon name=\"remove\" (click)=\"decreaseCart(cartItem.productId, -1)\"></ion-icon>\n            </div>\n          </div>\n        </span>\n        <span *ngIf=\"!cartDetails.success\">\n          <div class=\"empty-box\">\n            <ion-icon class=\"empty-cart-icon\" color=\"medium\" name=\"document\"></ion-icon>\n            <ion-label color=\"medium\">{{cartDetails.message}}</ion-label>\n          </div>\n        </span>\n      </ion-col>\n      <ion-col size=\"12\" sizeSm=\"6\" sizeMd=\"6\" sizeLg=\"4\" *ngIf=\"!cartDetails\">\n        <div class=\"empty-box\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n\n      <ion-col>\n        <p-divider [layout]=\"layout\"></p-divider>\n      </ion-col>\n\n      <!-- <p-divider [layout]=\"layout\"></p-divider> -->\n      <ion-col size=\"12\" sizeSm=\"4\" sizeMd=\"4\" sizeLg=\"6\">\n        <form class=\"coupon-form\" [formGroup]=\"couponForm\" (ngSubmit)=\"applyCoupon()\">\n          <ion-input formControlName=\"coupon\" type=\"text\" placeholder=\"coupon code\"></ion-input>\n          <ion-button color=\"warning\" type=\"submit\">apply</ion-button>\n        </form>\n      </ion-col>\n\n\n      <ion-col size=\"12\" sizeSm=\"4\" sizeMd=\"4\" sizeLg=\"6\">\n        <div class=\"proceed\" *ngIf=\"cartDetails\">\n          <div class=\"total-section\">\n            <span class=\"total-text\"> Total </span>\n            <span class=\"total\"> BDT {{ cartDetails.data.subtotal }}</span>\n          </div>\n          <ion-button color=\"warning\" (click)=\"onProceedCheckout()\" > Proceed Checkout </ion-button>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=default-src_app_carts_carts_module_ts.js.map