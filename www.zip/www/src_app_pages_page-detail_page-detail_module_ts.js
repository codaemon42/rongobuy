(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_pages_page-detail_page-detail_module_ts"],{

/***/ 69032:
/*!*****************************************************************!*\
  !*** ./src/app/pages/page-detail/page-detail-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageDetailPageRoutingModule": () => (/* binding */ PageDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _page_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./page-detail.page */ 37533);




const routes = [
    {
        path: '',
        component: _page_detail_page__WEBPACK_IMPORTED_MODULE_0__.PageDetailPage
    }
];
let PageDetailPageRoutingModule = class PageDetailPageRoutingModule {
};
PageDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PageDetailPageRoutingModule);



/***/ }),

/***/ 41328:
/*!*********************************************************!*\
  !*** ./src/app/pages/page-detail/page-detail.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageDetailPageModule": () => (/* binding */ PageDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _page_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./page-detail-routing.module */ 69032);
/* harmony import */ var _page_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-detail.page */ 37533);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);








let PageDetailPageModule = class PageDetailPageModule {
};
PageDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _page_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.PageDetailPageRoutingModule
        ],
        declarations: [_page_detail_page__WEBPACK_IMPORTED_MODULE_1__.PageDetailPage]
    })
], PageDetailPageModule);



/***/ }),

/***/ 37533:
/*!*******************************************************!*\
  !*** ./src/app/pages/page-detail/page-detail.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageDetailPage": () => (/* binding */ PageDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_page_detail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./page-detail.page.html */ 36295);
/* harmony import */ var _page_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-detail.page.scss */ 58889);
/* harmony import */ var _services_page_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/page.service */ 49450);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);






let PageDetailPage = class PageDetailPage {
    constructor(router, pageService) {
        this.router = router;
        this.pageService = pageService;
        this.isLoadingSearch = false;
    }
    ngOnInit() {
        this.router.params.subscribe(route => {
            this.title = route.slug;
            console.log('title : ', route.slug);
            // load page content
            this.loadContent(route.slug);
        });
    }
    // content loading method
    loadContent(slug) {
        this.pageService.fetchPage(slug).subscribe((data) => {
            console.log('fetch : ', data);
        });
        this.pageService.page.subscribe(data => {
            this.page = data;
            console.log('page-detail : ', this.page);
            document.getElementById('page-content').innerHTML = this.page.content;
        });
    }
    // app header methods
    onSearch(event) {
        console.log('new event created: ', event);
        this.searchData = event;
    }
    isLoading(event) {
        console.log('is loading', event);
        this.isLoadingSearch = event;
    }
};
PageDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: _services_page_service__WEBPACK_IMPORTED_MODULE_2__.PageService }
];
PageDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-page-detail',
        template: _raw_loader_page_detail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_page_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PageDetailPage);



/***/ }),

/***/ 49450:
/*!******************************************!*\
  !*** ./src/app/services/page.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageService": () => (/* binding */ PageService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 68307);






let PageService = class PageService {
    constructor(http) {
        this.http = http;
        this._page = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    }
    get page() {
        return this._page.asObservable();
    }
    fetchPage(slug) {
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/single-page/${slug}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)((pageRes) => {
            this._page.next(pageRes.data);
        }));
    }
};
PageService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient }
];
PageService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], PageService);



/***/ }),

/***/ 58889:
/*!*********************************************************!*\
  !*** ./src/app/pages/page-detail/page-detail.page.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYWdlLWRldGFpbC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 36295:
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-detail/page-detail.page.html ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <app-header (isLoadingSearch)=\"isLoading($event)\" (searchTextFound)=\"onSearch($event)\"></app-header>\n    <ion-title>{{ page.pageTitle }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- search result section -->\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"isLoadingSearch\" size=\"2\" sizeSm=\"2\" sizeMd=\"2\" sizeLg=\"2\" offset=\"5\" offsetSm=\"5\" offsetMd=\"5\" offsetLg=\"5\">\n        <ion-spinner color=\"warning\"></ion-spinner>\n      </ion-col>\n      <ion-col *ngIf=\"searchData\" size=\"12\" sizeSm=\"12\" sizeMd=\"10\" sizeLg=\"8\" offsetMd=\"1\" offsetLg=\"2\">\n        <app-search-results [data]=\"searchData\"></app-search-results>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <!-- search result section ends -->\n\n  <!-- main page -->\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"page\">\n\n        <!-- page title -->\n        <h2 style=\"color: #888\" class=\"ion-text-center\">{{ page.title }}</h2>\n\n        <!-- page content section -->\n        <span id=\"page-content\"></span>\n\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <!-- main page -->\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_page-detail_page-detail_module_ts.js.map