(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_custom-checkout_custom-checkout_module_ts"],{

/***/ 65812:
/*!*******************************************************************!*\
  !*** ./src/app/custom-checkout/custom-checkout-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomCheckoutPageRoutingModule": () => (/* binding */ CustomCheckoutPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _custom_checkout_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./custom-checkout.page */ 36138);




const routes = [
    {
        path: '',
        component: _custom_checkout_page__WEBPACK_IMPORTED_MODULE_0__.CustomCheckoutPage
    }
];
let CustomCheckoutPageRoutingModule = class CustomCheckoutPageRoutingModule {
};
CustomCheckoutPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CustomCheckoutPageRoutingModule);



/***/ }),

/***/ 4872:
/*!***********************************************************!*\
  !*** ./src/app/custom-checkout/custom-checkout.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomCheckoutPageModule": () => (/* binding */ CustomCheckoutPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _custom_checkout_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./custom-checkout-routing.module */ 65812);
/* harmony import */ var _custom_checkout_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./custom-checkout.page */ 36138);







let CustomCheckoutPageModule = class CustomCheckoutPageModule {
};
CustomCheckoutPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _custom_checkout_routing_module__WEBPACK_IMPORTED_MODULE_0__.CustomCheckoutPageRoutingModule
        ],
        declarations: [_custom_checkout_page__WEBPACK_IMPORTED_MODULE_1__.CustomCheckoutPage]
    })
], CustomCheckoutPageModule);



/***/ }),

/***/ 36138:
/*!*********************************************************!*\
  !*** ./src/app/custom-checkout/custom-checkout.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomCheckoutPage": () => (/* binding */ CustomCheckoutPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_custom_checkout_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./custom-checkout.page.html */ 62805);
/* harmony import */ var _custom_checkout_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./custom-checkout.page.scss */ 73264);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);




let CustomCheckoutPage = class CustomCheckoutPage {
    constructor() { }
    ngOnInit() {
    }
};
CustomCheckoutPage.ctorParameters = () => [];
CustomCheckoutPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-custom-checkout',
        template: _raw_loader_custom_checkout_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_custom_checkout_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CustomCheckoutPage);



/***/ }),

/***/ 73264:
/*!***********************************************************!*\
  !*** ./src/app/custom-checkout/custom-checkout.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjdXN0b20tY2hlY2tvdXQucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 62805:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/custom-checkout/custom-checkout.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>custom-checkout</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_custom-checkout_custom-checkout_module_ts.js.map