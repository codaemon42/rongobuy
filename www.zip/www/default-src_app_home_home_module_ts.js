(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["default-src_app_home_home_module_ts"],{

/***/ 52003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 62267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/components.module */ 45642);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 52003);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page */ 62267);








let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_0__.ComponentsModule,
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_2__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 62267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home.page.html */ 49764);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 2610);
/* harmony import */ var _services_homepage_homepage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../services/homepage/homepage.service */ 40775);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../services/auth.service */ 37556);
/* harmony import */ var _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/device/ngx */ 77668);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _services_colors_colors_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/colors/colors.service */ 99562);
/* harmony import */ var _services_breakpoint_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/breakpoint.service */ 43489);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/category.service */ 54655);











/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable curly */
/* eslint-disable object-shorthand */
/* eslint-disable max-len */
let HomePage = class HomePage {
    constructor(device, platform, authService, colorsService, brkPointService, homepageService, categoryService) {
        this.device = device;
        this.platform = platform;
        this.authService = authService;
        this.colorsService = colorsService;
        this.brkPointService = brkPointService;
        this.homepageService = homepageService;
        this.categoryService = categoryService;
        this.logo = 'https://scontent.fdac22-1.fna.fbcdn.net/v/t1.6435-9/52384618_403447716890410_7519901944706498560_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=09cbfe&_nc_ohc=4vf2J_gHjV4AX9Iw4WH&_nc_ht=scontent.fdac22-1.fna&oh=cc8086e722ec06839a2993d3ac1852a3&oe=6180485F';
        this.image = 'https://scontent.fdac22-1.fna.fbcdn.net/v/t1.6435-9/243141730_1930955927087406_8439625270110780804_n.jpg?_nc_cat=102&ccb=1-5&_nc_sid=666b5a&_nc_ohc=zAXTa3xu9zgAX-Mzz2d&_nc_ht=scontent.fdac22-1.fna&oh=4c6324ea350ce5d6bdcb6adc428527bd&oe=617ED4F1';
        this.pImage = 'https://scontent.fdac22-1.fna.fbcdn.net/v/t1.6435-9/p960x960/196212923_938037606764749_8713735566665562108_n.jpg?_nc_cat=107&ccb=1-5&_nc_sid=730e14&_nc_ohc=7cDGYr4RfeUAX-XeiRq&_nc_ht=scontent.fdac22-1.fna&oh=6736547cb51ace26d76ca4d70c7a05f2&oe=618033C6';
        this.isLoadingSearch = false;
        this.mobileView = true;
        this.showSearch = false;
        this.sliderEl = null;
        this.sliderEl2 = null;
        this.banner = null;
        this.banner2 = null;
        this.banner3 = null;
    }
    ngOnInit() {
        this.platform.ready().then(res => {
            console.log('Device UUID is: ' + this.device);
        });
        this.setColors();
        this.setHomePage();
        this.sizeController();
        this.categoryService.fetchChildCat(4).subscribe(res => {
            this.phoneCategories = res.data;
        });
        //this.colorsService.getColors();
        this.slideOpts = {
            grabCursor: true,
            cubeEffect: {
                shadow: true,
                slideShadows: true,
                shadowOffset: 10,
                shadowScale: 0.64,
            },
            on: {
                beforeInit: function () {
                    const swiper = this;
                    swiper.classNames.push(`${swiper.params.containerModifierClass}cube`);
                    swiper.classNames.push(`${swiper.params.containerModifierClass}3d`);
                    const overwriteParams = {
                        slidesPerView: 1,
                        slidesPerColumn: 1,
                        slidesPerGroup: 1,
                        watchSlidesProgress: true,
                        resistanceRatio: 0,
                        spaceBetween: 0,
                        centeredSlides: false,
                        virtualTranslate: true,
                    };
                    this.params = Object.assign(this.params, overwriteParams);
                    this.originalParams = Object.assign(this.originalParams, overwriteParams);
                },
                setTranslate: function () {
                    const swiper = this;
                    const { $el, $wrapperEl, slides, width: swiperWidth, height: swiperHeight, rtlTranslate: rtl, size: swiperSize, } = swiper;
                    const params = swiper.params.cubeEffect;
                    const isHorizontal = swiper.isHorizontal();
                    const isVirtual = swiper.virtual && swiper.params.virtual.enabled;
                    let wrapperRotate = 0;
                    let $cubeShadowEl;
                    if (params.shadow) {
                        if (isHorizontal) {
                            $cubeShadowEl = $wrapperEl.find('.swiper-cube-shadow');
                            if ($cubeShadowEl.length === 0) {
                                $cubeShadowEl = swiper.$('<div class="swiper-cube-shadow"></div>');
                                $wrapperEl.append($cubeShadowEl);
                            }
                            $cubeShadowEl.css({ height: `${swiperWidth}px` });
                        }
                        else {
                            $cubeShadowEl = $el.find('.swiper-cube-shadow');
                            if ($cubeShadowEl.length === 0) {
                                $cubeShadowEl = swiper.$('<div class="swiper-cube-shadow"></div>');
                                $el.append($cubeShadowEl);
                            }
                        }
                    }
                    for (let i = 0; i < slides.length; i += 1) {
                        const $slideEl = slides.eq(i);
                        let slideIndex = i;
                        if (isVirtual) {
                            slideIndex = parseInt($slideEl.attr('data-swiper-slide-index'), 10);
                        }
                        let slideAngle = slideIndex * 90;
                        let round = Math.floor(slideAngle / 360);
                        if (rtl) {
                            slideAngle = -slideAngle;
                            round = Math.floor(-slideAngle / 360);
                        }
                        const progress = Math.max(Math.min($slideEl[0].progress, 1), -1);
                        let tx = 0;
                        let ty = 0;
                        let tz = 0;
                        if (slideIndex % 4 === 0) {
                            tx = -round * 4 * swiperSize;
                            tz = 0;
                        }
                        else if ((slideIndex - 1) % 4 === 0) {
                            tx = 0;
                            tz = -round * 4 * swiperSize;
                        }
                        else if ((slideIndex - 2) % 4 === 0) {
                            tx = swiperSize + (round * 4 * swiperSize);
                            tz = swiperSize;
                        }
                        else if ((slideIndex - 3) % 4 === 0) {
                            tx = -swiperSize;
                            tz = (3 * swiperSize) + (swiperSize * 4 * round);
                        }
                        if (rtl) {
                            tx = -tx;
                        }
                        if (!isHorizontal) {
                            ty = tx;
                            tx = 0;
                        }
                        const transform$$1 = `rotateX(${isHorizontal ? 0 : -slideAngle}deg) rotateY(${isHorizontal ? slideAngle : 0}deg) translate3d(${tx}px, ${ty}px, ${tz}px)`;
                        if (progress <= 1 && progress > -1) {
                            wrapperRotate = (slideIndex * 90) + (progress * 90);
                            if (rtl)
                                wrapperRotate = (-slideIndex * 90) - (progress * 90);
                        }
                        $slideEl.transform(transform$$1);
                        if (params.slideShadows) {
                            // Set shadows
                            let shadowBefore = isHorizontal ? $slideEl.find('.swiper-slide-shadow-left') : $slideEl.find('.swiper-slide-shadow-top');
                            let shadowAfter = isHorizontal ? $slideEl.find('.swiper-slide-shadow-right') : $slideEl.find('.swiper-slide-shadow-bottom');
                            if (shadowBefore.length === 0) {
                                shadowBefore = swiper.$(`<div class="swiper-slide-shadow-${isHorizontal ? 'left' : 'top'}"></div>`);
                                $slideEl.append(shadowBefore);
                            }
                            if (shadowAfter.length === 0) {
                                shadowAfter = swiper.$(`<div class="swiper-slide-shadow-${isHorizontal ? 'right' : 'bottom'}"></div>`);
                                $slideEl.append(shadowAfter);
                            }
                            if (shadowBefore.length)
                                shadowBefore[0].style.opacity = Math.max(-progress, 0);
                            if (shadowAfter.length)
                                shadowAfter[0].style.opacity = Math.max(progress, 0);
                        }
                    }
                    $wrapperEl.css({
                        '-webkit-transform-origin': `50% 50% -${swiperSize / 2}px`,
                        '-moz-transform-origin': `50% 50% -${swiperSize / 2}px`,
                        '-ms-transform-origin': `50% 50% -${swiperSize / 2}px`,
                        'transform-origin': `50% 50% -${swiperSize / 2}px`,
                    });
                    if (params.shadow) {
                        if (isHorizontal) {
                            $cubeShadowEl.transform(`translate3d(0px, ${(swiperWidth / 2) + params.shadowOffset}px, ${-swiperWidth / 2}px) rotateX(90deg) rotateZ(0deg) scale(${params.shadowScale})`);
                        }
                        else {
                            const shadowAngle = Math.abs(wrapperRotate) - (Math.floor(Math.abs(wrapperRotate) / 90) * 90);
                            const multiplier = 1.5 - ((Math.sin((shadowAngle * 2 * Math.PI) / 360) / 2)
                                + (Math.cos((shadowAngle * 2 * Math.PI) / 360) / 2));
                            const scale1 = params.shadowScale;
                            const scale2 = params.shadowScale / multiplier;
                            const offset$$1 = params.shadowOffset;
                            $cubeShadowEl.transform(`scale3d(${scale1}, 1, ${scale2}) translate3d(0px, ${(swiperHeight / 2) + offset$$1}px, ${-swiperHeight / 2 / scale2}px) rotateX(-90deg)`);
                        }
                    }
                    const zFactor = (swiper.browser.isSafari || swiper.browser.isUiWebView) ? (-swiperSize / 2) : 0;
                    $wrapperEl
                        .transform(`translate3d(0px,0,${zFactor}px) rotateX(${swiper.isHorizontal() ? 0 : wrapperRotate}deg) rotateY(${swiper.isHorizontal() ? -wrapperRotate : 0}deg)`);
                },
                setTransition: function (duration) {
                    const swiper = this;
                    const { $el, slides } = swiper;
                    slides
                        .transition(duration)
                        .find('.swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left')
                        .transition(duration);
                    if (swiper.params.cubeEffect.shadow && !swiper.isHorizontal()) {
                        $el.find('.swiper-cube-shadow').transition(duration);
                    }
                },
            }
        };
        this.emergencyCatSlider = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 2.2,
            spaceBetween: 1
        };
        this.catSlider = {
            initialSlide: 0,
            speed: 400,
            loop: true,
            slidesPerView: 3.9,
            spaceBetween: 1,
            autoplay: 1000,
            breakpoints: {
                // when window width is >= 320px
                320: {
                    slidesPerView: 3.7,
                    spaceBetween: 10
                },
                // when window width is >= 480px
                480: {
                    slidesPerView: 3.3,
                    spaceBetween: 30
                },
                // when window width is >= 640px
                768: {
                    slidesPerView: 3.9,
                    spaceBetween: 40
                },
                // when window width is >= 640px
                980: {
                    slidesPerView: 3.9,
                    spaceBetween: 40
                }
            }
        };
        this.catSlider2 = {
            initialSlide: 0,
            speed: 400,
            loop: true,
            slidesPerView: 1,
            spaceBetween: 10,
            autoplay: 1000,
            breakpoints: {
                // when window width is >= 320px
                320: {
                    slidesPerView: 1,
                    spaceBetween: 10
                },
                // when window width is >= 480px
                480: {
                    slidesPerView: 1,
                    spaceBetween: 10
                },
                // when window width is >= 640px
                768: {
                    slidesPerView: 1.9,
                    spaceBetween: 40
                },
                // when window width is >= 640px
                980: {
                    slidesPerView: 1.9,
                    spaceBetween: 40
                }
            }
        };
        this.emergencyInfo = [
            {
                id: '1',
                name: 'Customized Design',
                slug: 'delivery-charge',
                description: 'This is my page',
                link: this.pImage,
                type: 'below-header'
            },
            {
                id: '1',
                name: '7 days return',
                slug: 'delivery-charge',
                description: 'This is my page',
                link: this.pImage,
                type: 'below-header'
            },
            {
                id: '1',
                name: '15 days Refund',
                slug: 'delivery-charge',
                description: 'This is my page',
                link: this.pImage,
                type: 'below-header'
            },
            {
                id: '1',
                name: 'Secure Payment',
                slug: 'delivery-charge',
                description: 'This is my page',
                link: this.pImage,
                type: 'below-header'
            }
        ];
        setTimeout(() => {
            this.miniProducts = [
                {
                    id: '2',
                    title: 'Product One',
                    slug: 'product-slug-1',
                    featured_image: this.pImage,
                },
                {
                    id: '2',
                    title: 'Product One',
                    slug: 'product-slug-2',
                    featured_image: this.pImage,
                },
                {
                    id: '2',
                    title: 'Product One',
                    slug: 'product-slug-3',
                    featured_image: this.pImage,
                },
                {
                    id: '2',
                    title: 'Product One',
                    slug: 'product-slug-4',
                    featured_image: this.pImage,
                },
            ];
        }, 2000);
    }
    sliderNavigate(i) {
        console.log('selected slider : ', i);
        console.log('type : ', this.sliderEl[i].type);
        console.log('type : ', this.sliderEl[i].itemSlug);
    }
    onClickProduct(i) {
        console.log(this.miniProducts[i].slug);
    }
    onSearch(event) {
        console.log('new event created: ', event);
        this.searchData = event;
    }
    isLoading(event) {
        console.log('is loading', event);
        this.isLoadingSearch = event;
    }
    setColors() {
        this.colorsService.getColors();
        this.colorsService.randomColors.subscribe(res => {
            this.colors = res;
        });
        console.log(this.colors);
    }
    setHomePage() {
        this.homepageService.fetchHomePage().subscribe();
        this.homepageSub = this.homepageService.homepage.subscribe(res => {
            this.homepage = res;
            this.sliderEl = this.homepage.find(homepage => homepage.sectionTitle === 'slider');
            this.sliderEl2 = this.homepage.find(homepage => homepage.sectionTitle === 'Slider 2');
            this.banner = this.homepage.find(homepage => homepage.sectionTitle === 'Banner');
            this.banner2 = this.homepage.find(homepage => homepage.sectionTitle === 'Banner 2');
            this.banner3 = this.homepage.find(homepage => homepage.sectionTitle === 'Banner 3');
        });
    }
    sizeController() {
        this.brkPointService.size.subscribe(size => {
            console.log('size home : ', size);
            if (size === 'xs') {
                this.mobileView = true;
            }
            else {
                this.mobileView = false;
            }
        });
    }
    catSliderLoaded(event) {
        console.log('catslide : ', event);
    }
    ngOnDestroy() {
        this.homepageSub.unsubscribe();
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_4__.Device },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.Platform },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_colors_colors_service__WEBPACK_IMPORTED_MODULE_5__.ColorsService },
    { type: _services_breakpoint_service__WEBPACK_IMPORTED_MODULE_6__.BreakpointObserverService },
    { type: _services_homepage_homepage_service__WEBPACK_IMPORTED_MODULE_2__.HomepageService },
    { type: _services_category_service__WEBPACK_IMPORTED_MODULE_7__.CategoryService }
];
HomePage.propDecorators = {
    categorySlide: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild, args: ['categorySlide',] }]
};
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], HomePage);



/***/ }),

/***/ 54655:
/*!**********************************************!*\
  !*** ./src/app/services/category.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CategoryService": () => (/* binding */ CategoryService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 68307);






let CategoryService = class CategoryService {
    constructor(http) {
        this.http = http;
        this._categories = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
        this.images = [
            'https://images.unsplash.com/photo-1612012460576-5d51b5b04b00?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8d2FsbHBhcGVyJTIwZm9yJTIwbW9iaWxlfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80',
            'https://images.pexels.com/photos/799443/pexels-photo-799443.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
            'https://i.pinimg.com/564x/c4/2c/d3/c42cd325eb9e88ff4acd0b6914b9a3f0.jpg',
            'https://images.unsplash.com/photo-1611068813580-b07ef920964b?ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8d2FsbHBhcGVyJTIwZm9yJTIwbW9iaWxlfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80',
            'https://i.pinimg.com/originals/76/35/04/763504bd750c39bd9f3a053c70ebcf1b.jpg',
            'https://images.unsplash.com/photo-1612012460576-5d51b5b04b00?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8d2FsbHBhcGVyJTIwZm9yJTIwbW9iaWxlfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80',
            'https://images.pexels.com/photos/799443/pexels-photo-799443.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
            'https://i.pinimg.com/564x/c4/2c/d3/c42cd325eb9e88ff4acd0b6914b9a3f0.jpg',
            'https://images.unsplash.com/photo-1611068813580-b07ef920964b?ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8d2FsbHBhcGVyJTIwZm9yJTIwbW9iaWxlfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80',
            'https://i.pinimg.com/originals/76/35/04/763504bd750c39bd9f3a053c70ebcf1b.jpg'
        ];
    }
    get categories() {
        return this._categories.asObservable();
    }
    fetchCategories() {
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/all-category`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)(categories => {
            console.log('categories : ', categories);
            this._categories.next(categories);
        }));
    }
    fetchChildCat(parentId) {
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/get-category`, { parentId }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)(res => res.data));
    }
};
CategoryService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient }
];
CategoryService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], CategoryService);



/***/ }),

/***/ 99562:
/*!***************************************************!*\
  !*** ./src/app/services/colors/colors.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColorsService": () => (/* binding */ ColorsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 26215);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);



let ColorsService = class ColorsService {
    constructor() {
        this.colors = [
            'primary',
            'secondary',
            'success',
            'danger',
            'warning',
            'tertiary',
            'primary-shade',
            'primary-tint',
            'secondary-shade',
            'secondary-tint',
            'success-shade',
            'success-tint',
            'danger-shade',
            'danger-tint',
            'tertiary-shade',
            'tertiary-tint',
        ];
        this.randomColors = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject([]);
    }
    getColors() {
        const color = [];
        this.colors.map(res => {
            const bg = this.generateNumber();
            color.push(this.colors[bg]);
        });
        this.randomColors.next(color);
    }
    generateNumber() {
        const max = this.colors.length - 1;
        const min = 0;
        return Math.floor(Math.random() * (max - min + 1) + min);
    }
};
ColorsService.ctorParameters = () => [];
ColorsService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ColorsService);



/***/ }),

/***/ 40775:
/*!*******************************************************!*\
  !*** ./src/app/services/homepage/homepage.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomepageService": () => (/* binding */ HomepageService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 68307);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 26215);






let HomepageService = class HomepageService {
    constructor(http) {
        this.http = http;
        this._homepage = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
    }
    get homepage() {
        return this._homepage.asObservable();
    }
    fetchHomePage() {
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url.base}/homepage`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)(res => {
            console.log('homepage : ', res);
            this._homepage.next(res.data);
        }));
    }
};
HomepageService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient }
];
HomepageService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], HomepageService);



/***/ }),

/***/ 2610:
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".rb-logo-center {\n  margin: auto;\n  text-align: center;\n}\n\nion-header .main-header-menu {\n  padding-bottom: 20px;\n  border-radius: 0 0 30px 30px;\n}\n\nion-header ion-searchbar {\n  width: 90%;\n  margin: auto;\n  margin-top: auto;\n  margin-top: -30px;\n  z-index: 15;\n  --border-radius: 30px;\n}\n\nion-content {\n  --background: #fbfcff;\n}\n\nion-slides {\n  --bullet-background-active: var(--ion-color-warning);\n  --bullet-background: var(--ion-color-dark);\n  --scroll-bar-background: var(--ion-color-warning);\n  margin-bottom: 20px;\n}\n\n.rb-chat-icon {\n  bottom: 60px;\n}\n\n.rb-chat-icon ion-badge {\n  position: absolute;\n  top: 6px;\n  right: 6px;\n  border-radius: 50%;\n  width: 20px;\n  height: 20px;\n}\n\n.skeleton-img {\n  width: 100%;\n  height: 300px;\n}\n\n.rb-emergency-info {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n  align-items: center;\n  border-radius: 8px;\n  box-shadow: inset 6px 8px 8px 0 #0000003b;\n  width: 100%;\n  margin-left: 10px;\n}\n\n.rb-emergency-info .icon {\n  width: 20px;\n  height: 40px;\n  margin: 15px 10px;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n\n.rb-emergency-info ion-label {\n  font-size: 12px;\n  font-weight: bold;\n  color: var(--ion-color-dark-contrast-rgb);\n}\n\n.emergency-slider {\n  border-radius: 10px;\n  background: #00000012;\n  padding: 10px 0;\n}\n\n.poster-wrapper {\n  border: 1px solid #ff9c02;\n  border-radius: 10px;\n}\n\n.poster-wrapper .poster-label {\n  font-size: 14px;\n  text-align: center;\n  display: block;\n  text-shadow: 0px 1px #33333385;\n  color: #404040;\n}\n\n.cat-slider {\n  background: #95ff5a9c;\n  border-radius: 10px;\n  box-shadow: inset 0 8px 8px #3b3b3b45;\n}\n\n.cat-slider-2 {\n  background: #1b656f99;\n  border-radius: 10px;\n  box-shadow: inset 0 8px 8px #3b3b3ba1;\n}\n\n.rb-mini-product-list {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n}\n\n.rb-mini-product-list ion-chip {\n  --background: var(--ion-color-dark);\n  --color: var(--ion-color-warning);\n}\n\n.rb-footer-void {\n  width: 100%;\n  height: 50px;\n}\n\n.spinner {\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n}\n\n.banner31-containter {\n  width: 92%;\n  display: block;\n  margin: auto;\n}\n\n.banner31-containter .banner31-row {\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n}\n\n.banner31-containter .banner31-row .banner31-col-60 {\n  width: 89%;\n  padding-right: 5px;\n}\n\n.banner31-containter .banner31-row .banner31-col-40 {\n  width: 40%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n\n.banner31-containter .banner31-row .banner31-col-40 img {\n  padding-bottom: 5px;\n}\n\n.footer {\n  background-color: #333;\n}\n\n.footer ion-list {\n  background-color: #333;\n}\n\n.footer ion-list ion-list-header {\n  color: var(--ion-color-warning);\n  font-weight: bold;\n}\n\n.footer ion-list ion-item ion-label {\n  color: var(--ion-color-warning-tint);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0FBQUY7O0FBS0U7RUFDRSxvQkFBQTtFQUNBLDRCQUFBO0FBRko7O0FBS0U7RUFDRSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUFISjs7QUFRQTtFQUNFLHFCQUFBO0FBTEY7O0FBU0E7RUFDRSxvREFBQTtFQUNBLDBDQUFBO0VBQ0EsaURBQUE7RUFDQSxtQkFBQTtBQU5GOztBQWFBO0VBQ0UsWUFBQTtBQVZGOztBQVlFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFWSjs7QUFpQkE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtBQWRGOztBQW1CQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHlDQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FBaEJGOztBQWtCRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtBQWhCSjs7QUFtQkU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx5Q0FBQTtBQWpCSjs7QUFxQkE7RUFDRSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtBQWxCRjs7QUFxQkE7RUFDRSx5QkFBQTtFQUNBLG1CQUFBO0FBbEJGOztBQW1CRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSw4QkFBQTtFQUNBLGNBQUE7QUFqQko7O0FBc0JBO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLHFDQUFBO0FBbkJGOztBQXFCQTtFQUtFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtBQXRCRjs7QUEwQkE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0FBdkJGOztBQXlCSTtFQUNFLG1DQUFBO0VBQ0EsaUNBQUE7QUF2Qk47O0FBNEJBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUF6QkY7O0FBZ0NBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQTdCRjs7QUFxQ0E7RUFDRSxVQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFsQ0Y7O0FBb0NFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFsQ0o7O0FBb0NJO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0FBbENOOztBQW9DSTtFQUNFLFVBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBbENOOztBQW9DTTtFQUNFLG1CQUFBO0FBbENSOztBQTBDQTtFQUNFLHNCQUFBO0FBdkNGOztBQXlDRTtFQUNFLHNCQUFBO0FBdkNKOztBQXlDSTtFQUNFLCtCQUFBO0VBQ0EsaUJBQUE7QUF2Q047O0FBMkNNO0VBQ0Usb0NBQUE7QUF6Q1IiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBoZWFkZXJcclxuLnJiLWxvZ28tY2VudGVye1xyXG4gIG1hcmdpbjogYXV0bztcclxuICB0ZXh0LWFsaWduOmNlbnRlcjtcclxufVxyXG5cclxuaW9uLWhlYWRlcntcclxuXHJcbiAgLm1haW4taGVhZGVyLW1lbnV7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgMCAzMHB4IDMwcHg7XHJcbiAgfVxyXG5cclxuICBpb24tc2VhcmNoYmFye1xyXG4gICAgd2lkdGg6IDkwJTtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIG1hcmdpbi10b3A6IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAtMzBweDtcclxuICAgIHotaW5kZXg6IDE1O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gIH1cclxufVxyXG5cclxuLy8gY29udGVudFxyXG5pb24tY29udGVudHtcclxuICAtLWJhY2tncm91bmQ6ICNmYmZjZmY7XHJcbn1cclxuXHJcbi8vIHNsaWRlciBzZWN0aW9uXHJcbmlvbi1zbGlkZXMge1xyXG4gIC0tYnVsbGV0LWJhY2tncm91bmQtYWN0aXZlOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XHJcbiAgLS1idWxsZXQtYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gIC0tc2Nyb2xsLWJhci1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG4uc2xpZGVyLW1hcmdpbntcclxuICAvL21hcmdpbi10b3A6IDEwcHhcclxufVxyXG5cclxuLy8gY2hhdCBzZWN0aW9uXHJcbi5yYi1jaGF0LWljb24ge1xyXG4gIGJvdHRvbTogNjBweDtcclxuXHJcbiAgaW9uLWJhZGdlIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNnB4O1xyXG4gICAgcmlnaHQ6IDZweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG4gIH1cclxufVxyXG5cclxuXHJcbi8vQGF0LXJvb3RcclxuXHJcbi5za2VsZXRvbi1pbWd7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAzMDBweDtcclxufVxyXG5cclxuXHJcbi8vIGVtZXJnZW5jeSBzZWN0aW9uXHJcbi5yYi1lbWVyZ2VuY3ktaW5mbyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIGJveC1zaGFkb3c6aW5zZXQgNnB4IDhweCA4cHggMCAjMDAwMDAwM2I7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcblxyXG4gIC5pY29ue1xyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBtYXJnaW46IDE1cHggMTBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgfVxyXG5cclxuICBpb24tbGFiZWx7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyay1jb250cmFzdC1yZ2IpO1xyXG4gIH1cclxufVxyXG5cclxuLmVtZXJnZW5jeS1zbGlkZXJ7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBiYWNrZ3JvdW5kOiAjMDAwMDAwMTI7XHJcbiAgcGFkZGluZzogMTBweCAwO1xyXG59XHJcblxyXG4ucG9zdGVyLXdyYXBwZXJ7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmOWMwMjtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIC5wb3N0ZXItbGFiZWx7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHRleHQtc2hhZG93OiAwcHggMXB4ICMzMzMzMzM4NTtcclxuICAgIGNvbG9yOiAjNDA0MDQwO1xyXG4gIH1cclxufVxyXG5cclxuLy8gY2F0ZWdvcnkgc2xpZGVyXHJcbi5jYXQtc2xpZGVyIHtcclxuICBiYWNrZ3JvdW5kOiAjOTVmZjVhOWM7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBib3gtc2hhZG93OiBpbnNldCAwIDhweCA4cHggIzNiM2IzYjQ1O1xyXG59XHJcbi5jYXQtc2xpZGVyLTIge1xyXG4gIC8vIGJhY2tncm91bmQ6ICM1YWZmYjk1OTtcclxuICAvLyBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIC8vIGJveC1zaGFkb3c6IGluc2V0IDAgOHB4IDhweCAjM2IzYjNiNDU7XHJcblxyXG4gIGJhY2tncm91bmQ6ICMxYjY1NmY5OTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJveC1zaGFkb3c6IGluc2V0IDAgOHB4IDhweCAjM2IzYjNiYTE7XHJcbn1cclxuXHJcbi8vIHByb2R1Y3Qgc2VjdGlvblxyXG4ucmItbWluaS1wcm9kdWN0LWxpc3Qge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBib3R0b206IDA7XHJcbiAgcmlnaHQ6IDA7XHJcblxyXG4gICAgaW9uLWNoaXAge1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xyXG4gICAgfVxyXG59XHJcblxyXG4vLyBmb290ZXIgc2VjdGlvblxyXG4ucmItZm9vdGVyLXZvaWQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogNTBweDtcclxufVxyXG5cclxuLy8gYm9yZGVyOiA0cHggc29saWQgI0ZGQzQwOTtcclxuLy8gYm94LXNoYWRvdzogMCA4cHggOHB4ICMwMDA7XHJcblxyXG5cclxuLnNwaW5uZXJ7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLy8gaW9uLXJvd3tcclxuLy8gICBib3JkZXI6IDFweCBzb2xpZCBibHVlO1xyXG4vLyB9XHJcbi8vIGlvbi1jb2x7XHJcbi8vICAgYm9yZGVyOiAxcHggc29saWQgcmVkO1xyXG4vLyB9XHJcbi5iYW5uZXIzMS1jb250YWludGVyIHtcclxuICB3aWR0aDogOTIlO1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIG1hcmdpbjogYXV0bztcclxuXHJcbiAgLmJhbm5lcjMxLXJvd3tcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgLmJhbm5lcjMxLWNvbC02MHtcclxuICAgICAgd2lkdGg6IDg5JTtcclxuICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xyXG4gICAgfVxyXG4gICAgLmJhbm5lcjMxLWNvbC00MHtcclxuICAgICAgd2lkdGg6IDQwJTtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICBpbWd7XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuXHJcbi8vIGZvb3RlclxyXG4uZm9vdGVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzO1xyXG5cclxuICBpb24tbGlzdHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMzMzM7XHJcblxyXG4gICAgaW9uLWxpc3QtaGVhZGVye1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xyXG4gICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIH1cclxuXHJcbiAgICBpb24taXRlbXtcclxuICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZy10aW50KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 49764:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<app-header [showSearch]=\"showSearch\" (isLoadingSearch)=\"isLoading($event)\" (searchTextFound)=\"onSearch($event)\" [searchData]=\"searchData\"></app-header>\n\n<ion-content>\n  <!-- fab icon section -->\n\t<!-- <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n\t\t<ion-fab-button color=\"danger\">\n\t\t\t<ion-icon name=\"cart\"></ion-icon>\n\t\t</ion-fab-button>\n\t</ion-fab> -->\n      <!-- chat section -->\n      <ion-fab class=\"rb-chat-icon\" vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n        <ion-fab-button color=\"warning\">\n          <ion-icon name=\"chatbubbles\"></ion-icon>\n          <ion-badge color=\"danger\">1</ion-badge>\n        </ion-fab-button>\n      </ion-fab>\n\n  <!-- slider 1 section -->\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col *ngIf=\"sliderEl\">\n        <ion-slides [ngClass]=\"{'slider-margin': !mobileView}\" pager=\"true\" scrollbar=\"true\" [options]=\"slideOpts\">\n          <ion-slide *ngFor=\"let slide of sliderEl.sectioncontent;let i=index\" (click)=\"sliderNavigate(i)\">\n            <ion-img [src]=\"slide.imageUrl+'_1500x600.jpg'\"></ion-img>\n          </ion-slide>\n        </ion-slides>\n      </ion-col>\n      <ion-col *ngIf=\"!sliderEl\">\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\t<!-- <ion-list>\n\t\t<ion-item-sliding>\n\t\t\t<ion-item>\n\t\t\t\t<ion-label>\n\t\t\t\t\tSliding Item, Icons Bottom\n\t\t\t\t</ion-label>\n\t\t\t</ion-item>\n\t\t\t<ion-item-options>\n\t\t\t\t<ion-item-option color=\"primary\">\n\t\t\t\t\t<ion-icon slot=\"bottom\" ios=\"ellipsis-horizontal\" md=\"ellipsis-vertical\"></ion-icon>\n\t\t\t\t\tMore\n\t\t\t\t</ion-item-option>\n\t\t\t\t<ion-item-option color=\"secondary\">\n\t\t\t\t\t<ion-icon slot=\"bottom\" name=\"archive\"></ion-icon>\n\t\t\t\t\tArchive\n\t\t\t\t</ion-item-option>\n\t\t\t</ion-item-options>\n\t\t</ion-item-sliding>\n\t</ion-list> -->\n\n  <!-- emergency info -->\n  <ion-grid *ngIf=\"!mobileView\">\n    <ion-row>\n      <ion-col sizeLg=\"3\" sizeMd=\"3\" sizeSm=\"6\" *ngFor=\"let emergency of emergencyInfo; let i = index\">\n        <div class=\"rb-emergency-info\" [ngStyle]=\"{'background': 'var(--ion-color-'+colors[i]+')'}\">\n          <div class=\"icon\">\n            <!-- <img [src]=\"emergency.link\" alt=\"icon\"> -->\n            <ion-icon color=\"light\" name=\"accessibility\"></ion-icon>\n          </div>\n          <ion-label>{{emergency.name}}</ion-label>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid *ngIf=\"mobileView\">\n    <ion-row>\n      <ion-col>\n        <ion-slides class=\"emergency-slider\" pager=\"true\" scrollbar=\"false\" [options]=\"emergencyCatSlider\">\n          <ion-slide *ngFor=\"let emergency of emergencyInfo; let i = index\">\n                    <div class=\"rb-emergency-info\" [ngStyle]=\"{'background': 'var(--ion-color-'+colors[i]+')'}\">\n                <div class=\"icon\">\n                  <!-- <img [src]=\"emergency.link\" alt=\"icon\"> -->\n                  <ion-icon color=\"light\" name=\"accessibility\"></ion-icon>\n                </div>\n                <ion-label style=\"margin: 10px; text-align: left;\">{{emergency.name}}</ion-label>\n              </div>\n          </ion-slide>\n        </ion-slides>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <!-- category sections -->\n  <ion-grid>\n    <ion-row>\n      <ion-col [routerLink]=\"['/', 'phone-customizer']\" class=\"poster-wrapper\" size=\"4\">\n        <ion-img src=\"../../assets/bg/poster.png\"></ion-img>\n        <ion-label class=\"poster-label\">Customize</ion-label>\n      </ion-col>\n      <ion-col [routerLink]=\"['/', 'category', 'phone-cover']\" class=\"poster-wrapper\" size=\"4\">\n        <ion-img src=\"../../assets/bg/poster.png\"></ion-img>\n        <ion-label class=\"poster-label\"> Men Cover </ion-label>\n      </ion-col>\n      <ion-col [routerLink]=\"['/', 'category', 'phone-cover']\" class=\"poster-wrapper\" size=\"4\">\n        <ion-img src=\"../../assets/bg/poster.png\"></ion-img>\n        <ion-label class=\"poster-label\"> Women Cover </ion-label>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <!-- Popular category -->\n  <ion-grid>\n    <ion-row>\n      <ion-col class=\"ion-text-center\">\n        <ion-label class=\"ion-text-center\" color=\"dark\">DESIGNER PHONE CASES</ion-label>\n        <br>\n        <ion-label class=\"ion-text-center\" color=\"dark\">Starts from 299 Taka</ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"11\" offset=\"0.5\">\n        <ion-slides #categorySlide class=\"cat-slider\" pager=\"true\" scrollbar=\"false\" [options]=\"catSlider\" (ionSlidesDidLoad)=\"catSliderLoaded($event)\" (ionSlideNextStart)=\"catSliderLoaded($event)\">\n          <ion-slide *ngFor=\"let phoneCat of phoneCategories; let i = index\">\n            <ion-card [ngStyle]=\"{'background': 'var(--ion-color-'+colors[i+2]+')'}\">\n              <ion-img [src]=\"phoneCat.image\"></ion-img>\n            </ion-card>\n          </ion-slide>\n        </ion-slides>\n      </ion-col>\n    </ion-row>\n      <!-- <ion-row>\n      <ion-col size=\"11\" offset=\"0.5\">\n        <ion-slides class=\"cat-slider-2\" pager=\"true\" scrollbar=\"false\" [options]=\"catSlider2\">\n          <ion-slide>\n            <ion-card>\n              <ion-img src=\"https://media.rongobuy.com/p/product/0ew5fg1orzxcm63t2kshqnyjiu8a47.jpg\"></ion-img>\n            </ion-card>\n\n          </ion-slide>\n          <ion-slide>\n\n            <ion-card>\n              <ion-img src=\"https://media.rongobuy.com/p/product/4n8m75i29qrdwsabfcjo0e6kytv1lh.png\"></ion-img>\n            </ion-card>\n\n          </ion-slide>\n          <ion-slide>\n\n            <ion-card>\n              <ion-img src=\"https://media.rongobuy.com/p/product/67ra30v9uxogqypk1cz58lediwhs2t.png\"></ion-img>\n            </ion-card>\n\n          </ion-slide>\n          <ion-slide>\n\n            <ion-card>\n              <ion-img src=\"https://media.rongobuy.com/p/product/9sc1z7258xrvhwmnobqealdi6gk34p.png\"></ion-img>\n            </ion-card>\n          </ion-slide>\n          <ion-slide>\n\n            <ion-card>\n              <ion-img src=\"https://media.rongobuy.com/p/product/640mng78kd21rujcblexhyqwf3ptao.png\"></ion-img>\n            </ion-card>\n          </ion-slide>\n          <ion-slide>\n            <ion-card>\n              <ion-img src=\"https://media.rongobuy.com/p/product/2c3kresf74wph6lzqa1y5jimvxbn8o.png\"></ion-img>\n            </ion-card>\n          </ion-slide>\n        </ion-slides>\n      </ion-col>\n    </ion-row> -->\n  </ion-grid>\n  <!-- Popular category --/>\n\n  <!-- product section -->\n    <!-- skeleton -->\n  <div *ngIf=\"!miniProducts\">\n    <div class=\"ion-padding custom-skeleton\">\n      <div class=\"skeleton-img\">\n        <ion-skeleton-text animated style=\"width: 100%; height:300px\"></ion-skeleton-text>\n      </div>\n    </div>\n  </div>\n\n\n  <!-- slider 2 section -->\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"sliderEl2\" size=\"11\" offset=\"0.5\">\n        <ion-slides class=\"cat-slider-2\" pager=\"true\" scrollbar=\"false\" [options]=\"catSlider\">\n          <ion-slide *ngFor=\"let slide of sliderEl2.sectioncontent; let i = index\">\n            <ion-card [ngStyle]=\"{'background': 'var(--ion-color-'+colors[i+2]+')'}\">\n              <ion-img [src]=\"slide.imageUrl\"></ion-img>\n            </ion-card>\n          </ion-slide>\n        </ion-slides>\n      </ion-col>\n      <ion-col *ngIf=\"!sliderEl2\">\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <!-- banner 3:1 -->\n  <div *ngIf=\"banner\" class=\"banner31-containter\">\n    <div *ngIf=\"banner.isActive\" class=\"banner31-row\">\n      <div class=\"banner31-col-60\">\n        <img [src]=\"banner.sectioncontent[0].imageUrl\">\n      </div>\n      <div class=\"banner31-col-40\">\n        <img [src]=\"banner.sectioncontent[1].imageUrl\">\n        <img [src]=\"banner.sectioncontent[2].imageUrl\">\n      </div>\n    </div>\n  </div>\n  <!-- <ion-grid *ngIf=\"banner\">\n    <ion-row *ngIf=\"banner.isActive\">\n      <ion-col size=\"8\" style=\"padding: 10px 0\">\n        <img [src]=\"banner.sectioncontent[0].imageUrl\">\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-row class=\"ion-no-padding\">\n          <ion-col class=\"ion-no-padding\">\n            <img [src]=\"banner.sectioncontent[1].imageUrl\">\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"ion-no-padding\">\n          <ion-col class=\"ion-no-padding\">\n            <img [src]=\"banner.sectioncontent[2].imageUrl\">\n          </ion-col>\n        </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid> -->\n  <ion-grid *ngIf=\"!banner\">\n    <ion-row>\n      <ion-col>\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <!-- banner 2 section -->\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col *ngIf=\"banner2\" size=\"11\" offset=\"0.5\">\n        <ion-slides pager=\"true\" scrollbar=\"false\" [options]=\"catSlider2\">\n          <ion-slide *ngFor=\"let slide of banner2.sectioncontent; let i = index\">\n            <ion-card class=\"ion-no-margin\" [ngStyle]=\"{'background': 'var(--ion-color-'+colors[i+2]+')'}\">\n              <ion-img [src]=\"slide.imageUrl\"></ion-img>\n            </ion-card>\n          </ion-slide>\n        </ion-slides>\n      </ion-col>\n      <ion-col *ngIf=\"!sliderEl2\">\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n<!-- banner 3 section -->\n  <ion-grid *ngIf=\"!banner3\">\n    <ion-row>\n      <ion-col>\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid *ngIf=\"banner3\">\n    <ion-row *ngIf=\"banner3.isActive\">\n        <ion-col size=\"12\" *ngFor=\"let banner of banner3.sectioncontent\">\n          <ion-img [src]=\"banner.imageUrl\"></ion-img>\n        </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-no-padding\">\n        <!-- footer void -->\n        <div class=\"rb-footer-void\"></div>\n\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid class=\"footer\">\n    <ion-row>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" sizeLg=\"4\">\n        <ion-list>\n          <ion-list-header>Customer Care</ion-list-header>\n          <ion-item [routerLink]=\"['/', '']\" color=\"dark\">\n            <ion-label>Terms & Conditions</ion-label>\n          </ion-item>\n          <ion-item color=\"dark\">\n            <ion-label>Contact Us</ion-label>\n          </ion-item>\n          <ion-item color=\"dark\">\n            <ion-label>Return and Refund policy</ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" sizeLg=\"4\">\n        <ion-list>\n          <ion-list-header>Rongobuy</ion-list-header>\n          <ion-item color=\"dark\">\n            <ion-label>About Us</ion-label>\n          </ion-item>\n          <ion-item color=\"dark\">\n            <ion-label>Privacy Policy</ion-label>\n          </ion-item>\n          <ion-item color=\"dark\">\n            <ion-label>Career</ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" sizeLg=\"4\">\n        <ion-list>\n          <ion-list-header>Connect with us</ion-list-header>\n          <ion-item color=\"dark\">\n            <ion-buttons>\n              <ion-button>\n                <a href=\"https://www.facebook.com/rongobuy/\" target=\"_blank\" rel=\"noopener\">\n                  <ion-icon color=\"light\" slot=\"icon-only\" name=\"logo-facebook\"></ion-icon>\n                </a>\n              </ion-button>\n            </ion-buttons>\n            <ion-label >160K people like this</ion-label>\n          </ion-item>\n          <ion-item color=\"dark\">\n            <ion-buttons>\n              <ion-button>\n                <a href=\"https://www.instagram.com/rongobuy/\" target=\"_blank\" rel=\"noopener\">\n                  <ion-icon color=\"light\" slot=\"icon-only\" name=\"logo-instagram\"></ion-icon>\n                </a>\n              </ion-button>\n              <ion-button>\n                <a href=\"https://www.pinterest.com/rongobuy/\" target=\"_blank\" rel=\"noopener\">\n                  <ion-icon color=\"light\" slot=\"icon-only\" name=\"logo-pinterest\"></ion-icon>\n                </a>\n              </ion-button>\n              <ion-button>\n                <a href=\"https://www.linkedin.com/company/rongobuy/\" target=\"_blank\" rel=\"noopener\">\n                  <ion-icon color=\"light\" slot=\"icon-only\" name=\"logo-linkedin\"></ion-icon>\n                </a>\n              </ion-button>\n              <ion-button>\n                <a href=\"https://twitter.com/rongobuy/\" target=\"_blank\" rel=\"noopener\">\n                  <ion-icon color=\"light\" slot=\"icon-only\" name=\"logo-twitter\"></ion-icon>\n                </a>\n              </ion-button>\n            </ion-buttons>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\" offset=\"3\">\n        <ion-note>© All Rights Reserved | Rongobuy private Limited</ion-note>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n</ion-content>\n\n\n");

/***/ })

}]);
//# sourceMappingURL=default-src_app_home_home_module_ts.js.map