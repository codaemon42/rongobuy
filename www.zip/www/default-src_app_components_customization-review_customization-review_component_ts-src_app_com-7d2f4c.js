(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"],{

/***/ 32685:
/*!***********************************************************************************!*\
  !*** ./src/app/components/customization-review/customization-review.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomizationReviewComponent": () => (/* binding */ CustomizationReviewComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_customization_review_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./customization-review.component.html */ 40036);
/* harmony import */ var _customization_review_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customization-review.component.scss */ 64883);
/* harmony import */ var _phone_customizer_custom_order_custom_order_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../phone-customizer/custom-order/custom-order.page */ 91851);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 80476);






let CustomizationReviewComponent = class CustomizationReviewComponent {
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
    }
    ngOnInit() {
        const start = 'data:image/svg+xml;charset=utf-8'.length;
        const preview = this.dataUrl.slice(start + 1, this.dataUrl.length);
        //this.img.nativeElement.style.background = '#333';
        document.getElementById('preview').innerHTML = preview;
    }
    confirmPreview(confirm) {
        this.modalCtrl.dismiss({
            confirm,
            buy: false
        });
    }
    onPurchase() {
        this.modalCtrl.dismiss({
            confirm,
            buy: true
        });
        this.modalCtrl.create({
            component: _phone_customizer_custom_order_custom_order_page__WEBPACK_IMPORTED_MODULE_2__.CustomOrderPage,
            componentProps: {
                text: this.dataUrl,
            },
            cssClass: 'preview-modal'
        }).then(el => el.present());
    }
};
CustomizationReviewComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController }
];
CustomizationReviewComponent.propDecorators = {
    dataUrl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
CustomizationReviewComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-customization-review',
        template: _raw_loader_customization_review_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_customization_review_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CustomizationReviewComponent);



/***/ }),

/***/ 14388:
/*!*******************************************************************************!*\
  !*** ./src/app/components/text-editor-screen/text-editor-screen.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TextEditorScreenComponent": () => (/* binding */ TextEditorScreenComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_text_editor_screen_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./text-editor-screen.component.html */ 83125);
/* harmony import */ var _text_editor_screen_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./text-editor-screen.component.scss */ 72582);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 80476);



/* eslint-disable @typescript-eslint/naming-convention */


;
let TextEditorScreenComponent = class TextEditorScreenComponent {
    // styleParams = {
    //   color: '#333',
    //   font: {
    //     size: 12,
    //     weight: 400,
    //   },
    //   transform: {
    //     text: 'capitalize',
    //     scale: 1,
    //     rotate: 0
    //   }
    // };
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
        this.title = 'Edit Text';
    }
    ngOnInit() {
        console.log('styleParams : ', this.styleParams);
    }
    confirmPreview(confirm) {
        this.textEditor = {
            confirm,
            text: this.text,
            styleParams: this.styleParams
        };
        this.modalCtrl.dismiss({
            confirm,
            text: this.text,
            styleParams: this.styleParams
        });
    }
    fontSize(event) {
        console.log(event);
        this.styleParams.font.size = event;
    }
    fontWeight(event) {
        console.log(event);
        this.styleParams.font.weight = event;
    }
    scale(event) {
        console.log(event);
        this.styleParams.transform.scale = event / 10;
        console.log(event / 10);
    }
    rotate(event) {
        console.log(event);
        this.styleParams.transform.rotate = event;
    }
};
TextEditorScreenComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController }
];
TextEditorScreenComponent.propDecorators = {
    text: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    styleParams: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
TextEditorScreenComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-text-editor-screen',
        template: _raw_loader_text_editor_screen_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_text_editor_screen_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TextEditorScreenComponent);



/***/ }),

/***/ 91851:
/*!********************************************************************!*\
  !*** ./src/app/phone-customizer/custom-order/custom-order.page.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomOrderPage": () => (/* binding */ CustomOrderPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_custom_order_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./custom-order.page.html */ 75395);
/* harmony import */ var _custom_order_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./custom-order.page.scss */ 43141);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var src_app_account_account_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/account/account.service */ 10740);
/* harmony import */ var src_app_services_address_address_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/address/address.service */ 47172);
/* harmony import */ var src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/cart.service */ 90910);
/* harmony import */ var src_app_services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/controllers/toast.service */ 41048);
/* harmony import */ var src_app_services_orders_order_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/orders/order.service */ 53675);











let CustomOrderPage = class CustomOrderPage {
    constructor(nav, loadingCtrl, toastService, cartService, addressService, accountService, orderService) {
        this.nav = nav;
        this.loadingCtrl = loadingCtrl;
        this.toastService = toastService;
        this.cartService = cartService;
        this.addressService = addressService;
        this.accountService = accountService;
        this.orderService = orderService;
        this.sendGift = false;
        this.cartLoading = true;
        this.selectedAddress = null;
        this.addressLoading = true;
    }
    ngOnInit() {
        this.giftFormInit();
        this.addressInit();
        this.cartServiceInit();
    }
    giftFormInit() {
        this.giftForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup({
            message: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
            }),
            sender: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null, {
                updateOn: 'change',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
            })
        });
    }
    addressInit() {
        this.addressLoading = true;
        this.addressService.fetchAddress().subscribe(res => {
            this.addressLoading = false;
            this.selectedAddress = res.data.data.filter(address => address.default === '1')[0];
        });
        this.addressSub = this.addressService.address.subscribe(addresses => {
            this.addresses = addresses;
        });
        console.log('selected Address : ', this.selectedAddress);
    }
    cartServiceInit() {
        this.cartLoading = true;
        this.cartService.fetchCartObj().subscribe(res => {
            this.cartLoading = false;
        });
        this.cartSub = this.cartService.cartDetails.subscribe(res => {
            this.cartDetails = res;
        });
    }
    ionViewWillEnter() {
        this.cartLoading = true;
        this.cartService.fetchCartObj().subscribe(res => {
            this.cartLoading = false;
        });
        console.log('cart ion view');
        this.addressLoading = true;
        this.addressService.fetchAddress().subscribe(res => {
            this.addressLoading = false;
        });
    }
    onSelectAddress(addressId) {
        this.selectedAddress = this.addresses.filter(address => address.id === addressId)[0];
        console.log('selected Address : ', this.selectedAddress);
    }
    addNewAddress() {
        this.nav.navigateForward('account/address/add-address');
    }
    onPlacingOrder() {
        const gift = {
            isGift: 0,
            message: '',
            from: ''
        };
        if (this.sendGift) {
            gift.isGift = 1;
            gift.message = this.giftForm.value.message;
            gift.from = this.giftForm.value.sender;
        }
        this.loadingCtrl.create({
            message: 'Placing order',
            mode: 'ios'
        }).then(el => {
            el.present();
            this.orderService.addCustomOrder(this.selectedAddress.id, this.text, gift.isGift, gift.message, gift.from).subscribe(res => {
                console.log('custom order res : ', res);
                this.loadingCtrl.dismiss();
                this.toastService.toast('Order placed successfully', 'success', 3000);
                this.nav.navigateForward('/all/orders');
            });
        });
    }
    // helper
    sendAsGift(event) {
        console.log('check box event : ', event);
        this.sendGift = !this.sendGift;
    }
    ngOnDestroy() {
        this.cartSub.unsubscribe();
        this.addressSub.unsubscribe();
    }
};
CustomOrderPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: src_app_services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_4__.CartService },
    { type: src_app_services_address_address_service__WEBPACK_IMPORTED_MODULE_3__.AddressService },
    { type: src_app_account_account_service__WEBPACK_IMPORTED_MODULE_2__.AccountService },
    { type: src_app_services_orders_order_service__WEBPACK_IMPORTED_MODULE_6__.OrderService }
];
CustomOrderPage.propDecorators = {
    text: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input }]
};
CustomOrderPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-custom-order',
        template: _raw_loader_custom_order_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_custom_order_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CustomOrderPage);



/***/ }),

/***/ 64883:
/*!*************************************************************************************!*\
  !*** ./src/app/components/customization-review/customization-review.component.scss ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#preview {\n  display: block;\n  text-align: center;\n}\n\n.preview-modal {\n  --height: 90%;\n  --border-radius: 10px;\n}\n\n.buy {\n  display: block;\n  width: 80%;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbWl6YXRpb24tcmV2aWV3LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0EscUJBQUE7QUFDRjs7QUFHQTtFQUNFLGNBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQUFGIiwiZmlsZSI6ImN1c3RvbWl6YXRpb24tcmV2aWV3LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI3ByZXZpZXd7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4ucHJldmlldy1tb2RhbHtcclxuICAtLWhlaWdodDogOTAlO1xyXG4gIC0tYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuXHJcbi5idXl7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBtYXJnaW46IGF1dG87XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 72582:
/*!*********************************************************************************!*\
  !*** ./src/app/components/text-editor-screen/text-editor-screen.component.scss ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content .text-box {\n  min-height: 200px;\n  background: #616161;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  box-shadow: inset 0px 3px 10px #000;\n  width: 97%;\n  margin: auto;\n}\nion-content .text-box span {\n  min-height: 100px;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\nion-content .text-input {\n  width: 95%;\n  margin: 10px auto;\n}\nion-content .text-input ion-input {\n  border: 1px solid #0e0e0e00;\n  width: 100%;\n  background: #19191966;\n  color: #888;\n  border-radius: 5px;\n  min-height: 35px;\n  box-shadow: 0 5px 5px #0000004f;\n  text-align: center;\n}\nion-content .text-transforms .color-picker {\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n}\nion-content .text-transforms .color-picker span {\n  width: 80%;\n  font-size: 12px;\n  font-weight: 400;\n  color: var(--ion-color-medium-shade);\n}\nion-content .text-transforms ion-list {\n  background: transparent;\n}\nion-content .text-transforms ion-list ion-item {\n  --background: #0000;\n}\nion-content .text-transforms ion-list ion-item ion-note {\n  padding-top: 42px;\n  margin-right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRleHQtZWRpdG9yLXNjcmVlbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUNBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQUZKO0FBSUk7RUFDRSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFGTjtBQU1FO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0FBSko7QUFNSTtFQUNFLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQkFBQTtFQUNBLGtCQUFBO0FBSk47QUFTSTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFQTjtBQVNNO0VBQ0UsVUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG9DQUFBO0FBUFI7QUFVSTtFQUNFLHVCQUFBO0FBUk47QUFTTTtFQUNFLG1CQUFBO0FBUFI7QUFTUTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtBQVBWIiwiZmlsZSI6InRleHQtZWRpdG9yLXNjcmVlbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC50ZXh0LWJveCB7XHJcbiAgICBtaW4taGVpZ2h0OiAyMDBweDtcclxuICAgIGJhY2tncm91bmQ6ICM2MTYxNjE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJveC1zaGFkb3c6IGluc2V0IDBweCAzcHggMTBweCAjMDAwO1xyXG4gICAgd2lkdGg6IDk3JTtcclxuICAgIG1hcmdpbjogYXV0bztcclxuXHJcbiAgICBzcGFuIHtcclxuICAgICAgbWluLWhlaWdodDogMTAwcHg7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLnRleHQtaW5wdXR7XHJcbiAgICB3aWR0aDogOTUlO1xyXG4gICAgbWFyZ2luOiAxMHB4IGF1dG87XHJcblxyXG4gICAgaW9uLWlucHV0e1xyXG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjMGUwZTBlMDA7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjMTkxOTE5NjY7XHJcbiAgICAgIGNvbG9yOiAjODg4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgIG1pbi1oZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGJveC1zaGFkb3c6IDAgNXB4IDVweCAjMDAwMDAwNGY7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC50ZXh0LXRyYW5zZm9ybXMge1xyXG4gICAgLmNvbG9yLXBpY2tlcntcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICBzcGFue1xyXG4gICAgICAgIHdpZHRoOiA4MCU7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpb24tbGlzdCB7XHJcbiAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMDAwMDtcclxuXHJcbiAgICAgICAgaW9uLW5vdGUge1xyXG4gICAgICAgICAgcGFkZGluZy10b3A6IDQycHg7XHJcbiAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 43141:
/*!**********************************************************************!*\
  !*** ./src/app/phone-customizer/custom-order/custom-order.page.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (":host ::ng-deep .p-dropdown {\n  width: 100%;\n  border-radius: 4px;\n  box-shadow: 0 8px 8px 0 #0000001c;\n  padding-left: 20px;\n  border: none;\n  border-top: 0.5px solid #0808080a;\n  border-bottom: 0;\n  border-left: 0;\n  border-right: 0;\n}\n\nion-content {\n  --background: #F5F4F9;\n}\n\n.country-item-value img.flag {\n  width: 17px;\n}\n\n.gift-box-wrapper {\n  box-shadow: inset 0px 0px 12px 6px #00000012;\n  margin: 10px 0;\n  padding: 10px 5px;\n  border-radius: 5px;\n}\n\n.gift-box-wrapper .gift-box {\n  border: 1px solid #00000024;\n  padding: 0;\n  border-radius: 2px;\n}\n\n.gift-box-wrapper .gift-box .rb-gift-textarea {\n  margin: 0;\n}\n\n.gift-box-wrapper .gift-box ion-input {\n  line-height: 2;\n}\n\n.gift-box-wrapper .gift-box .gift-box-text {\n  text-align: center;\n  font-weight: bold;\n  color: #888;\n}\n\n.payment-section {\n  border: 1px solid #5effb4;\n  padding: 10px;\n  border-radius: 10px;\n}\n\n.payment-section .order-review-section {\n  display: flex;\n  flex-direction: column;\n  color: #666;\n}\n\n.payment-section .order-review-section .shipping-cost-section {\n  display: flex;\n  flex-direction: row;\n}\n\n.payment-section .order-review-section .shipping-cost-section .shipping-label {\n  width: 40%;\n}\n\n.payment-section .order-review-section .shipping-cost-section .shipping-total {\n  width: 60%;\n  text-align: right;\n  padding-right: 10px;\n}\n\n.payment-section .order-review-section .order-amount-section {\n  display: flex;\n  flex-direction: row;\n}\n\n.payment-section .order-review-section .order-amount-section .total-ordered-amount-text {\n  width: 40%;\n}\n\n.payment-section .order-review-section .order-amount-section .total-ordered-amount {\n  width: 60%;\n  text-align: right;\n  padding-right: 10px;\n}\n\n.payment-section .order-review-section .grand-total-section {\n  display: flex;\n  flex-direction: row;\n  font-weight: bold;\n  color: #333;\n}\n\n.payment-section .order-review-section .grand-total-section .grand-total-label {\n  width: 40%;\n}\n\n.payment-section .order-review-section .grand-total-section .grand-total-amount {\n  width: 60%;\n  text-align: right;\n  padding-right: 10px;\n}\n\n.payment-section .payment-method-section {\n  margin-top: 15px;\n  border-radius: 10px;\n}\n\n.payment-section .payment-method-section ion-label {\n  padding-left: 10px;\n}\n\n.checkout ion-button {\n  margin-top: 20px;\n  --border-radius: 10px;\n}\n\n.rb-input-shadow {\n  --padding-start: 20px;\n  --padding-end: 10px;\n  margin: 10px 10px 10px auto;\n  border-radius: 4px;\n  box-shadow: 0 8px 8px 0 #0000001c;\n  border-top: 0.5px solid #0808080a;\n  color: #4c4a4a;\n  background: #fff;\n  margin-bottom: 15px;\n}\n\nion-note {\n  text-align: left;\n  margin: auto;\n  display: block;\n  padding-left: 20px;\n}\n\n.address {\n  margin-left: 10px;\n}\n\n.spinner {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbS1vcmRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGlDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQUhKOztBQU1BO0VBQ0UscUJBQUE7QUFIRjs7QUFPSTtFQUNJLFdBQUE7QUFKUjs7QUFRQTtFQUNFLDRDQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFMRjs7QUFPRTtFQUNFLDJCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FBTEo7O0FBT0k7RUFFRSxTQUFBO0FBTk47O0FBUUk7RUFDRSxjQUFBO0FBTk47O0FBUUk7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQU5OOztBQW1CRTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBaEJKOztBQWtCSTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7QUFoQk47O0FBa0JNO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBaEJSOztBQWtCUTtFQUNFLFVBQUE7QUFoQlY7O0FBa0JRO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFoQlY7O0FBbUJNO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBakJSOztBQW1CUTtFQUNFLFVBQUE7QUFqQlY7O0FBbUJRO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFqQlY7O0FBcUJNO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0FBbkJSOztBQXFCUTtFQUNFLFVBQUE7QUFuQlY7O0FBcUJRO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFuQlY7O0FBd0JJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtBQXRCTjs7QUF3Qk07RUFDRSxrQkFBQTtBQXRCUjs7QUFrQ0U7RUFDRSxnQkFBQTtFQUNBLHFCQUFBO0FBL0JKOztBQW1DQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLGNBOUljO0VBK0lkLGdCQUFBO0VBQ0EsbUJBQUE7QUFoQ0Y7O0FBbUNBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBaENGOztBQWtDQTtFQUNFLGlCQUFBO0FBL0JGOztBQWtDQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUEvQkYiLCJmaWxlIjoiY3VzdG9tLW9yZGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiRib3hTaGFkb3c6ICMwMDAwMDAxYztcclxuJGJvcmRlclRvcDogIzA4MDgwODBhO1xyXG4kaW9uSW5wdXRDb2xvcjogIzRjNGE0YTtcclxuXHJcbjpob3N0IDo6bmctZGVlcCAucC1kcm9wZG93biB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGJveC1zaGFkb3c6IDAgOHB4IDhweCAwICRib3hTaGFkb3c7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBib3JkZXItdG9wOiAwLjVweCBzb2xpZCAkYm9yZGVyVG9wO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMDtcclxuICAgIGJvcmRlci1sZWZ0OiAwO1xyXG4gICAgYm9yZGVyLXJpZ2h0OiAwO1xyXG59XHJcblxyXG5pb24tY29udGVudHtcclxuICAtLWJhY2tncm91bmQ6ICNGNUY0Rjk7XHJcblxyXG59XHJcbi5jb3VudHJ5LWl0ZW0tdmFsdWUge1xyXG4gICAgaW1nLmZsYWcge1xyXG4gICAgICAgIHdpZHRoOiAxN3B4O1xyXG4gICAgfVxyXG59XHJcblxyXG4uZ2lmdC1ib3gtd3JhcHBlcntcclxuICBib3gtc2hhZG93OiBpbnNldCAwcHggMHB4IDEycHggNnB4ICMwMDAwMDAxMjtcclxuICBtYXJnaW46IDEwcHggMDtcclxuICBwYWRkaW5nOiAxMHB4IDVweDtcclxuICBib3JkZXItcmFkaXVzOiA1cHg7XHJcblxyXG4gIC5naWZ0LWJveCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwMDAwMjQ7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMnB4O1xyXG5cclxuICAgIC5yYi1naWZ0LXRleHRhcmVhe1xyXG4gICAgICAvL2JvcmRlcjogMXB4IHNvbGlkICM4ODg7XHJcbiAgICAgIG1hcmdpbjogMDtcclxuICAgIH1cclxuICAgIGlvbi1pbnB1dHtcclxuICAgICAgbGluZS1oZWlnaHQ6IDI7XHJcbiAgICB9XHJcbiAgICAuZ2lmdC1ib3gtdGV4dHtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgY29sb3I6ICM4ODg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5cclxuXHJcbi8vIC5yYi1naWZ0LWlucHV0e1xyXG4vLyAgIGJvcmRlcjogMXB4IHNvbGlkICM4ODg7XHJcbi8vICAgYm9yZGVyLXJhZGl1czogbm9uZTtcclxuLy8gfVxyXG5cclxuLy8jRjVGNEY5XHJcbiAgLnBheW1lbnQtc2VjdGlvbntcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM1ZWZmYjQ7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuXHJcbiAgICAub3JkZXItcmV2aWV3LXNlY3Rpb257XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgIGNvbG9yOiAjNjY2O1xyXG5cclxuICAgICAgLnNoaXBwaW5nLWNvc3Qtc2VjdGlvbntcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcblxyXG4gICAgICAgIC5zaGlwcGluZy1sYWJlbHtcclxuICAgICAgICAgIHdpZHRoOiA0MCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5zaGlwcGluZy10b3RhbHtcclxuICAgICAgICAgIHdpZHRoOiA2MCU7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC5vcmRlci1hbW91bnQtc2VjdGlvbntcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcblxyXG4gICAgICAgIC50b3RhbC1vcmRlcmVkLWFtb3VudC10ZXh0e1xyXG4gICAgICAgICAgd2lkdGg6IDQwJTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnRvdGFsLW9yZGVyZWQtYW1vdW50e1xyXG4gICAgICAgICAgd2lkdGg6IDYwJTtcclxuICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgcGFkZGluZy1yaWdodDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5ncmFuZC10b3RhbC1zZWN0aW9ue1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICBjb2xvcjogIzMzMztcclxuXHJcbiAgICAgICAgLmdyYW5kLXRvdGFsLWxhYmVse1xyXG4gICAgICAgICAgd2lkdGg6IDQwJTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmdyYW5kLXRvdGFsLWFtb3VudHtcclxuICAgICAgICAgIHdpZHRoOiA2MCU7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLnBheW1lbnQtbWV0aG9kLXNlY3Rpb257XHJcbiAgICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblxyXG4gICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuLmNoZWNrb3V0IHtcclxuICAvL21hcmdpbjogMjBweDtcclxuXHJcblxyXG5cclxuXHJcblxyXG4gIGlvbi1idXR0b257XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIH1cclxufVxyXG5cclxuLnJiLWlucHV0LXNoYWRvd3tcclxuICAtLXBhZGRpbmctc3RhcnQ6IDIwcHg7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcclxuICBtYXJnaW46IDEwcHggMTBweCAxMHB4IGF1dG87XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGJveC1zaGFkb3c6IDAgOHB4IDhweCAwICRib3hTaGFkb3c7XHJcbiAgYm9yZGVyLXRvcDogMC41cHggc29saWQgJGJvcmRlclRvcDtcclxuICBjb2xvcjogJGlvbklucHV0Q29sb3I7XHJcbiAgYmFja2dyb3VuZDogI2ZmZjtcclxuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG59XHJcblxyXG5pb24tbm90ZXtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIG1hcmdpbjogYXV0bztcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbn1cclxuLmFkZHJlc3Mge1xyXG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG59XHJcblxyXG4uc3Bpbm5lcntcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 40036:
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/customization-review/customization-review.component.html ***!
  \***************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" style=\"display: block; text-align: center;\">\n      <ion-button (click)=\"confirmPreview(true)\" slot=\"start\" color=\"success\"><ion-icon slot=\"icon-only\" name=\"save\"></ion-icon></ion-button>\n    </ion-buttons>\n\n    <ion-button (click)=\"onPurchase()\" class=\"buy\" strong=\"true\" mode=\"ios\" expand=\"block\" color=\"warning\">\n      <ion-icon name=\"checkmark-done-outline\"></ion-icon>\n      Buy Now\n    </ion-button>\n\n    <ion-buttons slot=\"end\" style=\"display: block; text-align: center;\">\n      <ion-button (click)=\"confirmPreview(false)\" slot=\"end\" color=\"danger\"> <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon> </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <p class=\"ion-text-center\">Preview your design</p>\n  <p id=\"preview\"></p>\n\n</ion-content>\n\n\n\n\n");

/***/ }),

/***/ 83125:
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/text-editor-screen/text-editor-screen.component.html ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\" style=\"display: block; text-align: center;\">\n      <ion-button (click)=\"confirmPreview(true)\" slot=\"start\" color=\"success\"><ion-icon slot=\"icon-only\" name=\"checkmark\"></ion-icon></ion-button>\n    </ion-buttons>\n\n    <ion-title class=\"ion-text-center\">{{ title }}</ion-title>\n\n    <ion-buttons slot=\"end\" style=\"display: block; text-align: center;\">\n      <ion-button (click)=\"confirmPreview(false)\" slot=\"end\" color=\"danger\"> <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon> </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col>\n        <div class=\"text-box\">\n          <span\n            [ngStyle]=\"{\n            'color': styleParams.color,\n            'font-size.px': styleParams.font.size,\n            'font-weight': styleParams.font.weight,\n            'transform': 'scale('+styleParams.transform.scale+') rotate('+styleParams.transform.rotate+'deg)'\n          }\"\n          > {{ text }} </span>\n        </div>\n\n        <div class=\"text-input\">\n          <ion-input placeholder=\"Write something ... \" autofocus=\"true\" type=\"text\" [(ngModel)]=\"text\"></ion-input>\n        </div>\n\n        <div class=\"text-transforms\">\n          <div class=\"color-picker\">\n            <span>Text Color</span>\n            <p-colorPicker [(ngModel)]=\"styleParams.color\"></p-colorPicker>\n          </div>\n          <ion-list>\n            <ion-item>\n              <ion-note slot=\"start\">Font Size</ion-note>\n              <ion-range (ionChange)=\"fontSize($event.detail.value)\" [value]=\"styleParams.font.size\" min=\"1\" max=\"40\" color=\"warning\" pin=\"true\"></ion-range>\n            </ion-item>\n\n            <ion-item>\n              <ion-note slot=\"start\">Font Weight</ion-note>\n              <ion-range (ionChange)=\"fontWeight($event.detail.value)\" [value]=\"styleParams.font.weight\" snaps=\"true\" step=\"100\" min=\"200\" max=\"800\" color=\"warning\" pin=\"true\"></ion-range>\n            </ion-item>\n\n            <ion-item>\n              <ion-note slot=\"start\">Zoom</ion-note>\n              <ion-range (ionChange)=\"scale($event.detail.value)\" [value]=\"styleParams.transform.scale*10\" step=\"1\" min=\"0\" max=\"80\" color=\"warning\" pin=\"true\"></ion-range>\n            </ion-item>\n\n            <ion-item>\n              <ion-note slot=\"start\">Rotate</ion-note>\n              <ion-range (ionChange)=\"rotate($event.detail.value)\" [value]=\"styleParams.transform.rotate\" snaps=\"true\" min=\"-360\" max=\"360\" color=\"warning\" pin=\"true\"></ion-range>\n            </ion-item>\n\n          </ion-list>\n        </div>\n        <!-- <h5>overlay</h5>\n              <p-colorPicker [(ngModel)]=\"styleParams.color\"></p-colorPicker> -->\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <p id=\"preview\"></p>\n\n</ion-content>\n");

/***/ }),

/***/ 75395:
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/phone-customizer/custom-order/custom-order.page.html ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"warning\" class=\"ion-text-center\">\n    <ion-title>Checkout</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <!-- address section -->\n    <ion-row *ngIf=\"addressLoading\">\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <div class=\"spinner\">\n          <ion-spinner color=\"warning\"></ion-spinner>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!addressLoading && selectedAddress\">\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n        <ion-list>\n          <ion-radio-group #address color=\"warning\" [value]=\"selectedAddress.id\" (ionChange)=\"onSelectAddress(address.value)\">\n            <ion-list-header>\n              <ion-label>\n                Select Address\n              </ion-label>\n            </ion-list-header>\n\n            <ion-item *ngFor=\"let address of addresses\">\n              <ion-radio color=\"warning\" [value]=\"address.id\"></ion-radio>\n              <ion-label class=\"address\">\n                <p> {{address.name}} : {{address.phone}}</p>\n                <p> {{address.address}}, {{address.city}}, {{address.area}}, {{address.division}}</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item (click)=\"addNewAddress()\">\n              <ion-buttons>\n                <ion-button>\n                  <ion-icon slot=\"icon-only\" color=\"tertiary\" name=\"add\"></ion-icon>\n                </ion-button>\n              </ion-buttons>\n              <ion-label color=\"tertiary\" class=\"address\"> Add different address</ion-label>\n            </ion-item>\n\n          </ion-radio-group>\n\n        </ion-list>\n        <!-- <ion-card [ngClass]=\"{'active': address.default==='1'}\">\n          <ion-card-header class='card-header'>\n            <ion-checkbox [checked]=\"address.default==='1'\" [value]=\"address.id\"></ion-checkbox>\n            {{address.type}}\n            <span *ngIf=\"address.default==='1'\"> (Default Address) </span>\n          </ion-card-header>\n          <ion-card-content>\n            <ion-label>\n              <p>{{address.name}} : {{address.phone}}</p>\n              <p>{{address.address}}, {{address.city}}, {{address.area}}, {{address.division}}</p>\n            </ion-label>\n          </ion-card-content>\n        </ion-card> -->\n      </ion-col>\n    </ion-row>\n    <!-- address section ends -->\n    <ion-row>\n      <!-- <ion-col size=\"12\" sizeSm=\"6\" sizeMd=\"6\">\n        <div class=\"checkout\">\n          <form [formGroup]=\"checkoutForm\">\n            <div class=\"name-section\">\n              <ion-input class=\"rb-input-shadow\" formControlName=\"name\" placeholder=\"Full Name\"></ion-input>\n               <ion-note *ngIf=\"checkoutForm.controls.phone.invalid && (checkoutForm.controls.phone.dirty || checkoutForm.controls.phone.touched)\" color=\"danger\" slot=\"end\">valid phone number required !</ion-note>\n              <ion-input class=\"rb-input-shadow\" maxLength=\"11\" formControlName=\"phone\" placeholder=\"Phone number\"></ion-input>\n              <ion-note *ngIf=\"checkoutForm.controls.email.invalid && (checkoutForm.controls.email.dirty || checkoutForm.controls.email.touched)\" color=\"danger\" slot=\"end\">valid email address required !</ion-note>\n              <ion-input class=\"rb-input-shadow\" formControlName=\"email\" type=\"email\" placeholder=\"email\"></ion-input>\n            </div>\n            <div class=\"address-section\">\n              <ion-input class=\"rb-input-shadow\" formControlName=\"address\" placeholder=\"house, street, local Address\"></ion-input>\n            </div>\n          </form>\n          <p-dropdown (onChange)=\"onChangeArea()\" [options]=\"area\" [(ngModel)]=\"selectedArea\" optionLabel=\"name\" [filter]=\"true\" filterBy=\"name\" [showClear]=\"true\" placeholder=\"Select Area\">\n                <ng-template pTemplate=\"selectedItem\">\n                    <div class=\"country-item country-item-value\"  *ngIf=\"selectedArea\">\n\n                        <div>{{selectedArea.name}}</div>\n                    </div>\n                </ng-template>\n          </p-dropdown>\n        </div>\n      </ion-col> -->\n      <ion-col size=\"12\" sizeSm=\"6\" sizeMd=\"6\">\n        <form [formGroup]=\"giftForm\">\n          <ion-list>\n            <ion-item>\n              <ion-checkbox (ionChange)=\"sendAsGift($event)\" [checked]=\"sendGift\" mode=\"ios\" color=\"warning\" ></ion-checkbox>\n              <ion-label color=\"dark\"> Send as gift </ion-label>\n            </ion-item>\n          </ion-list>\n          <ion-grid *ngIf=\"sendGift\" class=\"ion-no-padding\">\n            <ion-row class=\"gift-box-wrapper\">\n              <ion-label color=\"tertiary\">Gift message</ion-label>\n              <ion-col size=\"12\" class=\"gift-box\">\n                <ion-textarea formControlName=\"message\" class=\"rb-gift-textarea\" placeholder=\"write something...\" autofocus=\"true\"></ion-textarea>\n              </ion-col>\n              <ion-col size=\"2\" class=\"gift-box\">\n                <p class=\"gift-box-text\" >From</p>\n              </ion-col>\n              <ion-col size=\"10\" class=\"gift-box\">\n                  <ion-input formControlName=\"sender\"></ion-input>\n              </ion-col>\n              <!-- <ion-col>\n                <ion-list>\n                  <ion-item>\n                    <ion-checkbox (ionChange)=\"sendAsGift($event)\" [checked]=\"sendGift\" mode=\"ios\" color=\"warning\" ></ion-checkbox>\n                    <ion-label color=\"dark\"> add special packaging </ion-label>\n                  </ion-item>\n                </ion-list>\n              </ion-col> -->\n            </ion-row>\n          </ion-grid>\n\n          <!-- ddd -->\n\n          <!-- ddd -->\n        </form>\n        <div >\n          <div class=\"payment-section\">\n            <div *ngIf=\"cartLoading\" class=\"order-amount-section\">\n              <div class=\"spinner\">\n                <ion-spinner color=\"warning\"></ion-spinner>\n              </div>\n            </div>\n            <div *ngIf=\"!cartLoading\" class=\"order-review-section\">\n              <div class=\"order-amount-section\">\n                <div class=\"total-ordered-amount-text\">\n                  Sub-total\n                </div>\n                <div class=\"total-ordered-amount\">\n                  BDT {{cartDetails.data.subtotal}}\n                </div>\n              </div>\n\n              <div class=\"shipping-cost-section\">\n                <div class=\"shipping-label\">\n                  Shipping cost\n                </div>\n                <div class=\"shipping-total\">\n                  BDT {{cartDetails.data.shippingTotal}}\n                </div>\n              </div>\n\n              <div class=\"grand-total-section\">\n                <div class=\"grand-total-label\">\n                  Grand Total\n                </div>\n                <div class=\"grand-total-amount\">\n                  BDT {{cartDetails.data.grandTotal}}\n                </div>\n              </div>\n            </div>\n            <div class=\"payment-method-section\">\n              <ion-list>\n                <ion-radio-group #payment color=\"warning\" value=\"cod\" (ionChange)=\"onChangePayment(payment.value)\">\n                  <ion-list-header>\n                    <ion-label>\n                      Select Payment Method\n                    </ion-label>\n                  </ion-list-header>\n\n                  <ion-item>\n                    <ion-radio color=\"warning\" value=\"cod\"></ion-radio>\n                    <ion-label>Cash on delivery</ion-label>\n                  </ion-item>\n\n                  <!-- <ion-item>\n                    <ion-radio color=\"warning\" value=\"sslcommerz\"></ion-radio>\n                    <ion-label>SSLCOMMERZ (pay online)</ion-label>\n                  </ion-item> -->\n                </ion-radio-group>\n              </ion-list>\n            </div>\n          </div>\n          <ion-button [disabled]=\"cartLoading && addressLoading\" color=\"warning\" expand=\"full\" (click)=\"onPlacingOrder()\">Place Order</ion-button>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c.js.map