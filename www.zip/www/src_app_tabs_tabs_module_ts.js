(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_tabs_tabs_module_ts"],{

/***/ 80530:
/*!*********************************************!*\
  !*** ./src/app/tabs/tabs-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageRoutingModule": () => (/* binding */ TabsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _account_account_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../account/account.guard */ 81131);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page */ 7942);





const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_1__.TabsPage,
        children: [
            {
                path: 'home',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"), __webpack_require__.e("default-src_app_components_components_module_ts"), __webpack_require__.e("default-src_app_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../home/home.module */ 3467)).then(m => m.HomePageModule)
            },
            {
                path: 'category',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"), __webpack_require__.e("default-src_app_components_components_module_ts"), __webpack_require__.e("default-src_app_category_category_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../category/category.module */ 26914)).then(m => m.CategoryPageModule)
            },
            {
                path: 'search',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_search_search_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../search/search.module */ 24682)).then(m => m.SearchPageModule)
            },
            {
                path: 'carts',
                loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_carts_carts_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../carts/carts.module */ 92120)).then(m => m.CartsPageModule),
                canActivate: [_account_account_guard__WEBPACK_IMPORTED_MODULE_0__.AccountGuard]
            },
            {
                path: 'wishlist',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_wishlist_wishlist_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../wishlist/wishlist.module */ 90582)).then(m => m.WishlistPageModule),
                canActivate: [_account_account_guard__WEBPACK_IMPORTED_MODULE_0__.AccountGuard],
            },
            {
                path: 'account',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-api_js"), __webpack_require__.e("default-node_modules_primeng_fesm2015_primeng-dropdown_js-src_app_services_address_address_se-0d111e"), __webpack_require__.e("default-src_app_components_customization-review_customization-review_component_ts-src_app_com-7d2f4c"), __webpack_require__.e("default-src_app_components_components_module_ts"), __webpack_require__.e("default-src_app_account_account_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../account/account.module */ 63879)).then(m => m.AccountPageModule)
            },
            {
                path: '',
                redirectTo: '/tabs/home',
                pathMatch: 'full'
            }
            // {
            //   path: 'tab1',
            //   loadChildren: () => import('../tab1/tab1.module').then(m => m.Tab1PageModule)
            // },
            // {
            //   path: 'tab2',
            //   loadChildren: () => import('../tab2/tab2.module').then(m => m.Tab2PageModule)
            // },
            // {
            //   path: 'tab3',
            //   loadChildren: () => import('../tab3/tab3.module').then(m => m.Tab3PageModule)
            // },
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ 15564:
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageModule": () => (/* binding */ TabsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs-routing.module */ 80530);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page */ 7942);







let TabsPageModule = class TabsPageModule {
};
TabsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__.TabsPageRoutingModule
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_1__.TabsPage]
    })
], TabsPageModule);



/***/ }),

/***/ 7942:
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPage": () => (/* binding */ TabsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_tabs_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./tabs.page.html */ 97665);
/* harmony import */ var _tabs_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page.scss */ 24427);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _services_breakpoint_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/breakpoint.service */ 43489);





let TabsPage = class TabsPage {
    constructor(brkPointObs) {
        this.brkPointObs = brkPointObs;
        this.showTabTitle = true;
        this.desktop = false;
        //this.getSize();
    }
    ngOnInit() {
        this.getSize();
    }
    getSize() {
        this.brkPointObs.size.subscribe(data => {
            console.log('size : ', data);
            if (data === 'xl' || data === 'lg') {
                this.desktop = true;
            }
            else {
                this.desktop = false;
            }
        });
        //console.log('window : ', window.innerWidth);
    }
};
TabsPage.ctorParameters = () => [
    { type: _services_breakpoint_service__WEBPACK_IMPORTED_MODULE_2__.BreakpointObserverService }
];
TabsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-tabs',
        template: _raw_loader_tabs_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_tabs_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TabsPage);



/***/ }),

/***/ 24427:
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".mobile .tabbar {\n  justify-content: center;\n}\n.mobile .tab-button {\n  max-width: 200px;\n}\n.mobile ::ng-deep ion-img.icon-button {\n  background: var(--ion-color-warning-tint) !important;\n  color: white;\n  border-radius: 50% !important;\n}\n.mobile :host ::ng-deep .mobile .tabs-inner {\n  position: unset !important;\n  contain: size style !important;\n  border-radius: 50% !important;\n}\n.mobile .bottom-tab-bar {\n  --background: transparent;\n  --border: 0;\n}\n.mobile ion-tab-button {\n  --background: var(--ion-color-dark-tint);\n  --color-selected: var(--ion-color-warning);\n}\n.mobile .button-center {\n  --background: transparent!important;\n  border-radius: 50%;\n}\n.mobile .button-center ion-icon {\n  height: 50px;\n  width: 50px;\n  font-size: 75px;\n}\n.mobile ion-tab-bar:before {\n  box-shadow: 0 347px 0 456px var(--ion-color-dark-tint);\n  position: absolute;\n  margin-top: -48px;\n  border-radius: 48%;\n  content: \"\";\n  margin-bottom: 68px;\n}\n.mobile .inner-center-btn {\n  position: absolute;\n  left: calc(50% - 27px);\n  bottom: 28px;\n  font-size: 70px;\n  --background: transparent;\n  z-index: 999;\n  width: 56px;\n  height: 56px;\n  border-radius: 50%;\n  border: 4px solid #FFC409;\n  box-shadow: 0 8px 8px #000000b0;\n}\n.desktop {\n  flex-direction: row !important;\n  justify-content: center;\n}\n.desktop ion-tab-bar {\n  position: absolute;\n  width: 70%;\n  margin: auto;\n  border: none;\n  --background: transparent;\n}\n.desktop ion-tab-button {\n  --background: transparent;\n  --color: var(--ion-color-dark);\n  --color-selected: var(--ion-color-warning-shade);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsdUJBQUE7QUFBSjtBQUdFO0VBQ0UsZ0JBQUE7QUFESjtBQUlFO0VBQ0Usb0RBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7QUFGSjtBQUtFO0VBQ0UsMEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0FBSEo7QUFNRTtFQUNFLHlCQUFBO0VBQ0EsV0FBQTtBQUpKO0FBT0U7RUFDRSx3Q0FBQTtFQUNBLDBDQUFBO0FBTEo7QUFRRTtFQUNFLG1DQUFBO0VBQ0Usa0JBQUE7QUFOTjtBQU9JO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FBTE47QUFVSTtFQUNFLHNEQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUVBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FBVE47QUFxQkU7RUFDRSxrQkFBQTtFQUNBLHNCQUFBO0VBRUEsWUFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSwrQkFBQTtBQXBCSjtBQTZCQTtFQUNJLDhCQUFBO0VBQ0EsdUJBQUE7QUEzQko7QUE2QkU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0FBM0JKO0FBOEJFO0VBQ0UseUJBQUE7RUFDQSw4QkFBQTtFQUNBLGdEQUFBO0FBNUJKIiwiZmlsZSI6InRhYnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1vYmlsZXtcbiAgLnRhYmJhciB7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIH1cblxuICAudGFiLWJ1dHRvbiB7XG4gICAgbWF4LXdpZHRoOiAyMDBweDtcbiAgfVxuXG4gIDo6bmctZGVlcCBpb24taW1nLmljb24tYnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2FybmluZy10aW50KSFpbXBvcnRhbnQ7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgOmhvc3QgOjpuZy1kZWVwIC5tb2JpbGUgLnRhYnMtaW5uZXIge1xuICAgIHBvc2l0aW9uOiB1bnNldCFpbXBvcnRhbnQ7XG4gICAgY29udGFpbjogc2l6ZSBzdHlsZSFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuYm90dG9tLXRhYi1iYXIge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgLS1ib3JkZXI6IDA7XG4gIH1cblxuICBpb24tdGFiLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyay10aW50KTtcbiAgICAtLWNvbG9yLXNlbGVjdGVkOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG4gIH1cblxuICAuYnV0dG9uLWNlbnRlciB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCFpbXBvcnRhbnQ7XG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgaW9uLWljb24ge1xuICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgd2lkdGg6IDUwcHg7XG4gICAgICBmb250LXNpemU6IDc1cHg7XG4gICAgfVxuICB9XG5cbiAgaW9uLXRhYi1iYXIge1xuICAgICY6YmVmb3JlIHtcbiAgICAgIGJveC1zaGFkb3c6IDAgMzQ3cHggMCA0NTZweCB2YXIoLS1pb24tY29sb3ItZGFyay10aW50KTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIG1hcmdpbi10b3A6IC00OHB4O1xuICAgICAgLy9wYWRkaW5nOiA0NnB4O1xuICAgICAgYm9yZGVyLXJhZGl1czogNDglO1xuICAgICAgY29udGVudDogXCJcIjtcbiAgICAgIG1hcmdpbi1ib3R0b206IDY4cHg7XG4gICAgfVxuICB9XG5cbiAgLmlubmVyLWxlZnQtYnRuIHtcbiAgICAvL2JvcmRlci1yYWRpdXM6IDAgMzklIDAgMDsgLy8gY3JlYXRlIHRoZSBjdXJ2ZWQgc3R5bGUgb24gdGhlIGxlZnQgc2lkZSBvZiB0aGUgY2VudGVyXG4gIH1cblxuICAuaW5uZXItcmlnaHQtYnRuIHtcbiAgICAvL2JvcmRlci1yYWRpdXM6IDM5JSAwIDAgMDsgLy8gY3JlYXRlIHRoZSBjdXJ2ZWQgc3R5bGUgb24gdGhlIHJpZ2h0IHNpZGUgb2YgdGhlIGNlbnRlclxuICB9XG5cbiAgLmlubmVyLWNlbnRlci1idG4ge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiBjYWxjKDUwJSAtIDI3cHgpO1xuICAgIC8vYm90dG9tOiAyMHB4O1xuICAgIGJvdHRvbTogMjhweDtcbiAgICBmb250LXNpemU6IDcwcHg7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICB6LWluZGV4OiA5OTk7XG4gICAgd2lkdGg6IDU2cHg7XG4gICAgaGVpZ2h0OiA1NnB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBib3JkZXI6IDRweCBzb2xpZCAjRkZDNDA5O1xuICAgIGJveC1zaGFkb3c6IDAgOHB4IDhweCAjMDAwMDAwYjA7XG4gIH1cblxuICAucmItdGFiLW1pZGRsZSB7XG4gICAgLy9iYWNrZ3JvdW5kOiByZWQ7XG4gIH1cblxufVxuXG4uZGVza3RvcHtcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93ICFpbXBvcnRhbnQ7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5cbiAgaW9uLXRhYi1iYXJ7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiA3MCU7XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIGJvcmRlcjogbm9uZTtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICB9XG5cbiAgaW9uLXRhYi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICAgIC0tY29sb3Itc2VsZWN0ZWQ6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nLXNoYWRlKTtcbiAgfVxufVxuXG4iXX0= */");

/***/ }),

/***/ 97665:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/tabs.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-tabs class=\"desktop\" *ngIf=\"desktop\">\n\n  <ion-tab-bar slot=\"top\" class=\"bottom-tab-bar\">\n\n    <ion-tab-button tab=\"home\">\n      <ion-icon name=\"home\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Home</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"category\"  class=\"inner-left-btn\">\n      <ion-icon name=\"apps-sharp\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Category</ion-label>\n    </ion-tab-button>\n\n    <!-- <ion-tab-button tab=\"search\" class=\"rb-tab-middle\">\n      <ion-icon name=\"ellipse\" class=\"icon-button\"></ion-icon>\n      <ion-label>Search</ion-label>\n    </ion-tab-button> -->\n\n    <ion-tab-button class=\"button-center\">\n      <ion-img style=\"width:150px\" src=\"../../assets/logo/logo.gif\"></ion-img>\n    </ion-tab-button>\n\n\n    <ion-tab-button tab=\"wishlist\" class=\"inner-right-btn\">\n      <ion-icon name=\"heart\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Wishlist</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"carts\">\n      <ion-icon name=\"cart\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Cart</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"account\">\n      <ion-icon name=\"person\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Account</ion-label>\n    </ion-tab-button>\n\n  </ion-tab-bar>\n\n</ion-tabs>\n\n<ion-tabs class=\"mobile\" *ngIf=\"!desktop\">\n\n  <!-- <ion-icon name=\"add\" class=\"icon-button inner-center-btn\"></ion-icon> -->\n  <!-- <ion-img\n    style=\"border-radius: 50%;\"\n    src=\"../../assets/icon/icon.gif\"\n    class=\"icon-button inner-center-btn\"></ion-img> -->\n\n  <ion-tab-bar slot=\"bottom\" class=\"bottom-tab-bar\">\n\n    <ion-tab-button tab=\"home\">\n      <ion-icon name=\"home\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Home</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"category\"  class=\"inner-left-btn\">\n      <ion-icon name=\"apps-sharp\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Category</ion-label>\n    </ion-tab-button>\n\n    <!-- <ion-tab-button tab=\"search\" class=\"rb-tab-middle\">\n      <ion-icon name=\"ellipse\" class=\"icon-button\"></ion-icon>\n      <ion-label>Search</ion-label>\n    </ion-tab-button> -->\n\n    <!-- <ion-tab-button class=\"button-center\">\n      <div></div>\n    </ion-tab-button> -->\n        <ion-tab-button tab=\"wishlist\" class=\"inner-right-btn\">\n      <ion-icon name=\"heart\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Wishlist</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"carts\" class=\"inner-right-btn\">\n      <ion-icon name=\"cart\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Cart</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"account\">\n      <ion-icon name=\"person\"></ion-icon>\n      <ion-label *ngIf=\"showTabTitle\">Account</ion-label>\n    </ion-tab-button>\n\n  </ion-tab-bar>\n\n</ion-tabs>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_tabs_tabs_module_ts.js.map