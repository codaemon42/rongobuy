(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["src_app_pages_order-tracking_order-tracking_module_ts"],{

/***/ 77413:
/*!***********************************************************************!*\
  !*** ./src/app/pages/order-tracking/order-tracking-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderTrackingPageRoutingModule": () => (/* binding */ OrderTrackingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _order_tracking_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-tracking.page */ 87941);




const routes = [
    {
        path: '',
        component: _order_tracking_page__WEBPACK_IMPORTED_MODULE_0__.OrderTrackingPage
    }
];
let OrderTrackingPageRoutingModule = class OrderTrackingPageRoutingModule {
};
OrderTrackingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrderTrackingPageRoutingModule);



/***/ }),

/***/ 37053:
/*!***************************************************************!*\
  !*** ./src/app/pages/order-tracking/order-tracking.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderTrackingPageModule": () => (/* binding */ OrderTrackingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _order_tracking_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-tracking-routing.module */ 77413);
/* harmony import */ var _order_tracking_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-tracking.page */ 87941);







let OrderTrackingPageModule = class OrderTrackingPageModule {
};
OrderTrackingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _order_tracking_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrderTrackingPageRoutingModule
        ],
        declarations: [_order_tracking_page__WEBPACK_IMPORTED_MODULE_1__.OrderTrackingPage]
    })
], OrderTrackingPageModule);



/***/ }),

/***/ 87941:
/*!*************************************************************!*\
  !*** ./src/app/pages/order-tracking/order-tracking.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderTrackingPage": () => (/* binding */ OrderTrackingPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_order_tracking_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./order-tracking.page.html */ 76282);
/* harmony import */ var _order_tracking_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-tracking.page.scss */ 57097);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 80476);



/* eslint-disable max-len */



let OrderTrackingPage = class OrderTrackingPage {
    constructor(nav, toastCtrl) {
        this.nav = nav;
        this.toastCtrl = toastCtrl;
        this.invalidMessage = 'Order number is invalid';
        this.orderTrack = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroup({
            orderNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl(null, {
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
                updateOn: 'change'
            })
        });
        this.logo = 'https://scontent.fdac22-1.fna.fbcdn.net/v/t1.6435-9/52384618_403447716890410_7519901944706498560_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=09cbfe&_nc_ohc=4vf2J_gHjV4AX9Iw4WH&_nc_ht=scontent.fdac22-1.fna&oh=cc8086e722ec06839a2993d3ac1852a3&oe=6180485F';
    }
    ngOnInit() { }
    onOrderTrack() {
        console.log(this.orderTrack);
        if (this.orderTrack.valid) {
            console.log(('phone: '), this.orderTrack.value.orderNumber);
            this.nav.navigateForward(`/orders/${this.orderTrack.value.orderNumber}`);
        }
        else {
            console.log('invalid order track');
            this.toastCtrl.create({
                message: this.invalidMessage,
                position: 'top',
                color: 'danger',
                duration: 4000
            }).then(toastEl => {
                toastEl.present();
            });
        }
    }
};
OrderTrackingPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController }
];
OrderTrackingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-order-tracking',
        template: _raw_loader_order_tracking_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_order_tracking_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], OrderTrackingPage);



/***/ }),

/***/ 57097:
/*!***************************************************************!*\
  !*** ./src/app/pages/order-tracking/order-tracking.page.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo-container {\n  display: block;\n  width: 100%;\n  text-align: center;\n  padding-top: 50px;\n  padding-bottom: 25px;\n}\n.logo-container .site-icon {\n  width: 110px;\n  height: 110px;\n  border-radius: 50%;\n  text-align: center;\n  margin: auto;\n}\n.login-content {\n  border-radius: 10px 10px 0 0;\n  padding: 20px;\n  margin-top: 150px;\n}\n.login-content ion-input {\n  border-radius: 15px;\n  background: #fff;\n  box-shadow: 0 8px 8px 0 #ececec;\n}\n.login-content ion-button {\n  --border-radius: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLXRyYWNraW5nLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLGNBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBQUY7QUFFRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUFBSjtBQUlBO0VBQ0UsNEJBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7QUFERjtBQUdFO0VBQ0UsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLCtCQUFBO0FBREo7QUFHRTtFQUNFLHFCQUFBO0FBREoiLCJmaWxlIjoib3JkZXItdHJhY2tpbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5sb2dvLWNvbnRhaW5lcntcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB3aWR0aDogMTAwJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZy10b3A6IDUwcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDI1cHg7XHJcblxyXG4gIC5zaXRlLWljb257XHJcbiAgICB3aWR0aDogMTEwcHg7XHJcbiAgICBoZWlnaHQ6IDExMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czo1MCU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgfVxyXG59XHJcblxyXG4ubG9naW4tY29udGVudHtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMCAwO1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgbWFyZ2luLXRvcDogMTUwcHg7XHJcblxyXG4gIGlvbi1pbnB1dHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgYm94LXNoYWRvdzogMCA4cHggOHB4IDAgcmdiKDIzNiwgMjM2LCAyMzYpO1xyXG4gIH1cclxuICBpb24tYnV0dG9ue1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 76282:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/order-tracking/order-tracking.page.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"warning\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title> Order Tracking </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" sizeLg=\"4\" offsetMd=\"3\" offsetLg=\"4\">\n        <div class=\"logo-container\">\n          <img class=\"site-icon\" [src]=\"logo\" alt=\"Rongobuy\">\n        </div>\n        <div class=\"login-content\">\n          <div class=\"login-section\">\n            <form [formGroup]=\"orderTrack\" (ngSubmit)=\"onOrderTrack()\">\n              <ion-input type=\"text\" formControlName=\"orderNumber\" class=\"ion-margin-bottom ion-text-center\" placeholder=\"Order number\"></ion-input>\n              <ion-button type=\"submit\" color=\"warning\" expand=\"block\"> Track </ion-button>\n            </form>\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_order-tracking_order-tracking_module_ts.js.map