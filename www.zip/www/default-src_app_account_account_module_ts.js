(self["webpackChunkrongobuy"] = self["webpackChunkrongobuy"] || []).push([["default-src_app_account_account_module_ts"],{

/***/ 34742:
/*!***************************************************!*\
  !*** ./src/app/account/account-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountPageRoutingModule": () => (/* binding */ AccountPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _account_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account.page */ 97282);




const routes = [
    {
        path: '',
        component: _account_page__WEBPACK_IMPORTED_MODULE_0__.AccountPage
    },
    {
        path: 'profile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_account_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./profile/profile.module */ 51295)).then(m => m.ProfilePageModule)
    },
    {
        path: 'address',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_account_address_address_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./address/address.module */ 65107)).then(m => m.AddressPageModule)
    },
    {
        path: 'balance',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_account_balance_balance_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./balance/balance.module */ 79218)).then(m => m.BalancePageModule)
    }
];
let AccountPageRoutingModule = class AccountPageRoutingModule {
};
AccountPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AccountPageRoutingModule);



/***/ }),

/***/ 63879:
/*!*******************************************!*\
  !*** ./src/app/account/account.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountPageModule": () => (/* binding */ AccountPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _account_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account-routing.module */ 34742);
/* harmony import */ var _account_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account.page */ 97282);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/components.module */ 45642);








let AccountPageModule = class AccountPageModule {
};
AccountPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _account_routing_module__WEBPACK_IMPORTED_MODULE_0__.AccountPageRoutingModule
        ],
        declarations: [_account_page__WEBPACK_IMPORTED_MODULE_1__.AccountPage]
    })
], AccountPageModule);



/***/ }),

/***/ 97282:
/*!*****************************************!*\
  !*** ./src/app/account/account.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountPage": () => (/* binding */ AccountPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_account_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./account.page.html */ 65688);
/* harmony import */ var _account_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account.page.scss */ 72111);
/* harmony import */ var _services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../services/controllers/toast.service */ 41048);
/* harmony import */ var _account_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./account.service */ 10740);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/auth.service */ 37556);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/storage.service */ 71188);




/* eslint-disable object-shorthand */
/* eslint-disable no-underscore-dangle */





let AccountPage = class AccountPage {
    constructor(accountService, authService, loadingCtrl, toastService, nav, storageService) {
        this.accountService = accountService;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.toastService = toastService;
        this.nav = nav;
        this.storageService = storageService;
        this.isLogin = true;
        this.enableResend = false;
        this.counter = 100;
        this.refCounter = 100;
        this.userLoggedIn = false;
        this.bgContent = 'https://media.rongobuy.com/p/product/wyg3ubxo4kmnq2h0d9i5fpascj16tv.png';
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            console.log('user token : ', yield this.storageService.get('_userToken'));
            this.loggedInController();
            this.authService.referrer.subscribe(ref => {
                this.referrer = ref;
                if (ref !== '') {
                    this.toastService.toast('Please login to use all features', 'tertiary');
                }
                console.log('ref from acc page : ', ref);
            });
        });
    }
    ionViewWillEnter() {
        this.loggedInController();
    }
    onSendOTP(event) {
        this.enableResend = false;
        console.log(event);
        this.loginEvent = event;
        this.phoneNumber = event.phone;
        if (event.success) {
            this.loadingCtrl.create({ message: 'Sending OTP ...', mode: 'ios' }).then(el => el.present());
            this.authService.loginWithOtp(event.phone).then(res => {
                const resp = res;
                this.loadingCtrl.dismiss();
                if (resp.success) {
                    this.toastService.toast(`OTP has been sent to ${event.phone}`, 'success', 2000);
                    console.log('success login submit');
                    this.isLogin = false;
                    this.startOTPCountdown();
                }
                else {
                    this.toastService.toast(`OTP failed`, 'danger', 2000);
                    console.log('failure login submit');
                    this.isLogin = true;
                }
            });
        }
        else {
            this.isLogin = true;
            this.toastService.toast('invalid phone number', 'danger', 2000);
        }
    }
    onVerifyOTP(event) {
        console.log('onVerifyOTP : ', event);
        this.loadingCtrl.create({ message: 'verifying OTP ...', mode: 'ios' }).then(el => el.present());
        if (event.success) {
            this.authService.checkOTP(this.phoneNumber, event.code).then(res => {
                const resp = res;
                this.loadingCtrl.dismiss();
                if (resp.success) {
                    this.toastService.toast('logged in successfully', 'success', 2000);
                    this.stopOTPCountdown();
                    this.accountService.logIn(resp.data.access_token);
                    this.accountService.storeToken(resp.data.access_token);
                    console.log('successfully logged from account page');
                    this.userLoggedIn = true;
                    this.nav.navigateForward(this.referrer);
                }
                else {
                    this.toastService.toast('invalid otp executed');
                }
            });
        }
    }
    onOTPResend() {
        this.enableResend = false;
        console.log('resend');
        this.stopOTPCountdown();
        //this.startOTPCountdown();
        this.onSendOTP(this.loginEvent);
    }
    loggedInController() {
        this.userLoggedIn = this.accountService.isLoggedIn();
        if (!this.userLoggedIn) {
            this.isLogin = true;
            this.bgContent = 'https://media.rongobuy.com/p/product/wyg3ubxo4kmnq2h0d9i5fpascj16tv.png';
        }
        else {
            this.isLogin = false;
            this.bgContent = null;
        }
    }
    startOTPCountdown() {
        this.timer = setInterval(() => {
            console.log(this.counter);
            this.counter--;
            if (this.counter <= 0) {
                this.enableResend = true;
                this.counter = this.refCounter;
                clearInterval(this.timer);
            }
        }, 1000);
    }
    stopOTPCountdown() {
        clearInterval(this.timer);
        this.timer = null;
        this.counter = this.refCounter;
    }
};
AccountPage.ctorParameters = () => [
    { type: _account_service__WEBPACK_IMPORTED_MODULE_3__.AccountService },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _services_controllers_toast_service__WEBPACK_IMPORTED_MODULE_2__.ToastService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__.StorageService }
];
AccountPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-account',
        template: _raw_loader_account_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_account_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AccountPage);



/***/ }),

/***/ 72111:
/*!*******************************************!*\
  !*** ./src/app/account/account.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content ion-toolbar {\n  --background: transparent;\n}\nion-content .already-logged-in .logged-in-logo {\n  width: 200px;\n  display: block;\n  margin: auto;\n}\nion-content .already-logged-in .main-list {\n  background: transparent;\n}\nion-content .already-logged-in .main-list ion-item {\n  --background: rgba(255, 255, 255, 0.5);\n  margin: 10px;\n  border-radius: 10px;\n  box-shadow: 0 8px 8px rgba(0, 0, 0, 0.514);\n}\nion-content .already-logged-in .main-list ion-item ion-label {\n  margin-left: 10px;\n}\nion-content .already-logged-in .main-list .help {\n  --background: linear-gradient(90deg, rgba(252, 252, 252, 0.418) 0%, rgba(0, 251, 96, 0.432) 100%);\n}\nion-content .already-logged-in .main-list .help ion-label {\n  color: #0a5500;\n}\nion-content .already-logged-in .main-list .help a {\n  transform: scale(1.5);\n  padding: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjY291bnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQU1JO0VBQ0UseUJBQUE7QUFMTjtBQVdNO0VBQ0UsWUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FBVFI7QUFZTTtFQUNFLHVCQUFBO0FBVlI7QUFZUTtFQUNFLHNDQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7QUFWVjtBQVlVO0VBQ0UsaUJBQUE7QUFWWjtBQWFRO0VBQ0UsaUdBQUE7QUFYVjtBQWFVO0VBQ0UsY0FBQTtBQVhaO0FBYVU7RUFDRSxxQkFBQTtFQUNBLFlBQUE7QUFYWiIsImZpbGUiOiJhY2NvdW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuXHJcbmlvbi1jb250ZW50e1xyXG5cclxuXHJcbiAgICBpb24tdG9vbGJhcntcclxuICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLmFscmVhZHktbG9nZ2VkLWluIHtcclxuXHJcbiAgICAgIC5sb2dnZWQtaW4tbG9nbyB7XHJcbiAgICAgICAgd2lkdGg6IDIwMHB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIG1hcmdpbjogYXV0bztcclxuICAgICAgfVxyXG5cclxuICAgICAgLm1haW4tbGlzdCB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblxyXG4gICAgICAgIGlvbi1pdGVte1xyXG4gICAgICAgICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSk7XHJcbiAgICAgICAgICBtYXJnaW46IDEwcHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCA4cHggOHB4IHJnYmEoMCwgMCwgMCwgMC41MTQpO1xyXG5cclxuICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5oZWxwIHtcclxuICAgICAgICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1MiwgMjUyLCAyNTIsIDAuNDE4KSAwJSwgcmdiYSgwLCAyNTEsIDk2LCAwLjQzMikgMTAwJSk7XHJcblxyXG4gICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgY29sb3I6IHJnYigxMCwgODUsIDApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgYSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS41KTtcclxuICAgICAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 65688:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/account/account.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content style=\"--background: url({{bgContent}}) no-repeat\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/home\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n    <app-login *ngIf=\"isLogin && !userLoggedIn\" (rbOTPSend)=\"onSendOTP($event)\"></app-login>\n    <app-verify-otp *ngIf=\"!isLogin && !userLoggedIn\" (rbOTPVerify)=\"onVerifyOTP($event)\" (rbOTPResend)=\"onOTPResend()\" [counter]=\"counter\" [enableResend]=\"enableResend\"></app-verify-otp>\n    <div *ngIf=\"userLoggedIn\" class=\"already-logged-in\">\n      <ion-grid class=\"ion-no-padding\">\n        <ion-row>\n          <ion-col size=\"12\" sizeSm=\"12\" sizeMd=\"6\" offsetMd=\"3\">\n              <div class=\"logged-in-logo\">\n                <ion-img src=\"../../assets/icon/icon.gif\"></ion-img>\n              </div>\n              <ion-list class=\"main-list\">\n                <ion-item lines=\"none\">\n                  <ion-avatar>\n                    <img src=\"https://t3.ftcdn.net/jpg/03/46/83/96/360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg\">\n                  </ion-avatar>\n                  <ion-label>\n                    <h3>Welcome to Rongobuy</h3>\n                    <p>The home of premium products</p>\n                  </ion-label>\n                </ion-item>\n\n                <ion-item>\n                  <ion-icon name=\"card\"></ion-icon>\n                  <ion-label>Balance</ion-label>\n                  <ion-chip color=\"success\">300Tk</ion-chip>\n                </ion-item>\n\n                <ion-item [routerLink]=\"['/', 'tabs', 'account', 'profile']\" detail>\n                  <ion-icon name=\"person\"></ion-icon>\n                  <ion-label>Profile</ion-label>\n                </ion-item>\n                <ion-item [routerLink]=\"['/', 'tabs', 'account', 'address']\" detail>\n                  <ion-icon name=\"business\"></ion-icon>\n                  <ion-label>Address</ion-label>\n                </ion-item>\n\n\n                <ion-item [routerLink]=\"['/', 'all', 'orders']\" detail>\n                  <ion-icon name=\"cube\"></ion-icon>\n                  <ion-label>Orders</ion-label>\n                </ion-item>\n\n                <ion-item [routerLink]=\"['/', 'pages', 'order-tracking']\" detail>\n                  <ion-icon name=\"search-circle\"></ion-icon>\n                  <ion-label>Orders Tracking</ion-label>\n                </ion-item>\n\n                <ion-item class=\"help\">\n                  <ion-avatar>\n                    <img src=\"https://e7.pngegg.com/pngimages/766/525/png-clipart-computer-icons-technical-support-customer-service-call-centre-others-miscellaneous-service-thumbnail.png\">\n                  </ion-avatar>\n\n                  <ion-label>\n                    <h3>How can we help you ?</h3>\n                    <p>0196600007</p>\n                  </ion-label>\n                  <a href=\"tel:+880196600007\">\n                    <ion-icon color=\"success\" name=\"call\"></ion-icon>\n                  </a>\n\n                </ion-item>\n              </ion-list>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=default-src_app_account_account_module_ts.js.map